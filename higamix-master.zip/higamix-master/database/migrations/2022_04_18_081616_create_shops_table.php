<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShopsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shops', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained();
            $table->string('name');
            $table->string('logo_image')->nullable();
            $table->mediumText('description')->nullable();
            $table->string('general_description', 1000)->nullable();
            $table->uuid('agent_connect_code')->unique();
            $table->boolean('is_allow_agent_direct_connect');
            $table->string('telegram_channel_url')->nullable();
            $table->text('telegram_bot_api_key')->nullable();
            $table->text('telegram_channel_username')->nullable();
            $table->boolean('is_enabled_telegram_notification');
            $table->boolean('is_enable_telegram_send_product_link');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shops');
    }
}
