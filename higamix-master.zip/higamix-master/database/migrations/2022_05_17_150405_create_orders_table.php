<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained();
            $table->string('buyer_email');
            $table->foreignId('shop_id')->constrained();
            $table->decimal('total', 13, 2);
            $table->decimal('platform_commission_percentage', 13, 2);
            $table->decimal('platform_commission_amount', 13, 2);
            $table->decimal('product_cost', 13, 2);
            $table->decimal('seller_profit', 13, 2);
            $table->boolean('is_api_sales');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
