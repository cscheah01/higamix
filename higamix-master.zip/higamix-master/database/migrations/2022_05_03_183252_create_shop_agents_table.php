<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShopAgentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shop_agents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('shop_id')->constrained();
            $table->unsignedBigInteger('agent_shop_id');
            $table->foreign('agent_shop_id')->references('id')->on('shops');
            $table->boolean('is_waiting_approved');
            $table->boolean('is_approved');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shop_agents');
    }
}
