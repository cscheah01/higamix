<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('shop_id')->constrained();
            $table->string('name');
            $table->string('image')->nullable();
            $table->mediumText('description')->nullable();
            $table->foreignId('product_category_id')->nullable()->constrained();
            $table->foreignId('product_sub_category_id')->nullable()->constrained();
            $table->decimal('price', 13, 2)->nullable();
            $table->boolean('is_open_resell');
            $table->decimal('resell_cost_price', 13, 2)->nullable();
            $table->decimal('suggested_min_resell_price', 13, 2)->nullable();
            $table->integer('min_purchase_qty')->nullable();
            $table->integer('max_purchase_qty')->nullable();
            $table->string('product_type')->nullable();
            $table->mediumText('service_description')->nullable();
            $table->boolean('is_available');
            $table->boolean('is_resell');
            $table->unsignedBigInteger('parent_product_id')->nullable();
            $table->foreign('parent_product_id')->references('id')->on('products');
            $table->decimal('resell_profit', 13, 2)->nullable();
            $table->foreignId('discord_bot_id')->nullable()->constrained();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
