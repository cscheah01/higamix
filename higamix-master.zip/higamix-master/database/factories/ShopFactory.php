<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ShopFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->text,
            'logo_image' => $this->faker->image('public/storage/shop_logo', 640, 480, null, false),
            'description' => $this->faker->text,
            'agent_connect_code' => $this->faker->unique()->uuid,
            'is_allow_agent_direct_connect' => $this->faker->randomElement(['1', '0']),
            'is_enabled_telegram_notification' => 0,
            'is_enable_telegram_send_product_link' => 0,
        ];
    }
}
