<?php

namespace Database\Factories;

use App\Models\Shop;
use Illuminate\Database\Eloquent\Factories\Factory;

class DiscordBotFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'username' => $this->faker->name(),
            'avatar_image' => null,
            'webhook_url' => $this->faker->url,
            'is_enable_send_product_link' => 0,
        ];
    }
}
