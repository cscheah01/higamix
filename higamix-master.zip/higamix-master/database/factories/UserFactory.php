<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $google2fa = app('pragmarx.google2fa');
        return [
            'email' => $this->faker->unique()->safeEmail(),
            'password' => bcrypt('12345678'),
            'google_2fa_secret' => encrypt($google2fa->generateSecretKey()),
            'is_enabled_two_factor' => '0',
            'is_verified' => '0',
            'api_secret_key' => encrypt(Str::random(5) . Str::uuid() . Str::random(5)),
            'api_public_key' => Str::random(5) . Str::uuid() . Str::random(5)
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     *
     * @return \Illuminate\Database\Eloquent\Factories\Factory
     */
    public function unverified()
    {
        return $this->state(function (array $attributes) {
            return [
                'email_verified_at' => null,
            ];
        });
    }
}
