<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class InviteCodeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $is_used = $this->faker->randomElement([true, false]);
        if ($is_used == true) {
            $used_by = User::all()->random()->id;
        } else {
            $used_by = null;
        }
        return [
            'code' => $this->faker->uuid,
            'is_used' => $is_used,
            'used_by' => $used_by,
        ];
    }
}
