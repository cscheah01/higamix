<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class WalletFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'balance' => $this->faker->randomFloat(2),
            'inactive_balance' => 0.00,
            'withdraw_address' => $this->faker->address,
        ];
    }
}
