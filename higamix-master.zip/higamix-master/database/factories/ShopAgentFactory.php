<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ShopAgentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $is_waiting_approved = $this->faker->randomElement([true, false]);
        $is_approved = $is_waiting_approved == true ? false : $this->faker->randomElement([true, false]);
        return [
            'is_waiting_approved' => $is_waiting_approved,
            'is_approved' => $is_approved,
        ];
    }
}
