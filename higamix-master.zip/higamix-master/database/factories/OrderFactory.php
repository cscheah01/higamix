<?php

namespace Database\Factories;

use App\Models\Shop;
use App\Models\User;
use App\Enums\OrderStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrderFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $user_id = User::all()->random();
        $shop_id = Shop::all()->where('user_id', '!=', $user_id->id)->random();
        return [
            'user_id' => $user_id->id,
            'shop_id' => $shop_id->id,
            'total' => $this->faker->randomFloat(2),
            'platform_commission_percentage' => 4.00,
            'platform_commission_amount' => $this->faker->randomFloat(2),
            'product_cost' => $this->faker->randomFloat(2),
            'seller_profit' => $this->faker->randomFloat(2),
            'is_api_sales' => $this->faker->randomElement([true, false]),
            'status' => OrderStatus::CompletePayment()->key,
        ];
    }
}
