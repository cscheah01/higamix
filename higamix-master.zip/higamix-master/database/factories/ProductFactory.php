<?php

namespace Database\Factories;

use App\Enums\ProductType;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $productType = $this->faker->randomElement([ProductType::SerialKey()->key, ProductType::Service()->key]);
        $serviceDescription = $productType == ProductType::Service()->key ? $this->faker->text(20) : null;
        $is_open_resell = $this->faker->randomElement([true, false]);
        $resell_cost_price = $is_open_resell == true ? $this->faker->randomFloat(2) : null;
        $suggested_min_resell_price = $is_open_resell == true ? $this->faker->randomFloat(2) : null;

        return [
            'name' => $this->faker->text(20),
            'image' => null,
            'description' => $this->faker->text(20),
            'price' => $this->faker->randomFloat(2),
            'is_open_resell' => $is_open_resell,
            'resell_cost_price' => $resell_cost_price,
            'suggested_min_resell_price' => $suggested_min_resell_price,
            'min_purchase_qty' => $this->faker->randomDigitNot(0),
            'max_purchase_qty' => $this->faker->randomDigitNot(0),
            'product_type' => $productType,
            'service_description' => $serviceDescription,
            'is_available' => $this->faker->randomElement([true, false]),
            'is_resell' => false,
            'parent_product_id' => null,
            'resell_profit' => null,
            'discord_bot_id' => null,
        ];
    }
}
