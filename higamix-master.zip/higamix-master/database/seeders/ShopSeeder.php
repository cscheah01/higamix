<?php

namespace Database\Seeders;

use App\Models\Shop;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;

class ShopSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Shop::create([
            'user_id' => 1,
            'name' => 'admin shop',
            'agent_connect_code' => Str::uuid(),
            'is_allow_agent_direct_connect' => 1,
            'is_enabled_telegram_notification' => 0,
            'is_enable_telegram_send_product_link' => 0,
        ]);
    }
}
