<?php

namespace Database\Seeders;

use App\Models\Shop;
use App\Models\User;
use App\Models\Order;
use App\Models\Wallet;
use App\Models\Product;
use App\Models\ShopAgent;
use App\Enums\ProductType;
use App\Models\DiscordBot;
use App\Models\InviteCode;
use App\Models\ProductLog;
use Illuminate\Support\Str;
use App\Models\OrderProduct;
use App\Models\ProductSerial;
use App\Models\ProductCategory;
use Illuminate\Database\Seeder;
use App\Models\ProductSubCategory;
use Illuminate\Support\Facades\DB;
use App\Models\PlatformCommissionTransaction;

class TestingSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $users = User::factory(2)->create()->each(function ($users) {
            $users->assignRole('merchant');

            $shops = Shop::factory()->create([
                'user_id' => $users->id,
            ]);

            Wallet::factory()->create([
                'user_id' => $users->id,
            ]);

            DiscordBot::factory(5)->create([
                'shop_id' => $shops->id,
            ]);

            InviteCode::factory(2)->create([
                'user_id' => $users->id,
            ]);

            $productCategory = ProductCategory::factory(5)->create([
                'shop_id' => $shops->id,
            ])->each(function ($productCategory) {
                $product = Product::factory(20)->create([
                    'shop_id' => $productCategory->shop_id,
                    'product_category_id' =>  $productCategory->id,
                ])->each(function ($product) {
                    if ($product->product_type == ProductType::SerialKey()->key) {
                        ProductSerial::factory(100)->create([
                            'product_id' => $product->id,
                        ]);
                    }

                    ProductLog::factory(5)->create([
                        'product_id' => $product->id,
                    ]);
                });
            });
        });

        $admins = User::factory(5)->create()->each(function ($admins) {
            $admins->assignRole('admin');
        });

        for ($i = 0; $i < 1000; $i++) {
            $shops = Shop::all()->random();
            $parentShopId = Shop::all()->where('id', '!=', $shops->id)->first();

            $productCategory = ProductCategory::all()->where('shop_id', '=', $shops->id)->random();
            Product::create([
                'shop_id' => $shops->id,
                'name' => Str::random(20),
                'image' => null,
                'description' => Str::random(20),
                'product_category_id' => $productCategory->id,
                'price' => null,
                'is_open_resell' => false,
                'resell_cost_price' => null,
                'suggested_min_resell_price' => null,
                'min_purchase_qty' => null,
                'max_purchase_qty' => null,
                'product_type' => null,
                'service_description' => null,
                'is_available' => true,
                'is_resell' => true,
                'parent_product_id' => $parentShopId->id,
                'discord_bot_id' => null,
            ]);
        }

        $order = Order::factory(1000)->create()->each(function ($order) {
            $product = Product::all()->where('shop_id', '=', $order->shop_id)->random();
            $resellProduct = Product::all()->where('id', '=', $product->parent_product_id)->first();

            $qty = rand(1, 20);
            $unitPrice = $product->parent_product_id ? $resellProduct->price : $product->price;
            $subtotal = $qty * $unitPrice;

            $orderProduct = OrderProduct::factory()->create([
                'order_id' => $order->id,
                'product_id' => $product->id,
                'name' => $product->name,
                'product_type' => $product->parent_product_id ? $resellProduct->product_type : $product->product_type,
                'qty' => $qty,
                'unit_price' => $unitPrice,
                'sub_total' => $subtotal,
                'is_resell' => $product->is_resell,
            ]);

            if ($orderProduct->product_type == ProductType::SerialKey()->key) {
                DB::table('product_serials')->where('is_sold', '=', false)
                    ->where('product_id', '=', $product->parent_product_id ? $resellProduct->id : $product->id)
                    ->take($qty)
                    ->update([
                        'is_sold' => true,
                        'order_product_id' => $orderProduct->id,
                    ]);
            }
            PlatformCommissionTransaction::factory()->create([
                'order_id' => $order->id,
                'percentage' => $order->platform_commission_percentage,
                'amount' => $order->platform_commission_amount,
            ]);
        });

        $shops = Shop::all();
        foreach ($shops as $shop) {
            $agentShopId = Shop::all()->where('id', '!=', $shop->id)->random();
            ShopAgent::factory()->create([
                'shop_id' => $shop,
                'agent_shop_id' => $agentShopId->id,
            ]);
        }
    }
}
