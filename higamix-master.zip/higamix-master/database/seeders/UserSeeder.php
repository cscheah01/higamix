<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $google2fa = app('pragmarx.google2fa');

        $user = User::create([
            'email' => 'merchant@merchant.com',
            'password' => bcrypt('12345678'),
            'google_2fa_secret' => encrypt($google2fa->generateSecretKey()),
            'is_enabled_two_factor' => '0',
            'is_verified' => '0',
            'api_secret_key' => encrypt(Str::random(5) . Str::uuid() . Str::random(5)),
            'api_public_key' => Str::random(5) . Str::uuid() . Str::random(5)
        ]);

        $user->assignRole('merchant');

        $user = User::create([
            'email' => 'admin@admin.com',
            'password' => bcrypt('12345678'),
            'google_2fa_secret' => encrypt($google2fa->generateSecretKey()),
            'is_enabled_two_factor' => '0',
            'is_verified' => '0',
            'api_secret_key' => encrypt(Str::random(5) . Str::uuid() . Str::random(5)),
            'api_public_key' => Str::random(5) . Str::uuid() . Str::random(5)
        ]);

        $user->assignRole('admin');
    }
}
