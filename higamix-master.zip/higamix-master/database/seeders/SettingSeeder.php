<?php

namespace Database\Seeders;

use Carbon\Carbon;
use App\Models\Setting;
use App\Enums\SettingMeta;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [];

        foreach (SettingMeta::asArray() as $key => $settingMeta) {
            $metaValue = null;

            if ($settingMeta == SettingMeta::PlatformCommission) {
                $metaValue = "4.00";
            }

            $data[] = [
                'meta_key' => $key,
                'meta_value' => $metaValue,
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        Setting::insert($data);
    }
}
