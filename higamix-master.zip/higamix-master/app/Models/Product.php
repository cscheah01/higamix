<?php

namespace App\Models;

use App\Models\Shop;
use App\Models\DiscordBot;
use App\Models\ProductCategory;
use App\Models\ProductDiscount;
use App\Models\ProductSubCategory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    public function productCategory()
    {
        return $this->belongsTo(ProductCategory::class, 'product_category_id', 'id');
    }

    public function productSubCategory()
    {
        return $this->belongsTo(ProductSubCategory::class, 'product_sub_category_id', 'id');
    }

    public function productDiscounts()
    {
        return $this->hasMany(ProductDiscount::class, 'product_id', 'id');
    }

    public function shop()
    {
        return $this->belongsTo(Shop::class, 'shop_id', 'id');
    }

    public function parentProduct()
    {
        return $this->hasOne(Product::class, 'id', 'parent_product_id');
    }

    public function discordBot()
    {
        return $this->belongsTo(DiscordBot::class, 'discord_bot_id', 'id');
    }
}
