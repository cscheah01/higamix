<?php

namespace App\Exports;

use App\Models\ProductSerial;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ProductSerialExport implements FromCollection, WithMapping, WithHeadings
{
    public function __construct($data)
    {
        $this->product_id = $data['product_id'];
        $this->is_sold = $data['is_sold'];
        $this->is_export_all = $data['is_export_all'];
        $this->qty = (int)$data['qty'];
        $this->delete_after_export = $data['delete_after_export'] ?? false;
    }

    public function headings(): array
    {
        return [
            'Serial Number',
            'Is Sold',
        ];
    }


    public function collection()
    {
        $productSerials = ProductSerial::query();
        $productSerials = $productSerials->where('product_id', $this->product_id);

        if ($this->is_sold != null) {
            $productSerials = $productSerials->where('is_sold', $this->is_sold);
        }

        if ($this->is_export_all == false) {
            $productSerials = $productSerials->limit($this->qty);
        }

        $result = $productSerials->get();

        if ($this->delete_after_export == true && $this->is_sold != null && $this->is_sold == false) {
            $productSerials->delete();
        }

        return $result;
    }


    public function map($productSerial): array
    {
        return [
            $productSerial->serial_number,
            ($productSerial->is_sold ? "Sold" : "Available"),
        ];
    }
}
