<?php

namespace App\Providers;

use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Support\Facades\RateLimiter;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        RateLimiter::for('resetPasswordRateLimiter', function (Request $request) {
            return Limit::perMinutes(10, 3)->by($request->ip());
        });

        view()->composer([
            'merchant.*'
        ], function () {

            $unseenNotifications = Notification::with(['order', 'product'])
                ->where('user_id', '=', Auth::id())
                ->where('is_seen', '=', false)
                ->orderBy('created_at', 'desc')
                ->limit(5)
                ->get();

            view()->share('unseenNotifications', $unseenNotifications);

            $totalUnseenNotificationCount = Notification::where('user_id', '=', Auth::id())
                ->orderBy('created_at', 'desc')
                ->where('is_seen', '=', false)
                ->count();

            view()->share('totalUnseenNotificationCount', $totalUnseenNotificationCount);
        });
    }
}
