<?php

namespace App\Enums;

use BenSampo\Enum\Enum;


final class StockDelimiterType extends Enum
{
    const Comma =   0;
    const NewLine =   1;
    const Custom = 2;
}
