<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class NotificationType extends Enum
{
    const Product = 0;
    const ProductCategory = 1;
    const ProductSubCategory = 2;
}
