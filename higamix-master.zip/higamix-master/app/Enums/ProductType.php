<?php

namespace App\Enums;

use BenSampo\Enum\Enum;


final class ProductType extends Enum
{
    const SerialKey = 0;
    const Service = 1;
}
