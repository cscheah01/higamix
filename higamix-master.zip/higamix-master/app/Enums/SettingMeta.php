<?php

namespace App\Enums;

use BenSampo\Enum\Enum;


final class SettingMeta extends Enum
{
    const PlatformCommission = 0;
    const MinimumTopUpAmount = 1;
    const MinimumWithdrawAmount = 2;
}
