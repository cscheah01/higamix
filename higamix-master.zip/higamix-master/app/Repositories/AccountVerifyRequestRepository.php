<?php

namespace App\Repositories;

use App\Models\AccountVerifyRequest;

class AccountVerifyRequestRepository extends Repository
{
    protected $_db;

    public function __construct(AccountVerifyRequest $accountVerifyRequest)
    {
        $this->_db = $accountVerifyRequest;
    }

    public function save($userId)
    {
        $model = new AccountVerifyRequest;
        $model->user_id = $userId;
        $model->is_waiting_approved = true;
        $model->is_approved = false;

        $model->save();
        return $model->fresh();
    }

    public function getByUserId($userId)
    {
        $data = $this->_db->where('user_id', '=', $userId)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->is_approved = $data['is_approved'] ?? $model->is_approved;
        $model->is_waiting_approved = $data['is_waiting_approved'] ?? $model->is_waiting_approved;

        $model->update();
        return $model;
    }

    public function updateWaitingApproavalByUserId($data, $userId)
    {
        $model = $this->_db->where('user_id', '=', $userId)->where('is_waiting_approved', '=', true);

        $model->update([
            'is_approved' => $data['is_approved'],
            'is_waiting_approved' => $data['is_waiting_approved'],
        ]);

        return true;
    }

    public function getTotalPendingApprovalCount()
    {
        $data = $this->_db->where('is_waiting_approved', '=', true)->count();

        if ($data == null) {
            return null;
        }

        return $data;
    }
}
