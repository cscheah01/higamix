<?php

namespace App\Repositories;

use App\Models\OrderProduct;

class OrderProductRepository extends Repository
{
    protected $_db;

    public function __construct(OrderProduct $orderProduct)
    {
        $this->_db = $orderProduct;
    }

    public function save($data)
    {
        $model = new OrderProduct();
        $model->order_id = $data['order_id'];
        $model->product_id = $data['product_id'];
        $model->name = $data['name'];
        $model->product_type = $data['product_type'];
        $model->qty = $data['qty'];
        $model->unit_price = $data['unit_price'];
        $model->sub_total = $data['sub_total'];
        $model->is_resell = $data['is_resell'];

        $model->save();
        return $model->fresh();
    }

    public function bulkSave($data, $orderId)
    {
        $orderProducts = [];
        foreach ($data as $orderProduct) {
            $orderProducts[] = [
                "order_id" => $orderId,
                "product_id" => $orderProduct['product_id'],
                "name" => $orderProduct['name'],
                "product_type" => $orderProduct['product_type'],
                "qty" => $orderProduct['qty'],
                "unit_price" => $orderProduct['unit_price'],
                "sub_total" => $orderProduct['sub_total'],
                "is_resell" => $orderProduct['is_resell'],
            ];
        }

        $this->_db->insert($orderProducts);
        return $data;
    }

    public function getAllByOrderId($orderId)
    {
        $data = $this->_db->where('order_id', '=', $orderId)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getSerialKeyProductOrderId($orderId, $productType)
    {
        $data = $this->_db->select('id')->where('order_id', '=', $orderId)->where('product_type', '=', $productType)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
