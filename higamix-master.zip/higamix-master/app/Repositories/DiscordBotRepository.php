<?php

namespace App\Repositories;

use App\Models\DiscordBot;


class DiscordBotRepository extends Repository
{
    protected $_db;

    public function __construct(DiscordBot $discordBot)
    {
        $this->_db = $discordBot;
    }

    public function save($data)
    {
        $model = new DiscordBot;
        $model->shop_id = $data['shop_id'];
        $model->username = $data['username'];
        $model->avatar_image = $data['avatar_image'] ?? null;
        $model->webhook_url = encrypt($data['webhook_url']);
        $model->is_enable_send_product_link = $data['is_enable_send_product_link'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->shop_id = $data['shop_id'] ?? $model->shop_id;
        $model->username = $data['username'] ?? $model->username;
        $model->avatar_image = ($data['remove_avatar_image'] ?? false) ? null : ($data['avatar_image'] ?? $model->avatar_image);
        $model->webhook_url = ($data['webhook_url'] ?? false) ? encrypt($data['webhook_url']) : $model->webhook_url;
        $model->is_enable_send_product_link = $data['is_enable_send_product_link'] ?? $model->is_enable_send_product_link;

        $model->update();
        return $model;
    }

    public function getAllByShopIdAndSerchTerm($data, $shopId)
    {
        $username = $data['search_term'] ?? '';

        $data = $this->_db->select("id", "username")
            ->where('shop_id', '=', "$shopId")
            ->where('username', 'LIKE', "%$username%")
            ->skip($data['offset'])->take($data['result_count'])
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getTotalCountByShopIdAndSerchTerm($data, $shopId)
    {
        $discordBotUsername = $data['search_term'] ?? '';

        $totalCount = $this->_db->select("id", "username")
            ->where('shop_id', '=', "$shopId")
            ->where('username', 'LIKE', "%$discordBotUsername%")
            ->count();

        return $totalCount;
    }
}
