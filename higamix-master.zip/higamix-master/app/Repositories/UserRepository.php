<?php

namespace App\Repositories;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class UserRepository extends Repository
{
    protected $_db;

    public function __construct(User $user)
    {
        $this->_db = $user;
    }

    public function save($data)
    {
        $model = new User;
        $model->email = $data['email'];
        $model->password = Hash::make($data['password']);
        $model->google_2fa_secret = encrypt($data['google_2fa_secret']);
        $model->is_enabled_two_factor = false;
        $model->is_verified = false;
        $model->api_secret_key = encrypt($data['api_secret_key']);
        $model->api_public_key = $data['api_public_key'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->email = $data['email'] ?? $model->email;
        $model->password = ($data['password'] ?? false) ? Hash::make($data['password']) : $model->password;
        $model->google_2fa_secret = ($data['google_2fa_secret'] ?? false) ? encrypt($data['google_2fa_secret']) : $model->google_2fa_secret;
        $model->is_enabled_two_factor = $data['is_enabled_two_factor'] ?? $model->is_enabled_two_factor;
        $model->is_verified = $data['is_verified'] ?? $model->is_verified;
        $model->api_public_key = $data['api_public_key'] ?? $model->api_public_key;
        $model->api_secret_key = ($data['api_secret_key'] ?? false) ? encrypt($data['api_secret_key']) : $model->api_secret_key;

        $model->update();
        return $model;
    }

    public function getByEmail($email)
    {
        $data = $this->_db->where('email', '=', $email)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getTotalCountByCreatedAt($createdAt)
    {
        $data = $this->_db->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->whereDate('users.created_at', '=', $createdAt)
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('roles.name', '=', 'merchant')
            ->count();

        return $data;
    }

    public function getEachMonthTotalCountByYear($year)
    {
        $data = $this->_db->select(DB::raw('COUNT(*) as total,MONTH(users.created_at) as month'))
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->whereYear('users.created_at', '=', $year)
            ->where('roles.name', '=', 'merchant')
            ->groupBy(DB::raw('MONTH(users.created_at)'))
            ->get();


        return $data;
    }
}
