<?php

namespace App\Repositories;

use App\Models\Wallet;

class WalletRepository extends Repository
{
    protected $_db;

    public function __construct(Wallet $wallet)
    {
        $this->_db = $wallet;
    }

    public function save($data)
    {
        $model = new Wallet;
        $model->user_id = $data['user_id'];
        $model->balance = $data['balance'] ?? 0.00;
        $model->inactive_balance = $data['inactive_balance'] ?? 0.00;
        $model->withdraw_address = $data['withdraw_address'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function getByUserId($userId)
    {
        $data = $this->_db
            ->lockForUpdate()
            ->where('user_id', '=', $userId)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function updateByUserId($data, $userId)
    {
        $model = $this->_db->where('user_id', '=', $userId)->first();
        $model->balance = $data['balance'] ?? $model->balance;
        $model->inactive_balance = $data['inactive_balance'] ?? $model->inactive_balance;
        $model->withdraw_address = array_key_exists('withdraw_address', $data) ? $data['withdraw_address'] : $model->withdraw_address;

        $model->update();
        return $model;
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);

        $model->balance = $data['balance'] ?? $model->balance;
        $model->inactive_balance = $data['inactive_balance'] ?? $model->inactive_balance;
        $model->withdraw_address = $data['withdraw_address'] ?? $model->withdraw_address;

        $model->update();
        return $model;
    }
}
