<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\ProductDiscount;
use Illuminate\Support\Facades\DB;

class ProductDiscountRepository extends Repository
{
    protected $_db;

    public function __construct(ProductDiscount $productDiscount)
    {
        $this->_db = $productDiscount;
    }

    public function bulkSave($data, $productId)
    {
        $productDiscounts = [];
        foreach ($data as $productDiscount) {
            $productDiscounts[] = [
                "product_id" => $productId,
                "min_qty" => $productDiscount['min_qty'],
                "discounted_price" => $productDiscount['discounted_price'],
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($productDiscounts);
        return $data;
    }


    public function deleteByProductId($productId)
    {
        $this->_db->where('product_id', '=', $productId)->delete();

        return true;
    }

    public function getAllByProductId($productId)
    {
        $data = $this->_db->where('product_id', '=', $productId)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
