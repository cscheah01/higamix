<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\ProductSubCategory;

class ProductSubCategoryRepository extends Repository
{
    protected $_db;

    public function __construct(ProductSubCategory $productSubCategory)
    {
        $this->_db = $productSubCategory;
    }

    public function bulkSave($data, $productCategoryId)
    {
        $productSubCategories = [];
        foreach ($data as $productSubCategory) {
            $productSubCategories[] = [
                "product_category_id" => $productCategoryId,
                "name" =>  $productSubCategory['name'],
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($productSubCategories);
        return $data;
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);

        $model->product_category_id = $data['product_category_id'] ?? $model->product_category_id;
        $model->name = $data['name'] ?? $model->name;

        $model->update();
        return $model;
    }

    public function getAllByProductCategoryIdAndSerchTerm($data)
    {
        $name = $data['search_term'] ?? '';

        $data = $this->_db->select("id", "name")
            ->where('product_category_id', '=', $data['product_main_category_id'])
            ->where('name', 'LIKE', "%$name%")
            ->skip($data['offset'])
            ->take($data['result_count'])
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getTotalCountByProductCategoryIdAndSerchTerm($data)
    {
        $name = $data['search_term'] ?? '';

        $totalCount = $this->_db->select("id", "name")
            ->where('product_category_id', '=', $data['product_main_category_id'])
            ->where('name', 'LIKE', "%$name%")
            ->count();

        return $totalCount;
    }
}
