<?php

namespace App\Repositories;

use Illuminate\Support\Facades\DB;
use App\Models\PlatformCommissionTransaction;

class PlatformCommissionTransactionRepository extends Repository
{
    protected $_db;

    public function __construct(PlatformCommissionTransaction $platformCommissionTransaction)
    {
        $this->_db = $platformCommissionTransaction;
    }

    public function save($data)
    {
        $model = new PlatformCommissionTransaction;
        $model->order_id = $data['order_id'];
        $model->percentage = $data['platform_commission_percentage'];
        $model->amount = $data['platform_commission_amount'];

        $model->save();
        return $model->fresh();
    }

    public function getTotalByMonthAndYear($month, $year)
    {
        $data = $this->_db->select(DB::raw('SUM(amount) as total_amount'))
            ->whereMonth('created_at', '=', $month)
            ->whereYear('created_at', '=', $year)->first();

        if ($data == null) {
            return null;
        }

        return $data['total_amount'];
    }

    public function getEachMonthTotalEarnedPlatformCommission($year)
    {
        $data = $this->_db->select(DB::raw('SUM(amount) as total_platform_commission, MONTH(created_at) as month'))
            ->whereYear('created_at', '=', $year)
            ->groupBy(DB::raw('MONTH(created_at)'))->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
