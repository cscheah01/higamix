<?php

namespace App\Repositories;

use App\Models\Notification;
use Illuminate\Support\Carbon;


class NotificationRepository extends Repository
{
    protected $_db;

    public function __construct(Notification $notification)
    {
        $this->_db = $notification;
    }

    public function save($data)
    {
        $model = new Notification;
        $model->user_id = $data['user_id'];
        $model->content = $data['content'];
        $model->order_id = $data['order_id'] ?? null;
        $model->product_id = $data['product_id'] ?? null;
        $model->product_category_id = $data['product_category_id'] ?? null;
        $model->product_sub_category_id = $data['product_sub_category_id'] ?? null;
        $model->is_seen = false;

        $model->save();
        return $model->fresh();
    }

    public function bulkSave($data, $userIdList)
    {
        $notifications = [];
        foreach ($userIdList as $userId) {
            $notifications[] = [
                "user_id" => $userId,
                "content" => $data['content'],
                "order_id" =>  $data['order_id'] ?? null,
                "product_id" =>  $data['product_id'] ?? null,
                "product_category_id" =>  $data['product_category_id'] ?? null,
                "product_sub_category_id" =>  $data['product_sub_category_id'] ?? null,
                "is_seen" => false,
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($notifications);

        return $data;
    }

    public function update($data)
    {
        $model = $this->_db->where('user_id', '=', $data['user_id']);

        if (array_key_exists('product_id', $data)) {
            $model = $model->where('product_id', '=', $data['product_id']);
        }

        if (array_key_exists('id', $data)) {
            $model = $model->where('id', '=', $data['id']);
        }

        if (array_key_exists('order_id', $data)) {
            $model = $model->where('order_id', '=', $data['order_id']);
        }

        $model->update(['is_seen' => $data['is_seen'] ?? $model->is_seen]);

        return true;
    }
}
