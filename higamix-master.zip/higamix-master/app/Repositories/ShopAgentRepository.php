<?php

namespace App\Repositories;

use App\Models\ShopAgent;

class ShopAgentRepository extends Repository
{
    protected $_db;

    public function __construct(ShopAgent $shopAgent)
    {
        $this->_db = $shopAgent;
    }

    public function save($data)
    {
        $model = new ShopAgent();

        $model->shop_id = $data['shop_id'];
        $model->agent_shop_id = $data['agent_shop_id'];
        $model->is_waiting_approved = $data['is_waiting_approved'];
        $model->is_approved = $data['is_approved'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->shop_id = $data['shop_id'] ?? $model->shop_id;
        $model->agent_shop_id = $data['agent_shop_id'] ?? $model->agent_shop_id;
        $model->is_waiting_approved = $data['is_waiting_approved'] ?? $model->is_waiting_approved;
        $model->is_approved = $data['is_approved'] ?? $model->agent_shop_id;


        $model->update();
        return $model;
    }

    public function getByShopIdAndAgentShopId($shopId, $agentShopId)
    {
        $data = $this->_db
            ->where('shop_id', '=', $shopId)
            ->where('agent_shop_id', '=', $agentShopId)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getPendingAgentRequestTotalCountByShopId($shopId)
    {
        $data = $this->_db
            ->where('shop_id', '=', $shopId)
            ->where('is_waiting_approved', '=', true)
            ->count();

        return $data;
    }
}
