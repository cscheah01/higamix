<?php

namespace App\Repositories;

use App\Models\LoginHistory;


class LoginHistoryRepository extends Repository
{
    protected $_db;

    public function __construct(LoginHistory $loginHistory)
    {
        $this->_db = $loginHistory;
    }

    public function save($data){
        $model = new LoginHistory;
        $model-> user_id = $data['user_id'];
        $model->ip_address = $data['ip_address'];
        $model->country = $data['country_name'];

        $model->save();
        return $model->fresh();
    }
}
