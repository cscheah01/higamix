<?php

namespace App\Repositories;

use App\Models\WalletTransaction;

class WalletTransactionRepository extends Repository
{
    protected $_db;

    public function __construct(WalletTransaction $walletTransaction)
    {
        $this->_db = $walletTransaction;
    }

    public function save($data)
    {
        $model = new WalletTransaction;
        $model->wallet_id = $data['wallet_id'];
        $model->order_id = $data['order_id'] ?? null;
        $model->debit = $data['debit'] ?? null;
        $model->credit = $data['credit'] ?? null;
        $model->balance = $data['balance'];
        $model->description = $data['description'];
        $model->zixi_pay_transaction_id = $data['zixi_pay_transaction_id'] ?? null;
        $model->api_response = $data['api_response'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function getByZixiPayTransactionId($zixiPayTransactionId)
    {
        $data = $this->_db->lockForUpdate()->where('zixi_pay_transaction_id', '=', $zixiPayTransactionId)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
