<?php

namespace App\Repositories;

use App\Models\InviteCode;


class InviteCodeRepository extends Repository
{
    protected $_db;

    public function __construct(InviteCode $inviteCode)
    {
        $this->_db = $inviteCode;
    }

    public function save($data)
    {
        $model = new InviteCode;
        $model->user_id = $data['user_id'];
        $model->code = $data['code'];
        $model->is_used = false;
        $model->used_by = null;

        $model->save();
        return $model->fresh();
    }

    public function getByCode($code)
    {
        $data = $this->_db->lockForUpdate()->where('code', '=', $code)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }


    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->code = $data['code'] ?? $model->code;
        $model->is_used = $data['is_used'] ?? $model->is_used;
        $model->used_by = $data['used_by'] ?? $model->used_by;

        $model->update();
        return $model;
    }
}
