<?php

namespace App\Repositories;

use App\Models\Order;
use Illuminate\Support\Facades\DB;

class OrderRepository extends Repository
{
    protected $_db;

    public function __construct(Order $order)
    {
        $this->_db = $order;
    }

    public function save($data)
    {
        $model = new Order();
        $model->user_id = $data['user_id'];
        $model->buyer_email = $data['buyer_email'];
        $model->shop_id = $data['shop_id'];
        $model->total = $data['total'];
        $model->platform_commission_percentage = $data['platform_commission_percentage'];
        $model->platform_commission_amount = $data['platform_commission_amount'];
        $model->product_cost = $data['product_cost'];
        $model->seller_profit = $data['seller_profit'];
        $model->is_api_sales = $data['is_api_sales'] ?? false;
        $model->status = $data['status'];

        $model->save();
        return $model->fresh();
    }

    public function getTotalSalesByShopIdAndCreatedAt($shopId, $createAt)
    {
        $data = $this->_db->select(DB::raw("SUM(total) as total_sales"))
            ->where('shop_id', '=', $shopId)
            ->whereDate('created_at', '=', $createAt)
            ->first();

        return $data['total_sales'] ?? 0;
    }

    public function getTotalProfitByShopIdAndCreatedAt($shopId, $createAt)
    {
        $data = $this->_db->select(DB::raw("SUM(seller_profit) as total_profit"))
            ->where('shop_id', '=', $shopId)
            ->whereDate('created_at', '=', $createAt)
            ->first();

        return $data['total_profit'] ?? 0;
    }

    public function getTotalProfitByShopIdAndMonthAndYear($shopId, $data)
    {
        $data = $this->_db->select(DB::raw("SUM(seller_profit) as total_profit"))
            ->where('shop_id', '=', $shopId)
            ->whereMonth('created_at', '=', $data['month'])
            ->whereYear('created_at', '=', $data['year'])
            ->first();

        return $data['total_profit'] ?? 0;
    }

    public function getTotalProfitByShopIdAndYear($shopId, $year)
    {
        $data = $this->_db->select(DB::raw("SUM(seller_profit) as total_profit"))
            ->where('shop_id', '=', $shopId)
            ->whereYear('created_at', '=', $year)
            ->first();

        return $data['total_profit'] ?? 0;
    }

    public function getEachMonthSalesByShopIdAndYear($shopId, $year)
    {
        $data = DB::table('orders')->select(DB::raw('SUM(total) as total_amount, MONTH(created_at) as month'))
            ->where('shop_id', '=', $shopId)
            ->whereYear('created_at', '=', $year)
            ->groupBy(DB::raw('MONTH(created_at)'))
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getTotalSalesByMonthAndYear($month, $year)
    {
        $data = $this->_db->select(DB::raw('SUM(total) as total_amount'))
            ->whereMonth('created_at', '=', $month)
            ->whereYear('created_at', '=', $year)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data['total_amount'];
    }

    public function getEachMonthSalesByYear($year)
    {
        $data = $this->_db->select(DB::raw('SUM(total) as total_amount, MONTH(created_at) as month'))
            ->whereYear('created_at', '=', $year)
            ->groupBy(DB::raw('MONTH(created_at)'))
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
