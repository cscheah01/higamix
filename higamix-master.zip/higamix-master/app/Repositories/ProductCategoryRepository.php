<?php

namespace App\Repositories;

use App\Models\ProductCategory;


class ProductCategoryRepository extends Repository
{
    protected $_db;

    public function __construct(ProductCategory $productCategory)
    {
        $this->_db = $productCategory;
    }

    public function save($data)
    {
        $model = new ProductCategory;
        $model->shop_id = $data['shop_id'];
        $model->name = $data['name'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->shop_id = $data['shop_id'] ?? $model->shop_id;
        $model->name = $data['name'] ?? $model->name;

        $model->update();
        return $model;
    }

    public function getAllByShopIdAndSerchTerm($data, $shopId)
    {
        $name = $data['search_term'] ?? '';

        $data = $this->_db->select("id", "name")
            ->where('shop_id', '=', "$shopId")
            ->where('name', 'LIKE', "%$name%")
            ->skip($data['offset'])->take($data['result_count'])
            ->get();

        if (empty($data)) {
            return null;
        }
        return $data;
    }

    public function getTotalCountByShopIdAndSerchTerm($data, $shopId)
    {
        $name = $data['search_term'] ?? '';

        $totalCount = $this->_db->select("id", "name")
            ->where('shop_id', '=', "$shopId")
            ->where('name', 'LIKE', "%$name%")
            ->count();

        return $totalCount;
    }
}
