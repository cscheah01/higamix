<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\ProductSerial;

class ProductSerialRepository extends Repository
{
    protected $_db;

    public function __construct(ProductSerial $productSerial)
    {
        $this->_db = $productSerial;
    }

    public function bulkSave($data, $productId)
    {
        $productSerials = [];
        foreach ($data as $seriesNumber) {
            $productSerials[] = [
                "product_id" => $productId,
                "serial_number" => $seriesNumber,
                "is_sold" => 0,
                "order_product_id" => null,
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($productSerials);
        return $data;
    }

    public function updateSold($data)
    {
        $model = $this->_db->where('is_sold', false)
            ->where('product_id', $data['product_id'])
            ->take($data['qty']);


        $model->update([
            'is_sold' => true,
            'order_product_id' => $data['order_product_id'],
        ]);

        return $model;
    }

    public function getTotalUnSoldCountByProductId($productId)
    {
        $data = $this->_db->lockForUpdate()->where('is_sold', false)
            ->where('product_id', '=', $productId)->count();

        return $data;
    }

    public function getAllByOrderProductId($orderProductId)
    {
        $data = $this->_db
            ->where('order_product_id', '=', $orderProductId)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
