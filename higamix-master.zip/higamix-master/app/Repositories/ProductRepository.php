<?php

namespace App\Repositories;

use App\Models\Product;
use App\Enums\ProductType;
use Illuminate\Support\Facades\DB;

class ProductRepository extends Repository
{
    protected $_db;

    public function __construct(Product $product)
    {
        $this->_db = $product;
    }

    public function save($data)
    {
        $model = new Product();
        $model->shop_id = $data['shop_id'];
        $model->name = $data['name'];
        $model->image = $data['image'];
        $model->description = $data['description'];
        $model->product_category_id = $data['product_category_id'] ?? null;
        $model->product_sub_category_id = $data['product_sub_category_id'] ?? null;
        $model->price = $data['price'] ?? null;
        $model->is_open_resell = $data['is_open_resell'];
        $model->resell_cost_price = $data['is_open_resell'] ? $data['resell_cost_price'] : null;
        $model->suggested_min_resell_price = $data['suggested_min_resell_price'] ? $data['suggested_min_resell_price'] : null;
        $model->min_purchase_qty = $data['min_purchase_qty'];
        $model->max_purchase_qty = $data['max_purchase_qty'];
        $model->product_type = $data['product_type'];
        $model->service_description = $data['product_type'] == ProductType::Service()->key ? $data['service_description'] : null;
        $model->is_available = $data['is_available'];
        $model->is_resell = 0;
        $model->parent_product_id = $data['parent_product_id'] ?? null;
        $model->resell_profit = $data['resell_profit'] ?? null;
        $model->discord_bot_id = $data['discord_bot_id'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function saveResellProduct($data)
    {
        $model = new Product();
        $model->shop_id = $data['agent_shop_id'];
        $model->name = $data['name'];
        $model->image = $data['image'] ?? null;
        $model->description = $data['description'] ?? null;
        $model->product_category_id = $data['product_category_id'] ?? null;
        $model->product_sub_category_id = $data['product_sub_category_id'] ?? null;
        $model->price = $data['price'] ?? null;
        $model->is_open_resell = 0;
        $model->resell_cost_price = $data['resell_cost_price'] ?? null;
        $model->suggested_min_resell_price = $data['suggested_min_resell_price'] ?? null;
        $model->min_purchase_qty = $data['min_purchase_qty'] ?? null;
        $model->max_purchase_qty = $data['max_purchase_qty'] ?? null;
        $model->product_type = $data['product_type'] ?? null;
        $model->service_description = $data['service_description'] ?? null;
        $model->is_available = $data['is_available'];
        $model->is_resell = 1;
        $model->parent_product_id = $data['parent_product_id'];
        $model->resell_profit = $data['resell_profit'];
        $model->discord_bot_id = $data['discord_bot_id'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function updateProduct($data, $id)
    {
        $model = $this->_db->find($id);
        $model->shop_id = $data['shop_id'] ?? $model->shop_id;
        $model->name = $data['name'] ?? $model->name;
        if ($data['remove_image'] ?? false) {
            $model->image = null;
        } else {
            $model->image = $data['image'] ?? $model->image;
        }
        $model->description = $data['description'] ?? $model->description;
        $model->product_category_id = $data['product_category_id'] ?? $model->product_category_id;
        $model->product_sub_category_id = $data['product_sub_category_id'] ?? $model->product_sub_category_id;
        $model->price = $data['price'] ?? $model->price;
        $model->is_open_resell = $data['is_open_resell'] ?? $model->is_open_resell;

        if ($data['is_open_resell'] == false) {
            $model->resell_cost_price = null;
            $model->suggested_min_resell_price = null;
        } else {
            $model->resell_cost_price = $data['resell_cost_price'] ?? $model->resell_cost_price;
            $model->suggested_min_resell_price = $data['suggested_min_resell_price'] ?? $model->suggested_min_resell_price;
        }

        $model->min_purchase_qty = $data['min_purchase_qty'] ?? $model->min_purchase_qty;
        $model->max_purchase_qty = $data['max_purchase_qty'] ?? $model->max_purchase_qty;
        $model->product_type = $data['product_type'] ?? $model->product_type;
        $model->service_description = $data['service_description'] ?? $model->service_description;
        $model->is_available = $data['is_available'] ?? $model->is_available;
        $model->is_resell = $data['is_resell'] ?? $model->is_resell;
        $model->parent_product_id = $data['parent_product_id'] ?? $model->parent_product_id;
        $model->resell_profit = $data['resell_profit'] ?? $model->resell_profit;
        $model->discord_bot_id = $data['discord_bot_id'] ?? $model->discord_bot_id;

        $model->update();
        return $model->refresh();
    }

    public function updateResellProduct($data, $id)
    {
        $model = $this->_db->find($id);
        $model->shop_id = $data['shop_id'] ?? $model->shop_id;
        $model->name = $data['name'] ?? $model->name;
        $model->image = $data['image'] ?? $model->image;
        $model->description = $data['description'] ?? $model->description;
        $model->product_category_id = $data['product_category_id'] ?? $model->product_category_id;
        $model->product_sub_category_id = $data['product_sub_category_id'] ?? $model->product_sub_category_id;
        $model->price = $data['price'] ?? $model->price;
        $model->is_open_resell = $data['is_open_resell'] ?? $model->is_open_resell;
        $model->resell_cost_price = $data['resell_cost_price'] ?? $model->resell_cost_price;
        $model->suggested_min_resell_price = $data['suggested_min_resell_price'] ?? $model->suggested_min_resell_price;
        $model->min_purchase_qty = $data['min_purchase_qty'] ?? $model->min_purchase_qty;
        $model->max_purchase_qty = $data['max_purchase_qty'] ?? $model->max_purchase_qty;
        $model->product_type = $data['product_type'] ?? $model->product_type;
        $model->service_description = $data['service_description'] ?? $model->service_description;
        $model->is_available = $data['is_available'] ?? $model->is_available;
        $model->is_resell = $data['is_resell'] ?? $model->is_resell;
        $model->parent_product_id = $data['parent_product_id'] ?? $model->parent_product_id;
        $model->resell_profit = $data['resell_profit'] ?? $model->resell_profit;
        $model->discord_bot_id = $data['discord_bot_id'] ?? $model->discord_bot_id;

        $model->update();
        return $model->refresh();
    }

    public function getByParentProductIdAndShopId($parentProductId, $shop_id)
    {
        $data = $this->_db
            ->where('parent_product_id', '=', $parentProductId)
            ->where('shop_id', '=', $shop_id)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllByShopIdAndSerchTermAndProductType($data, $shopId, $productType)
    {
        $name = $data['search_term'] ?? '';

        $data = $this->_db->select("id", "name")
            ->where('shop_id', '=', "$shopId")
            ->where('product_type', '=', "$productType")
            ->where('name', 'LIKE', "%$name%")
            ->skip($data['offset'])->take($data['result_count'])
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getTotalCountByShopIdAndSerchTermAndProductType($data, $shopId, $productType)
    {
        $name = $data['search_term'] ?? '';

        $totalCount = $this->_db->select("id", "name")
            ->where('shop_id', '=', "$shopId")
            ->where('product_type', '=', "$productType")
            ->where('name', 'LIKE', "%$name%")
            ->count();

        return $totalCount;
    }

    public function getAllByParentProductId($parentProductId)
    {
        $data = $this->_db->with(['shop', 'parentProduct'])->where('parent_product_id', '=', $parentProductId)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllByProductCategoryId($productCategoryId, $shopId)
    {
        $data = DB::table('products')
            ->select(
                "products.shop_id",
                "discord_bots.webhook_url as discord_bot_webhook_url",
                "discord_bots.username as discord_bot_username",
                "discord_bots.avatar_image as discord_bot_avatar_image",
                'shops.name as parent_product_shop_name',
                'product_categories.name as product_category_name',
                'reseller_shop.user_id as reseller_user_id',
            )
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftjoin('discord_bots', 'products.discord_bot_id', '=', 'discord_bots.id')
            ->leftjoin('product_categories', 'parent_product.product_category_id', '=', 'product_categories.id')
            ->leftjoin('shops', 'parent_product.shop_id', '=', 'shops.id')
            ->leftjoin('shops as reseller_shop', 'products.shop_id', '=', 'reseller_shop.id')
            ->where('parent_product.product_category_id', $productCategoryId)
            ->where('parent_product.shop_id', '=', $shopId)
            ->where('products.deleted_at', '=', null)
            ->where('products.discord_bot_id', '!=', null)
            ->get()
            ->unique('shop_id');

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllByProductSubCategoryId($productSubCategoryId, $shopId)
    {
        $data = DB::table('products')
            ->select(
                "products.shop_id",
                "discord_bots.webhook_url as discord_bot_webhook_url",
                "discord_bots.username as discord_bot_username",
                "discord_bots.avatar_image as discord_bot_avatar_image",
                'shops.name as parent_product_shop_name',
                'product_categories.name as product_category_name',
                'product_sub_categories.name as product_sub_category_name',
                'reseller_shop.user_id as reseller_user_id',
            )
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftjoin('discord_bots', 'products.discord_bot_id', '=', 'discord_bots.id')
            ->leftjoin('product_categories', 'parent_product.product_category_id', '=', 'product_categories.id')
            ->leftjoin('product_sub_categories', 'parent_product.product_sub_category_id', '=', 'product_sub_categories.id')
            ->leftjoin('shops', 'parent_product.shop_id', '=', 'shops.id')
            ->leftjoin('shops as reseller_shop', 'products.shop_id', '=', 'reseller_shop.id')
            ->where('parent_product.product_sub_category_id', $productSubCategoryId)
            ->where('parent_product.shop_id', '=', $shopId)
            ->where('products.deleted_at', '=', null)
            ->where('products.discord_bot_id', '!=', null)
            ->get()
            ->unique('shop_id');

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getByProductCategoryId($productCategoryId)
    {
        $data = $this->_db->where('product_category_id', '=', $productCategoryId)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getByProductSubCategoryId($productSubCategoryId)
    {
        $data = $this->_db->where('product_sub_category_id', '=', $productSubCategoryId)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function removeProductCategoryIdByProductCategoryId($productCategoryId)
    {
        $model = $this->_db->where('product_category_id', '=', $productCategoryId);

        $model->update([
            'product_category_id' => null,
        ]);

        return true;
    }

    public function removeProductSubCategoryIdByProductSubCategoryId($productSubCategoryId)
    {
        $model = $this->_db->where('product_sub_category_id', '=', $productSubCategoryId);

        $model->update([
            'product_sub_category_id' => null,
        ]);

        return $model;
    }

    public function deleteByParentProductId($parentProductId)
    {
        $model = $this->_db->where('parent_product_id', '=', $parentProductId);

        $model->delete();

        return true;
    }

    public function deleteProductByShopIdAndParentProductShopId($shopId, $parentProductShopId)
    {
        $model = $this->_db->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->where('products.shop_id', '=', $shopId)
            ->where('parent_product.shop_id', '=', $parentProductShopId);

        $model->delete();

        return true;
    }

    public function updateAvailableByParentProductIdAndShopId($isAvailable, $parentProductId, $shopId)
    {
        $model = $this->_db
            ->leftJoin('shop_agents', 'products.shop_id', '=', 'shop_agents.agent_shop_id')
            ->where('products.parent_product_id', '=', $parentProductId)
            ->where('shop_agents.shop_id', '=', $shopId)
            ->where('shop_agents.is_waiting_approved', '=', false)
            ->where('shop_agents.is_approved', '=', true);


        $model->update([
            'is_available' => $isAvailable
        ]);

        return true;
    }

    public function updateAvailableByParentProductShopIdAndShopId($isAvailable, $parentProductShopId, $shopId)
    {
        $model = $this->_db
            ->leftJoin('shop_agents', 'products.shop_id', '=', 'shop_agents.agent_shop_id')
            ->where('products.shop_id', '=', $shopId)
            ->where('shop_agents.shop_id', '=', $parentProductShopId);


        $model->update([
            'is_available' => $isAvailable
        ]);

        return true;
    }
}
