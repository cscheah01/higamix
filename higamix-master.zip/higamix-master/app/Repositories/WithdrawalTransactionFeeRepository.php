<?php

namespace App\Repositories;

use Illuminate\Support\Carbon;
use App\Models\WithdrawalTransactionFee;

class WithdrawalTransactionFeeRepository extends Repository
{
    protected $_db;

    public function __construct(WithdrawalTransactionFee $withdrawalTransactionFee)
    {
        $this->_db = $withdrawalTransactionFee;
    }

    public function bulkSave($data)
    {
        $withdrawalTransactionFees = [];
        foreach ($data as $withdrawalTransactionFee) {
            $withdrawalTransactionFees[] = [
                "amount_more_than_equal" => $withdrawalTransactionFee['amount_more_than_equal'],
                "fee" => $withdrawalTransactionFee['fee'],
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($withdrawalTransactionFees);
        return $data;
    }

    public function deleteAll()
    {
        $this->_db->where('id', '!=', null)->delete();


        return true;
    }
}
