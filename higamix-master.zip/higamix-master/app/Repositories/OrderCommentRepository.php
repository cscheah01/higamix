<?php

namespace App\Repositories;

use App\Models\OrderComment;


class OrderCommentRepository extends Repository
{
    protected $_db;

    public function __construct(OrderComment $orderComment)
    {
        $this->_db = $orderComment;
    }

    public function save($data)
    {
        $model = new OrderComment;
        $model->user_id = $data['user_id'];
        $model->order_id = $data['order_id'];
        $model->content = $data['content'];

        $model->save();
        return $model->fresh();
    }

    public function getAllByOrderId($orderId)
    {
        $data = $this->_db->where('order_id', '=', $orderId)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}
