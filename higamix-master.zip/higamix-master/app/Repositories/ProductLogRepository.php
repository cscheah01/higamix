<?php

namespace App\Repositories;

use App\Models\ProductLog;


class ProductLogRepository extends Repository
{
    protected $_db;

    public function __construct(ProductLog $productLog)
    {
        $this->_db = $productLog;
    }

    public function save($data)
    {
        $model = new ProductLog;
        $model->product_id = $data['product_id'] ?? null;
        $model->product_category_id = $data['product_category_id'] ?? null;
        $model->product_sub_category_id = $data['product_sub_category_id'] ?? null;
        $model->content = $data['content'];

        $model->save();
        return $model->fresh();
    }
}
