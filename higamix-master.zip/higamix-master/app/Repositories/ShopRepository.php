<?php

namespace App\Repositories;

use App\Models\Shop;
use Illuminate\Support\Str;


class ShopRepository extends Repository
{
    protected $_db;

    public function __construct(Shop $shop)
    {
        $this->_db = $shop;
    }

    public function save($data)
    {
        $model = new Shop;
        $model->user_id = $data['user_id'];
        $model->name = $data['name'];
        $model->logo_image = $data['logo_image'] ?? null;
        $model->description = $data['description'] ?? null;
        $model->general_description = $data['general_description'] ?? null;
        $model->agent_connect_code = Str::uuid();
        $model->is_allow_agent_direct_connect = $data['is_allow_agent_direct_connect'] ?? false;
        $model->telegram_channel_url = $data['telegram_channel_url'] ?? null;
        $model->telegram_bot_api_key = $data['telegram_bot_api_key'] ?? null;
        $model->telegram_channel_username = $data['telegram_channel_username'] ?? null;
        $model->is_enabled_telegram_notification = $data['is_enabled_telegram_notification'] ?? false;
        $model->is_enable_telegram_send_product_link = $data['is_enable_telegram_send_product_link'] ?? false;

        $model->save();
        return $model->fresh();
    }

    public function getByUserId($userId)
    {
        $data = $this
            ->_db->where('user_id', '=', $userId)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function updateByUserId($data, $userId)
    {
        $model = $this->_db->where('user_id', '=', $userId)->first();
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->name = $data['name'] ?? $model->name;
        $model->logo_image = ($data['remove_image'] ?? false) ? null : $data['logo_image'] ?? $model->logo_image;
        $model->description = $data['description'] ?? $model->description;
        $model->general_description = array_key_exists('general_description', $data) ? $data['general_description'] : $model->general_description;
        $model->agent_connect_code = $data['agent_connect_code'] ?? $model->agent_connect_code;
        $model->is_allow_agent_direct_connect = $data['is_allow_agent_direct_connect'] ?? $model->is_allow_agent_direct_connect;


        $model->telegram_channel_url = $data['telegram_channel_url'] ?? $model->telegram_channel_url;


        if (array_key_exists('telegram_bot_api_key', $data) && $data['telegram_bot_api_key'] == null) {
            $model->telegram_bot_api_key = $data['telegram_bot_api_key'];
        } else  if (array_key_exists('telegram_bot_api_key', $data) && $data['telegram_bot_api_key'] != null) {
            $model->telegram_bot_api_key = encrypt($data['telegram_bot_api_key']);
        } else {
            $model->telegram_bot_api_key = $model->telegram_bot_api_key;
        }

        if (array_key_exists('telegram_channel_username', $data) && $data['telegram_channel_username'] == null) {
            $model->telegram_channel_username = $data['telegram_channel_username'];
        } else if (array_key_exists('telegram_channel_username', $data) && $data['telegram_channel_username'] != null) {
            $model->telegram_channel_username = encrypt($data['telegram_channel_username']);
        } else {
            $model->telegram_channel_username = $model->telegram_channel_username;
        }

        $model->is_enabled_telegram_notification = $data['is_enabled_telegram_notification'] ?? $model->is_enabled_telegram_notification;
        $model->is_enable_telegram_send_product_link = $data['is_enable_telegram_send_product_link'] ?? $model->is_enable_telegram_send_product_link;

        $model->update();
        return $model;
    }

    public function updateById($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->name = $data['name'] ?? $model->name;
        $model->logo_image = ($data['remove_image'] ?? false) ? null : $data['logo_image'] ?? $model->logo_image;
        $model->description = $data['description'] ?? $model->description;
        $model->general_description = $data['general_description'] ?? $model->general_description;
        $model->agent_connect_code = $data['agent_connect_code'] ?? $model->agent_connect_code;
        $model->is_allow_agent_direct_connect = $data['is_allow_agent_direct_connect'] ?? $model->is_allow_agent_direct_connect;


        $model->telegram_channel_url = $data['telegram_channel_url'] ?? $model->telegram_channel_url;


        if (array_key_exists('telegram_bot_api_key', $data) && $data['telegram_bot_api_key'] == null) {
            $model->telegram_bot_api_key = $data['telegram_bot_api_key'];
        } else  if (array_key_exists('telegram_bot_api_key', $data) && $data['telegram_bot_api_key'] != null) {
            $model->telegram_bot_api_key = encrypt($data['telegram_bot_api_key']);
        } else {
            $model->telegram_bot_api_key = $model->telegram_bot_api_key;
        }

        if (array_key_exists('telegram_channel_username', $data) && $data['telegram_channel_username'] == null) {
            $model->telegram_channel_username = $data['telegram_channel_username'];
        } else if (array_key_exists('telegram_channel_username', $data) && $data['telegram_channel_username'] != null) {
            $model->telegram_channel_username = encrypt($data['telegram_channel_username']);
        } else {
            $model->telegram_channel_username = $model->telegram_channel_username;
        }

        $model->is_enabled_telegram_notification = $data['is_enabled_telegram_notification'] ?? $model->is_enabled_telegram_notification;

        $model->update();
        return $model;
    }
}
