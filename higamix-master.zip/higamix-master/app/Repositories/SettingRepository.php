<?php

namespace App\Repositories;

use App\Models\Setting;

class SettingRepository extends Repository
{
    protected $_db;

    public function __construct(Setting $setting)
    {
        $this->_db = $setting;
    }

    public function getByMetaKey($metaKey)
    {
        $data = $this->_db->where('meta_key', '=', $metaKey)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function updateByMetaKey($metaKey, $metaValue)
    {
        $model = $this->_db->where('meta_key', '=', $metaKey)->first();
        $model->meta_value = $metaValue ?? $model->meta_value;

        $model->update();
        return $model;
    }
}
