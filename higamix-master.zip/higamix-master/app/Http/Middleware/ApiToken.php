<?php

namespace App\Http\Middleware;

use Closure;
use Carbon\Carbon;
use App\Models\Shop;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ApiToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $token = Str::substr($request->header('Authorization'), 5);

        $array = explode(":", $token);

        $apiPublicKey = $array[0] ?? null;
        $timestamp = $array[1] ?? null;
        $signature = $array[2] ?? null;

        $currentTimestamp = Carbon::now();
        if (
            $apiPublicKey == null ||
            $timestamp == null ||
            $signature == null ||
            abs($timestamp - $currentTimestamp->timestamp)  > 60
        ) {
            return response()->json('Unauthorized', 401);
        }

        $user = User::where('api_public_key', $apiPublicKey)->first();

        if (empty($user)) {
            return response()->json('Unauthorized', 401);
        }

        if ($signature != hash_hmac("sha256", "{$timestamp}\r\n\r\n{$request->getContent()}", decrypt($user->api_secret_key))) {
            return response()->json('Unauthorized', 401);
        }

        $request->user = $user;
        $request->shop = Shop::where('user_id', $user->id)->first();

        return $next($request);
    }
}
