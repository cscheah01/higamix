<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ForgetPasswordService;

class ForgetPasswordController extends Controller
{
    private $_forgetPasswordService;

    public function __construct(
        ForgetPasswordService $forgetPasswordService

    ) {
        $this->_forgetPasswordService = $forgetPasswordService;
    }

    public function index()
    {
        return view('public/auth/forgot_password');
    }

    public function forgotPassword(Request $request)
    {
        $data = $request->only([
            'email',
        ]);

        $result = $this->_forgetPasswordService->forgotPassword($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_forgetPasswordService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "We've sent you an email with a link to reset your password.");
    }
}
