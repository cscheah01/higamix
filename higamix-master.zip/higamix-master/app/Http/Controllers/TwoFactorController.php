<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\TwoFactorService;
use Illuminate\Support\Facades\Auth;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Redirect;

class TwoFactorController extends Controller
{
    private $_twoFactorService;

    public function __construct(TwoFactorService $twoFactorService)
    {
        $this->_twoFactorService = $twoFactorService;
    }

    public function index()
    {
        return view('public/auth/two_factor');
    }

    public function attemp(Request $request)
    {
        $data = $request->only([
            'code',
        ]);

        $result = $this->_twoFactorService->validateTwoFactorCode($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_twoFactorService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        if (Auth::user()->hasRole('admin')) {
            return Redirect::route('admin.dashboard');
        } else if (Auth::user()->hasRole('merchant')) {
            return Redirect::route('merchant.dashboard');
        }

        return redirect(RouteServiceProvider::HOME);
    }
}
