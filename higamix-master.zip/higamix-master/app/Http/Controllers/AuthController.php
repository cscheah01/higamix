<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\AuthService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class AuthController extends Controller
{
    private $_authService;

    public function __construct(
        AuthService $authService
    ) {
        $this->_authService = $authService;
    }

    public function loginIndex()
    {
        return view('public/auth/login');
    }

    public function login(Request $request)
    {
        $data = $request->only([
            'email',
            'password',
        ]);

        $result = $this->_authService->loginUser($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        if (Auth::user()->hasRole('admin')) {
            return Redirect::route('admin.dashboard');
        } else if (Auth::user()->hasRole('merchant')) {
            return Redirect::route('merchant.dashboard');
        }

        return Redirect::route('merchant.dashboard');
    }

    public function logout()
    {
        $result = $this->_authService->logoutUser();

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('login.index');
    }

    public function registerIndex()
    {
        return view('public/auth/register');
    }


    public function register(Request $request)
    {
        $data = $request->only([
            'user.email',
            'user.password',
            'user.password_confirmation',
            'shop.name',
            'invite_code',
        ]);


        $result = $this->_authService->registerUser($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('login.index')->with('success', "Successfully registered.");
    }
}
