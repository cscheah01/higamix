<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ZixiPayService;

class ZixiPayController extends Controller
{
    private $_zixiPayService;

    public function __construct(ZixiPayService $zixiPayService)
    {
        $this->_zixiPayService = $zixiPayService;
    }

    public function callback(Request $request)
    {
        $this->_zixiPayService->handleCallback($request->input());

        return response()->json(null, 200);
    }
}
