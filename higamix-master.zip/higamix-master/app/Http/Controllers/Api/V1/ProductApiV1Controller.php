<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\Api\V1\ProductApiV1Service;

class ProductApiV1Controller extends Controller
{
    protected $_productApiV1Service;

    public function __construct(
        ProductApiV1Service $productApiV1Service
    ) {
        $this->_productApiV1Service = $productApiV1Service;
    }

    public function getProductList(Request $request)
    {
        $data['page'] = $request->query('page', 1);
        $data['shop_id'] = $request->shop->id;

        $result = $this->_productApiV1Service->getProductList($data);

        return $result;
    }

    public function getProductDetails(Request $request, $id)
    {
        $shopId = $request->shop->id;

        $result = $this->_productApiV1Service->getProductDetails($shopId, $id);

        return $result;
    }
}
