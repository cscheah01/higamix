<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\Api\V1\WalletApiV1Service;

class WalletApiV1Controller extends Controller
{
    protected $_walletApiV1Service;

    public function __construct(
        WalletApiV1Service $walletApiV1Service
    ) {
        $this->_walletApiV1Service = $walletApiV1Service;
    }

    public function getBalance(Request $request)
    {
        $userId = $request->user->id;

        $result = $this->_walletApiV1Service->getUserWalletBalance($userId);

        return $result;
    }
}
