<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\Api\V1\SalesHistoryApiV1Service;

class SalesHistoryApiV1Controller extends Controller
{
    protected $_salesHistoryApiV1Service;

    public function __construct(
        SalesHistoryApiV1Service $salesHistoryApiV1Service
    ) {
        $this->_salesHistoryApiV1Service = $salesHistoryApiV1Service;
    }

    public function getSalesHistoryList(Request $request)
    {
        $data['page'] = $request->query('page', 1);
        $data['shop_id'] = $request->shop->id;

        $result = $this->_salesHistoryApiV1Service->getSalesHistoryList($data);

        return $result;
    }

    public function getSalesHistoryDetails(Request $request, $id)
    {
        $shopId = $request->shop->id;

        $result = $this->_salesHistoryApiV1Service->getSalesHistoryDetails($shopId, $id);

        return $result;
    }
}
