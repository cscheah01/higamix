<?php

namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\Api\V1\PurchaseProductApiV1Service;

class PurchaseProductApiV1Controller extends Controller
{
    protected $_purchaseProductApiV1Service;

    public function __construct(
        PurchaseProductApiV1Service $purchaseProductApiV1Service
    ) {
        $this->_purchaseProductApiV1Service = $purchaseProductApiV1Service;
    }

    public function purchase(Request $request)
    {
        $data = $request->only([
            'buyer_email',
            'product',
        ]);

        $shopId = $request->shop->id;
        $userId = $request->user->id;

        $result = $this->_purchaseProductApiV1Service->createOrder($shopId, $userId, $data);

        return $result;
    }
}
