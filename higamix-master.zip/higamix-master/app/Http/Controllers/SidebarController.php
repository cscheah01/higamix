<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;

class SidebarController extends Controller
{
    //remember sidebar collapse by session
    public function saveState()
    {
        if (Session::has('sidebarState')) {
            Session::remove('sidebarState');
        } else {
            Session::put('sidebarState', 'sidebar-collapse');
        }
    }
}
