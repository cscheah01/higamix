<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\Admin\ShopAdminService;
use Illuminate\Support\Facades\Redirect;

class ShopAdminController extends Controller
{
    private $_shopAdminService;

    public function __construct(
        ShopAdminService $shopAdminService
    ) {
        $this->_shopAdminService = $shopAdminService;
    }

    public function index()
    {
        return view('admin/shop/index');
    }

    public function show($id)
    {
        $shop = $this->_shopAdminService->getById($id);

        if ($shop == false) {
            abort(404);
        }

        if ($shop == null) {
            $errorMessage = implode("<br>", $this->_shopAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/shop/show', compact('shop'));
    }

    public function dataTable()
    {
        $data = $this->_shopAdminService->getDataTable();

        return $data;
    }

    public function edit($id)
    {
        $shop = $this->_shopAdminService->getById($id);

        if ($shop == false) {
            abort(404);
        }

        if ($shop == null) {
            $errorMessage = implode("<br>", $this->_shopAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/shop/edit', compact('shop'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'logo_image',
            'remove_image',
            'name',
            'general_description',
            'description',
        ]);

        $result = $this->_shopAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_shopAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.shop.show',  $result->id)->with('success', "Shop successfully updated.");
    }
}
