<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\ProfileAdminService;

class ProfileAdminController extends Controller
{
    private $_profileAdminService;

    public function __construct(ProfileAdminService $profileAdminService)
    {
        $this->_profileAdminService = $profileAdminService;
    }

    public function index()
    {
        $profile = $this->_profileAdminService->getProfile();

        return view('admin/account_setting/index', compact('profile'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'email',
        ]);

        $result = $this->_profileAdminService->updateProfile($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.profile.index')->with('success', "Profile details successfully updated.");
    }

    public function edit()
    {
        $profile = $this->_profileAdminService->getProfile();

        return view('admin/account_setting/edit', compact('profile'));
    }

    public function editPassword()
    {
        return view('admin/account_setting/password/edit');
    }

    public function updatePassword(Request $request)
    {
        $data = $request->only([
            'current_password',
            'password',
            'password_confirmation',
        ]);

        $result = $this->_profileAdminService->updatePassword($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Password successfully updated.");
    }
}
