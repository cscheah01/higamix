<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\AccountVerifyRequestAdminService;


class AccountVerifyRequestAdminController extends Controller
{
    private $_accountVerifyRequestAdminService;

    public function __construct(
        AccountVerifyRequestAdminService $accountVerifyRequestAdminService
    ) {
        $this->_accountVerifyRequestAdminService = $accountVerifyRequestAdminService;
    }

    public function index()
    {
        return view('admin/account_verify_request/index');
    }

    public function rejectedIndex()
    {
        return view('admin/account_verify_request/rejected/index');
    }

    public function rejectedDataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
        ]);
        $data = $this->_accountVerifyRequestAdminService->getRejectedDataTable($filterData);

        return $data;
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
        ]);
        $data = $this->_accountVerifyRequestAdminService->getDataTable($filterData);

        return $data;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'is_approved'
        ]);

        $result = $this->_accountVerifyRequestAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_accountVerifyRequestAdminService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.merchant.show', $result->user_id)->with('success', "Account verify request successfully updated.");
    }
}
