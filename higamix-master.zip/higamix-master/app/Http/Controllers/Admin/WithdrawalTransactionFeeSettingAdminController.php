<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\WithdrawalTransactionFeeSettingAdminService;


class WithdrawalTransactionFeeSettingAdminController extends Controller
{
    private $_withdrawalTransactionFeeSettingAdminService;

    public function __construct(
        WithdrawalTransactionFeeSettingAdminService $withdrawalTransactionFeeSettingAdminService
    ) {
        $this->_withdrawalTransactionFeeSettingAdminService = $withdrawalTransactionFeeSettingAdminService;
    }

    public function index()
    {
        $withdrawalTransactionFees = $this->_withdrawalTransactionFeeSettingAdminService->getAll();

        return view('admin/withdrawal_transaction_fee_setting/index', compact('withdrawalTransactionFees'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'withdrawal_transaction_fees',
        ]);

        $result = $this->_withdrawalTransactionFeeSettingAdminService->updateWithdrawalTransactionFeesSetting($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_withdrawalTransactionFeeSettingAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.withdrawal_transaction_fee_setting.index')->with('success', "Withdraw transaction fee setting successfully updated.");
    }
}
