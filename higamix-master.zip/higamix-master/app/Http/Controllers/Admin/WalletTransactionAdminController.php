<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\WalletTransactionAdminService;

class WalletTransactionAdminController extends Controller
{
    private $_walletTransactionAdminService;

    public function __construct(
        WalletTransactionAdminService $walletTransactionAdminService
    ) {
        $this->_walletTransactionAdminService = $walletTransactionAdminService;
    }

    public function dataTable()
    {
        $data = $this->_walletTransactionAdminService->getDataTable();

        return $data;
    }
}
