<?php

namespace App\Http\Controllers\Admin;

use App\Enums\ProductType;
use App\Http\Controllers\Controller;
use App\Services\Admin\ProductAdminService;
use App\Services\Admin\ProductDiscountAdminService;


class ProductAdminController extends Controller
{
    private $_productAdminService;
    private $_productDiscountAdminService;
    private $_productTypes;

    public function __construct(
        ProductAdminService $productAdminService,
        ProductDiscountAdminService $productDiscountAdminService
    ) {
        $this->_productAdminService = $productAdminService;
        $this->_productDiscountAdminService = $productDiscountAdminService;

        $this->_productTypes = [];
        foreach (ProductType::asArray() as $key => $status) {
            $this->_productTypes[] = [
                'value' => $key,
                'description' => ProductType::fromValue($status)->description
            ];
        }
    }

    public function index()
    {
        $productTypes = $this->_productTypes;

        return view('admin/product/index', compact('productTypes'));
    }

    public function show($id)
    {
        $product = $this->_productAdminService->getById($id);

        if ($product == false) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_productAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $productDiscounts = $this->_productDiscountAdminService->getAllByProductId($id);

        $parentProduct = $this->_productAdminService->getById($product->parent_product_id);

        return view('admin/product/show', compact('product', 'productDiscounts', 'parentProduct'));
    }

    public function dataTable()
    {
        $data = $this->_productAdminService->getDataTable();

        return $data;
    }
}
