<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\TwoFactorAdminService;

class TwoFactorAdminController extends Controller
{
    private $_twoFactorAdminService;

    public function __construct(
        TwoFactorAdminService $twoFactorAdminService
    ) {
        $this->_twoFactorAdminService = $twoFactorAdminService;
    }

    public function setupIndex()
    {
        $twoFactor = $this->_twoFactorAdminService->getTwoFactorSetupDetails();

        return view('admin/two_factor/setup', compact('twoFactor'));
    }

    public function enable(Request $request)
    {
        $data = $request->only([
            'code',
        ]);

        $result = $this->_twoFactorAdminService->enableTwoFactor($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_twoFactorAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.profile.index')->with('success', "Two-factor authentication successfully enabled.");
    }

    public function disable(Request $request)
    {
        $data = $request->only([
            'is_enabled_two_factor',
        ]);

        $result = $this->_twoFactorAdminService->disableTwoFactor($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_twoFactorAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Two-factor authentication successfully disabled.");
    }

    public function disableUser(Request $request, $userId)
    {
        $data = $request->only([
            'is_enabled_two_factor'
        ]);

        $result = $this->_twoFactorAdminService->disableTwoFactor($data, $userId);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_twoFactorAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Two factor authentication successfully disabled.");
    }
}
