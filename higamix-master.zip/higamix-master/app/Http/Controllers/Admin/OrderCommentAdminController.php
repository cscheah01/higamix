<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\OrderCommentAdminService;

class OrderCommentAdminController extends Controller
{
    private $_orderCommentAdminService;

    public function __construct(
        OrderCommentAdminService $orderCommentAdminService
    ) {
        $this->_orderCommentAdminService = $orderCommentAdminService;
    }

    public function store(Request $request, $id)
    {
        $data = $request->only([
            'content',
        ]);

        $result = $this->_orderCommentAdminService->createOrderComment($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_orderCommentAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Order comment successfully save.");
    }
}
