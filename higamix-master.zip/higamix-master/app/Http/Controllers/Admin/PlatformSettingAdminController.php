<?php

namespace App\Http\Controllers\Admin;

use App\Enums\SettingMeta;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\PlatformSettingAdminService;


class PlatformSettingAdminController extends Controller
{
    private $_platformSettingAdminService;


    public function __construct(
        PlatformSettingAdminService $platformSettingAdminService
    ) {
        $this->_platformSettingAdminService = $platformSettingAdminService;
    }

    public function index()
    {
        $platformSettings = $this->_platformSettingAdminService->getAllPlatformSetting();

        return view('admin/platform_setting/index', compact('platformSettings'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'platform_setting',
            'platform_setting.' . SettingMeta::PlatformCommission()->key,
            'platform_setting.' . SettingMeta::MinimumTopUpAmount()->key,
            'platform_setting.' . SettingMeta::MinimumWithdrawAmount()->key,
        ]);

        $result = $this->_platformSettingAdminService->update($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_platformSettingAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.platform_setting.index')->with('success', "Platform setting successfully updated.");
    }
}
