<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\PlatformCommissionTransactionAdminService;

class PlatformCommissionTransactionAdminController extends Controller
{
    private $_platformCommissionTransactionAdminService;

    public function __construct(
        PlatformCommissionTransactionAdminService $platformCommissionTransactionAdminService
    ) {
        $this->_platformCommissionTransactionAdminService = $platformCommissionTransactionAdminService;
    }

    public function index()
    {
        return view('admin/platform_commission_transaction/index');
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
        ]);
        $data = $this->_platformCommissionTransactionAdminService->getDataTable($filterData);
        return $data;
    }
}
