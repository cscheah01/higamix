<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\ShopAgentAdminService;

class ShopAgentAdminController extends Controller
{
    private $_shopAgentAdminService;

    public function __construct(
        ShopAgentAdminService $shopAgentAdminService
    ) {
        $this->_shopAgentAdminService = $shopAgentAdminService;
    }

    public function index()
    {
        return view('admin/shop_agent/index');
    }


    public function dataTable()
    {
        $data = $this->_shopAgentAdminService->getDataTable();

        return $data;
    }

    public function show($id)
    {
        $shopAgent = $this->_shopAgentAdminService->getById($id);

        if ($shopAgent == false) {
            abort(404);
        }

        if ($shopAgent == null) {
            $errorMessage = implode("<br>", $this->_shopAgentAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/shop_agent/show', compact('shopAgent'));
    }
}
