<?php

namespace App\Http\Controllers\Admin;

use App\Enums\OrderStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\OrderAdminService;
use App\Services\Admin\OrderCommentAdminService;
use App\Services\Admin\OrderProductAdminService;


class OrderAdminController extends Controller
{
    private $_orderAdminService;
    private $_orderProductAdminService;
    private $_orderCommentAdminService;
    private $_orderStatuses;

    public function __construct(
        OrderAdminService $orderAdminService,
        OrderProductAdminService $orderProductAdminService,
        OrderCommentAdminService $orderCommentAdminService
    ) {
        $this->_orderAdminService = $orderAdminService;
        $this->_orderProductAdminService = $orderProductAdminService;
        $this->_orderCommentAdminService = $orderCommentAdminService;

        $this->_orderStatuses = [];
        foreach (OrderStatus::asArray() as $key => $status) {
            $this->_orderStatuses[] = [
                'value' => $key,
                'description' => OrderStatus::fromValue($status)->description
            ];
        }
    }

    public function index()
    {
        $orderStatuses = $this->_orderStatuses;

        return view('admin/platform_order/index', compact('orderStatuses'));
    }

    public function show($id)
    {
        $order = $this->_orderAdminService->getOrderById($id);

        if ($order == false) {
            abort(404);
        }

        if ($order == null) {
            $errorMessage = implode("<br>", $this->_orderAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $orderProducts = $this->_orderProductAdminService->getAllByOrderId($id);

        $orderComments = $this->_orderCommentAdminService->getAllByOrderId($id);


        return view('admin/platform_order/show', compact('order', 'orderProducts', 'orderComments'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
            'id',
        ]);
        $data = $this->_orderAdminService->getDataTable($filterData);
        return $data;
    }
}
