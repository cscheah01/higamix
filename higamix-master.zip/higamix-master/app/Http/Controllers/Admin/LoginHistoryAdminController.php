<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\Admin\LoginHistoryAdminService;


class LoginHistoryAdminController extends Controller
{
    private $_loginHistoryAdminService;

    public function __construct(
        LoginHistoryAdminService $loginHistoryAdminService
    ) {
        $this->_loginHistoryAdminService = $loginHistoryAdminService;
    }
    public function index()
    {
        $userId = Auth::id();
        return view('admin/login_history/index', compact('userId'));
    }

    public function dataTable()
    {
        $data = $this->_loginHistoryAdminService->getDataTable();

        return $data;
    }
}
