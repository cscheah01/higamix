<?php

namespace App\Http\Controllers\Admin;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\InviteCodeAdminService;


class InviteCodeAdminController extends Controller
{
    private $_inviteCodeAdminService;

    public function __construct(
        InviteCodeAdminService $inviteCodeAdminService
    ) {
        $this->_inviteCodeAdminService = $inviteCodeAdminService;
    }

    public function index()
    {
        return view('admin/invite_code/index');
    }

    public function show($id)
    {
        $inviteCode = $this->_inviteCodeAdminService->getById($id);

        if ($inviteCode == false) {
            abort(404);
        }

        if ($inviteCode == null) {
            $errorMessage = implode("<br>", $this->_inviteCodeAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/invite_code/show', compact('inviteCode'));
    }

    public function create()
    {
        return view('admin/invite_code/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'code',
        ]);

        $result = $this->_inviteCodeAdminService->createInviteCode($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_inviteCodeAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.invite_code.show',  $result->id)->with('success', "Invite code successfully added.");
    }

    public function destroy($id)
    {
        $result = $this->_inviteCodeAdminService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_inviteCodeAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.invite_code.index')->with('success', "Invite code successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_inviteCodeAdminService->getDataTable();

        return $data;
    }
}
