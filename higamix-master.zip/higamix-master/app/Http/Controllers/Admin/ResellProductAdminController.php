<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\ResellProductAdminService;


class ResellProductAdminController extends Controller
{
    private $_resellProductAdminService;

    public function __construct(
        ResellProductAdminService $resellProductAdminService
    ) {
        $this->_resellProductAdminService = $resellProductAdminService;
    }

    public function shopResellProductDataTable($shopId)
    {
        $data = $this->_resellProductAdminService->getShopResellProductDataTable($shopId);
        return $data;
    }
}
