<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\MerchantAdminService;

class MerchantAdminController extends Controller
{
    private $_merchantAdminService;

    public function __construct(
        MerchantAdminService $merchantAdminService
    ) {
        $this->_merchantAdminService = $merchantAdminService;
    }

    public function index()
    {
        return view('admin/merchant/index');
    }

    public function show($id)
    {
        $merchant = $this->_merchantAdminService->getById($id);

        if ($merchant == false) {
            abort(404);
        }

        if ($merchant == null) {
            $errorMessage = implode("<br>", $this->_merchantAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/merchant/show', compact('merchant'));
    }

    public function edit($id)
    {
        $merchant = $this->_merchantAdminService->getById($id);

        if ($merchant == false) {
            abort(404);
        }

        if ($merchant == null) {
            $errorMessage = implode("<br>", $this->_merchantAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/merchant/edit', compact('merchant'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'email',
            'password',
            'password_confirmation'
        ]);

        $result = $this->_merchantAdminService->update($data, $id);
        if ($result == null) {
            $errorMessage = implode("<br>", $this->_merchantAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.merchant.show',  $result->id)->with('success', "Merchant details successfully updated.");
    }

    public function updateAccountVerify(Request $request, $id)
    {
        $data = $request->only([
            'is_verified'
        ]);

        $result = $this->_merchantAdminService->updateAccountVerify($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_merchantAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.merchant.show',  $result['id'])->with('success', "Merchant account verification successfully updated.");
    }


    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
        ]);
        $data = $this->_merchantAdminService->getDataTable($filterData);

        return $data;
    }
}
