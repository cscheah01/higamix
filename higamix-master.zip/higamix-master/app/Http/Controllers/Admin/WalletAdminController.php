<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Services\Admin\WalletAdminService;


class WalletAdminController extends Controller
{
    private $_walletAdminService;

    public function __construct(
        WalletAdminService $walletAdminService
    ) {
        $this->_walletAdminService = $walletAdminService;
    }

    public function index()
    {
        return view('admin/wallet/index');
    }

    public function show($id)
    {
        $wallet = $this->_walletAdminService->getById($id);

        if ($wallet == false) {
            abort(404);
        }

        if ($wallet == null) {
            $errorMessage = implode("<br>", $this->_walletAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/wallet/show', compact('wallet'));
    }

    public function dataTable()
    {
        $data = $this->_walletAdminService->getDataTable();

        return $data;
    }
}
