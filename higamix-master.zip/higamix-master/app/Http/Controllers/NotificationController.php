<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\NotificationService;
use Illuminate\Support\Facades\Redirect;


class NotificationController extends Controller
{
    private $_notificationService;

    public function __construct(
        NotificationService $notificationService
    ) {
        $this->_notificationService = $notificationService;
    }

    public function index()
    {
        $userId = Auth::id();

        return view('merchant/notification/index', compact('userId'));
    }

    public function show($id)
    {
        $notification = $this->_notificationService->getById($id);

        if ($notification == false) {
            abort(404);
        }

        if ($notification == null) {
            $errorMessage = implode("<br>", $this->_notificationService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }
        $this->_notificationService->updateSeenById($id);
        return view('merchant/notification/show', compact('notification'));
    }

    public function dataTable()
    {
        $data = $this->_notificationService->getDataTable();
        return $data;
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'is_seen',
        ]);
        $result = $this->_notificationService->markAllNotificationAsSeen($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_notificationService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }
        return Redirect::route('merchant.notification.index')->with('success', "All notification successfully marked as seen.");
    }
}
