<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\PlatformSettingService;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\WalletMerchantService;
use App\Services\Merchant\WithdrawalTransactionFeeMerchantService;

class WalletMerchantController extends Controller
{
    private $_walletMerchantService;
    private $_platformSettingService;
    private $_withdrawalTransactionFeeMerchantService;

    public function __construct(
        WalletMerchantService $walletMerchantService,
        PlatformSettingService $platformSettingService,
        WithdrawalTransactionFeeMerchantService $withdrawalTransactionFeeMerchantService
    ) {
        $this->_walletMerchantService = $walletMerchantService;
        $this->_platformSettingService = $platformSettingService;
        $this->_withdrawalTransactionFeeMerchantService = $withdrawalTransactionFeeMerchantService;
    }

    public function index()
    {
        $userId = Auth::id();
        $wallet = $this->_walletMerchantService->getWalletByUserId($userId);

        $minimumWithdrawAmount = $this->_platformSettingService->getMinimumWithdrawAmount();
        $withdrawalTransactionFees
            = $this->_withdrawalTransactionFeeMerchantService->getWithdrawalTransactionFee();
        return view('merchant/wallet/index', compact('wallet', 'minimumWithdrawAmount', 'withdrawalTransactionFees'));
    }

    public function dataTable()
    {
        $data = $this->_walletMerchantService->getDataTable();

        return $data;
    }

    public function withdraw(Request $request)
    {
        $data = $request->only([
            'amount',
        ]);

        $result = $this->_walletMerchantService->walletWithdrawRequest($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_walletMerchantService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.wallet.index')->with('success', "Wallet withdrawal request successfully sent.");
    }
}
