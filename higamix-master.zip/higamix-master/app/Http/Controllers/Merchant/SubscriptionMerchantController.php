<?php

namespace App\Http\Controllers\Merchant;

class SubscriptionMerchantController extends Controller
{

    public function __construct()
    {
    }

    public function index()
    {
        return view('merchant/subscription/index');
    }
}
