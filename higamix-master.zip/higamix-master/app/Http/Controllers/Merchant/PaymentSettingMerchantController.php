<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\WalletMerchantService;

class PaymentSettingMerchantController extends Controller
{

    private $_walletMerchantService;

    public function __construct(
        WalletMerchantService $walletMerchantService
    ) {

        $this->_walletMerchantService = $walletMerchantService;
    }

    public function index()
    {
        $userId = Auth::id();
        $wallet = $this->_walletMerchantService->getWalletByUserId($userId);

        if ($wallet == null) {
            $errorMessage = implode("<br>", $this->_walletMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/account_setting/payment_setting/index', compact('wallet'));
    }

    public function edit()
    {
        $userId = Auth::id();
        $wallet = $this->_walletMerchantService->getWalletByUserId($userId);

        if ($wallet == null) {
            $errorMessage = implode("<br>", $this->_walletMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/account_setting/payment_setting/edit', compact('wallet'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'withdraw_address',
        ]);

        $result = $this->_walletMerchantService->updateWithdrawalSetting($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_walletMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.profile.payment_setting.index')->with('success', "Payment setting successfully updated.");
    }
}
