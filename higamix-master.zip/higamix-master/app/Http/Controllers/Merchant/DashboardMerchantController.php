<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Services\Merchant\OrderMerchantService;
use App\Services\Merchant\WalletMerchantService;
use App\Services\Merchant\ShopAgentMerchantService;

class DashboardMerchantController extends Controller
{
    protected $_walletMerchantService;
    protected $_orderMerchantService;
    protected $_shopAgentMerchantService;

    public function __construct(
        WalletMerchantService $walletMerchantService,
        OrderMerchantService $orderMerchantService,
        ShopAgentMerchantService $shopAgentMerchantService
    ) {
        $this->_walletMerchantService = $walletMerchantService;
        $this->_orderMerchantService = $orderMerchantService;
        $this->_shopAgentMerchantService = $shopAgentMerchantService;
    }

    public function index()
    {
        $userId = Auth::id();

        $wallet = $this->_walletMerchantService->getWalletByUserId($userId);
        $walletBalance = $wallet['balance'];

        $data['date'] = Carbon::now()->format('Y-m-d');
        $data['month'] = Carbon::now()->format('m');
        $data['year'] = Carbon::now()->format('Y');
        $dailyProfit = $this->_orderMerchantService->getDailyTotalProfit($data);
        $monthlyProfit = $this->_orderMerchantService->getMonthlyTotalProfit($data);
        $yearlyProfit = $this->_orderMerchantService->getYearlyTotalProfit($data);

        $todayTotalSales = $this->_orderMerchantService->getTodayTotalSales($data);

        $totalPendingAgentRequest = $this->_shopAgentMerchantService->getPendingAgentRequestTotalCount();
        $currentYearEachMonthSales = $this->_orderMerchantService->getCurrentYearEachMonthSales();

        return view('merchant/dashboard/index', compact('walletBalance', 'dailyProfit', 'monthlyProfit', 'yearlyProfit', 'todayTotalSales', 'totalPendingAgentRequest', 'currentYearEachMonthSales'));
    }
}
