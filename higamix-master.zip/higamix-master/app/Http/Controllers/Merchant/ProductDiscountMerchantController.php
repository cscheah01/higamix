<?php

namespace App\Http\Controllers\Merchant;

use App\Services\Merchant\ProductDiscountMerchantService;

class ProductDiscountMerchantController extends Controller
{
    private $_productDiscountMerchantService;

    public function __construct(
        ProductDiscountMerchantService $productDiscountMerchantService,
    ) {
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
    }

    public function getAllProductDiscount($productId)
    {
        $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($productId);

        return $productDiscounts;
    }
}
