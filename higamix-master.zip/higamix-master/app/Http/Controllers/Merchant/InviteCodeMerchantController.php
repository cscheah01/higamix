<?php

// namespace App\Http\Controllers\Merchant;

// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Redirect;
// use App\Services\Merchant\InviteCodeMerchantService;

// class InviteCodeMerchantController extends Controller
// {
//     private $_inviteCodeMerchantService;

//     public function __construct(
//         InviteCodeMerchantService $inviteCodeMerchantService
//     ) {
//         $this->_inviteCodeMerchantService = $inviteCodeMerchantService;
//     }

//     public function index()
//     {
//         return view('merchant/invite_code/index');
//     }

//     public function create()
//     {
//         return view('merchant/invite_code/create');
//     }

//     public function store(Request $request)
//     {
//         $data = $request->only([
//             'code',
//         ]);

//         $result = $this->_inviteCodeMerchantService->createInviteCode($data);

//         if ($result == null) {
//             $errorMessage = implode("<br>", $this->_inviteCodeMerchantService->_errorMessage);
//             return back()->with('error', $errorMessage)->withInput();
//         }

//         return Redirect::route('merchant.invite_code.show',  $result->id)->with('success', "Invite code successfully added.");
//     }

//     public function show($id)
//     {
//         $inviteCode = $this->_inviteCodeMerchantService->getById($id);

//         if ($inviteCode == false) {
//             abort(404);
//         }

//         if ($inviteCode == null) {
//             $errorMessage = implode("<br>", $this->_inviteCodeMerchantService->_errorMessage);
//             return back()->with('error', $errorMessage)->withInput();
//         }

//         return view('merchant/invite_code/show', compact('inviteCode'));
//     }

//     public function destroy($id)
//     {
//         $result = $this->_inviteCodeMerchantService->deleteById($id);

//         if ($result == null) {
//             $errorMessage = implode("<br>", $this->_inviteCodeMerchantService->_errorMessage);
//             return back()->with('error', $errorMessage)->withInput();
//         }

//         return Redirect::route('merchant.invite_code.index')->with('success', "Invite code successfully deleted.");
//     }

//     public function dataTable()
//     {
//         $data = $this->_inviteCodeMerchantService->getDataTable();

//         return $data;
//     }
// }
