<?php

namespace App\Http\Controllers\Merchant;

use App\Enums\ProductType;
use Illuminate\Http\Request;
use App\Services\Merchant\OrderProductMerchantService;

class AgentSalesHistoryMerchantController extends Controller
{
    private $_orderProductMerchantService;

    public function __construct(
        OrderProductMerchantService $orderProductMerchantService
    ) {
        $this->_orderProductMerchantService = $orderProductMerchantService;

        $this->_productTypes = [];
        foreach (ProductType::asArray() as $key => $productType) {
            $this->_productTypes[] = [
                'value' => $key,
                'description' => ProductType::fromValue($productType)->description
            ];
        }
    }

    public function index()
    {
        $productTypes = $this->_productTypes;

        return view('merchant/agent_sales_history/index', compact('productTypes'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
            'order_id',
        ]);

        $data = $this->_orderProductMerchantService->getAgentSalesProductDataTable($filterData);

        return $data;
    }
}
