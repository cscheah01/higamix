<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\TwoFactorMerchantService;

class TwoFactorMerchantController extends Controller
{
    private $_twoFactorMerchantService;

    public function __construct(TwoFactorMerchantService $twoFactorMerchantService)
    {
        $this->_twoFactorMerchantService = $twoFactorMerchantService;
    }

    public function setupIndex()
    {
        $twoFactor = $this->_twoFactorMerchantService->getTwoFactorSetupDetails();

        return view('merchant/two_factor/setup', compact('twoFactor'));
    }

    public function enable(Request $request)
    {
        $data = $request->only([
            'code',
        ]);

        $result = $this->_twoFactorMerchantService->enableTwoFactor($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_twoFactorMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.profile.index')->with('success', "Two-factor authentication successfully enabled.");
    }

    public function disable(Request $request)
    {
        $data = $request->only([
            'is_enabled_two_factor',
        ]);

        $result = $this->_twoFactorMerchantService->disableTwoFactor($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_twoFactorMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Two-factor authentication successfully disabled.");
    }
}
