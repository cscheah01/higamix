<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ShopMerchantService;

class AgentSettingMerchantController extends Controller
{
    private $_shopMerchantService;

    public function __construct(ShopMerchantService $shopMerchantService)
    {
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function index()
    {
        $shop = $this->_shopMerchantService->getShopDetails();

        return view('merchant/shop_agent/setting/index', compact('shop'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'agent_connect_code',
            'is_allow_agent_direct_connect',
            'general_description',
        ]);

        $result = $this->_shopMerchantService->updateAgentSetting($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.shop_agent.setting.index')->with('success', "Agent setting successfully updated.");
    }

    public function edit()
    {
        $shop = $this->_shopMerchantService->getShopDetails();

        return view('merchant/shop_agent/setting/edit', compact('shop'));
    }
}
