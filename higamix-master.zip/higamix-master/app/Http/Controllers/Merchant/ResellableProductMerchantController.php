<?php

namespace App\Http\Controllers\Merchant;

use App\Services\Merchant\ShopMerchantService;
use App\Services\Merchant\ProductMerchantService;
use App\Services\Merchant\ResellProductMerchantService;
use App\Services\Merchant\ProductDiscountMerchantService;

class ResellableProductMerchantController extends Controller
{
    private $_productDiscountMerchantService;
    private $_resellProductMerchantService;
    private $_productMerchantService;
    private $_shopMerchantService;

    public function __construct(
        ProductDiscountMerchantService $productDiscountMerchantService,
        ResellProductMerchantService $resellProductMerchantService,
        ProductMerchantService $productMerchantService,
        ShopMerchantService $shopMerchantService
    ) {
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_resellProductMerchantService = $resellProductMerchantService;
        $this->_productMerchantService = $productMerchantService;
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function index()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        return view('merchant/resellable_product/index', compact('shopId'));
    }

    public function show($id)
    {
        $product = $this->_productMerchantService->getProductById($id);

        if ($product == false || !$product->is_open_resell) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_resellProductMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($product->id);

        $shopId = $this->_shopMerchantService->getShopId();

        return view('merchant/resellable_product/show', compact('product', 'productDiscounts', 'shopId'));
    }

    public function dataTable()
    {
        $data = $this->_resellProductMerchantService->getResellableProductDataTable();
        return $data;
    }
}
