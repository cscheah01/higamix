<?php

namespace App\Http\Controllers\Merchant;

use App\Enums\ProductType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ShopMerchantService;

class ShopMerchantController extends Controller
{
    private $_shopMerchantService;
    private $_productTypes;

    public function __construct(
        ShopMerchantService $shopMerchantService,
    ) {
        $this->_shopMerchantService = $shopMerchantService;

        $this->_productTypes = [];
        foreach (ProductType::asArray() as $key => $productType) {
            $this->_productTypes[] = [
                'value' => $key,
                'description' => ProductType::fromValue($productType)->description
            ];
        }
    }

    public function index()
    {
        $shop = $this->_shopMerchantService->getShopDetails();

        return view('merchant/my_shop/index', compact('shop'));
    }

    public function searchShopIndex()
    {
        return view('merchant/shop/search/index');
    }

    public function show($id)
    {
        $productTypes = $this->_productTypes;

        $shop = $this->_shopMerchantService->getById($id);

        if ($shop == false) {
            abort(404);
        }

        if ($shop == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/shop/show', compact('shop', 'productTypes'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'logo_image',
            'remove_image',
            'name',
            'description',
        ]);

        $result = $this->_shopMerchantService->updateShop($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.shop.index')->with('success', "Shop details successfully updated.");
    }

    public function edit()
    {
        $shop = $this->_shopMerchantService->getShopDetails();

        if ($shop == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/my_shop/edit', compact('shop'));
    }

    public function dataTable()
    {
        $data = $this->_shopMerchantService->getDataTable();
        return $data;
    }
}
