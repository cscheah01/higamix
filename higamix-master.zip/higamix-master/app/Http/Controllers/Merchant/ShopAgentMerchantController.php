<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ShopAgentMerchantService;


class ShopAgentMerchantController extends Controller
{
    private $_shopAgentMerchantService;

    public function __construct(
        ShopAgentMerchantService $shopAgentMerchantService
    ) {
        $this->_shopAgentMerchantService = $shopAgentMerchantService;
    }

    public function approvalRequestIndex()
    {
        return view('merchant/shop_agent/approval_request_index');
    }

    public function rejectedRequestIndex()
    {
        return view('merchant/shop_agent/rejected_request_index');
    }

    public function index()
    {
        return view('merchant/shop_agent/index');
    }

    public function dataTable()
    {
        $data = $this->_shopAgentMerchantService->getDataTable();
        return $data;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'is_approved',
        ]);

        $result = $this->_shopAgentMerchantService->updateShopAgentRequest($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_shopAgentMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Shop agent successfully updated.");
    }

    public function show($id)
    {
        $shopAgent = $this->_shopAgentMerchantService->getById($id);

        if ($shopAgent == false) {
            abort(404);
        }

        if ($shopAgent == null) {
            $errorMessage = implode("<br>", $this->_shopAgentMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/shop_agent/show', compact('shopAgent'));
    }
}
