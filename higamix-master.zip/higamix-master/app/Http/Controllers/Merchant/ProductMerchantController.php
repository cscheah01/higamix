<?php

namespace App\Http\Controllers\Merchant;

use App\Enums\ProductType;
use Illuminate\Http\Request;
use App\Enums\StockDelimiterType;
use App\Services\NotificationService;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ShopMerchantService;
use App\Services\Merchant\ProductMerchantService;
use App\Services\Merchant\ProductDiscountMerchantService;

class ProductMerchantController extends Controller
{
    private $_productMerchantService;
    private $_productDiscountMerchantService;
    private $_shopMerchantService;
    private $_notificationService;

    private $_productTypes;
    private $_stockDelimiterTypes;

    public function __construct(
        ProductMerchantService $productMerchantService,
        ProductDiscountMerchantService $productDiscountMerchantService,
        ShopMerchantService $shopMerchantService,
        NotificationService $notificationService
    ) {
        $this->_productMerchantService = $productMerchantService;
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_notificationService = $notificationService;


        $this->_productTypes = [];
        foreach (ProductType::asArray() as $key => $productType) {
            $this->_productTypes[] = [
                'value' => $key,
                'description' => ProductType::fromValue($productType)->description
            ];
        }

        $this->_stockDelimiterTypes = [];
        foreach (StockDelimiterType::asArray() as $key => $stockDelimiterType) {
            $this->_stockDelimiterTypes[] = [
                'value' => StockDelimiterType::fromValue($stockDelimiterType)->value,
                'description' => StockDelimiterType::fromValue($stockDelimiterType)->description
            ];
        }
    }

    public function index()
    {
        $productTypes = $this->_productTypes;
        $shopId = $this->_shopMerchantService->getShopId();

        return view('merchant/product/index', compact('productTypes', 'shopId'));
    }

    public function create()
    {
        $productTypes = $this->_productTypes;
        $stockDelimiterTypes = $this->_stockDelimiterTypes;

        return view('merchant/product/create', compact('productTypes', 'stockDelimiterTypes'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'image',
            'price',
            'description',
            'is_open_resell',
            'suggested_min_resell_price',
            'resell_cost_price',
            'product_category_id',
            'product_sub_category_id',
            'min_purchase_qty',
            'max_purchase_qty',
            'is_available',
            'product_type',
            'serials',
            'stock_delimiter_type',
            'remove_duplicate_serials',
            'custom_delimiter',
            'service_description',
            'product_discount',
        ]);
        $data['remove_duplicate_serials'] = $request->has('remove_duplicate_serials') ? true : false;

        $result = $this->_productMerchantService->createProduct($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product.show',  $result->id)->with('success', "Product successfully added.");
    }

    public function destroy($id)
    {
        $result = $this->_productMerchantService->deleteProductById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product.index')->with('success', "Product successfully deleted.");
    }

    public function edit($id)
    {
        $product = $this->_productMerchantService->getProductById($id);

        if ($product == false) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_productMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($id);
        $productTypes = $this->_productTypes;

        return view('merchant/product/edit', compact('product', 'productTypes', 'productDiscounts'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'image',
            'remove_image',
            'price',
            'resell_cost_price',
            'suggested_min_resell_price',
            'is_open_resell',
            'product_category_id',
            'product_sub_category_id',
            'min_purchase_qty',
            'max_purchase_qty',
            'service_description',
            'is_available',
            'description',
            'product_discount',
        ]);

        $result = $this->_productMerchantService->updateProduct($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product.show',  $result->id)->with('success', "Product details successfully updated.");
    }

    public function show($id)
    {
        $product = $this->_productMerchantService->getProductById($id);

        if ($product == false) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_productMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($id);

        $this->_notificationService->updateSeenByProductId($id);

        return view('merchant/product/show', compact('product', 'productDiscounts'));
    }

    public function dataTable($shopId)
    {
        $data = $this->_productMerchantService->getDataTableByShopId($shopId);

        return $data;
    }

    public function selectOption(Request $request)
    {
        $data = [
            "search_term" => $request->search_term ?? null,
            "page" => $request->page ?? 1,
        ];
        $products = $this->_productMerchantService->getSelectOption($data);

        return $products;
    }
}
