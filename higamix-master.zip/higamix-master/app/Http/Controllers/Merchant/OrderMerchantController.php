<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\OrderMerchantService;
use App\Services\Merchant\ProductDiscountMerchantService;
use App\Services\Merchant\ProductMerchantService;
use App\Services\Merchant\ShopMerchantService;

class OrderMerchantController extends Controller
{
    private $_productDiscountMerchantService;
    private $_orderMerchantService;
    private $_productMerchantService;
    private $_shopMerchantService;

    public function __construct(
        ProductDiscountMerchantService $productDiscountMerchantService,
        ProductMerchantService $productMerchantService,
        OrderMerchantService $orderMerchantService,
        ShopMerchantService $shopMerchantService
    ) {
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_productMerchantService = $productMerchantService;
        $this->_orderMerchantService = $orderMerchantService;
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function index()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        return view('merchant/purchase_product/index', compact('shopId'));
    }

    public function showProduct($id)
    {
        $product = $this->_productMerchantService->getProductById($id);

        if ($product == false) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_productMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($id);

        $parentProduct = $this->_productMerchantService->getProductById($product->parent_product_id);

        $shopId = $this->_shopMerchantService->getShopId();

        return view('merchant/purchase_product/show', compact('product', 'productDiscounts', 'parentProduct', 'shopId'));
    }

    public function dataTable()
    {
        $data = $this->_productMerchantService->getDataTable();

        return $data;
    }

    public function purchase(Request $request, $productId)
    {
        $data = $request->only([
            'qty',
        ]);
        $data['product_id'] = $productId;

        $result = $this->_orderMerchantService->createOrder($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_orderMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }
        return Redirect::route('merchant.purchase_history.show',  $result->id)->with('success', "Product successfully purchased.");
    }
}
