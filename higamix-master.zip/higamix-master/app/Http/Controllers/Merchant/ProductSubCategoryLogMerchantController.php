<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use App\Enums\NotificationType;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProductLogMerchantService;

class ProductSubCategoryLogMerchantController extends Controller
{
    private $_productLogMerchantService;
    public function __construct(
        ProductLogMerchantService $productLogMerchantService
    ) {
        $this->_productLogMerchantService = $productLogMerchantService;
    }

    public function datatable($productSubCategoryId)
    {
        $type = NotificationType::ProductSubCategory();
        $data = $this->_productLogMerchantService->getDataTable($productSubCategoryId, $type);

        return $data;
    }

    public function store(Request $request, $productSubCategoryId)
    {
        $data = $request->only([
            'content',
        ]);
        $type = NotificationType::ProductSubCategory();
        $result = $this->_productLogMerchantService->createLog($data, $productSubCategoryId, $type);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productLogMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_sub_category.show',  $result->product_sub_category_id)->with('success', "Product sub category log successfully added.");
    }
}
