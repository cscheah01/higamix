<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use App\Enums\NotificationType;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProductLogMerchantService;

class ProductLogMerchantController extends Controller
{
    private $_productLogMerchantService;
    public function __construct(
        ProductLogMerchantService $productLogMerchantService
    ) {
        $this->_productLogMerchantService = $productLogMerchantService;
    }

    public function datatable($productId)
    {
        $type = NotificationType::Product();
        $data = $this->_productLogMerchantService->getDataTable($productId, $type);

        return $data;
    }

    public function store(Request $request, $productId)
    {
        $data = $request->only([
            'content',
        ]);

        $type = NotificationType::Product();
        $result = $this->_productLogMerchantService->createLog($data, $productId, $type);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productLogMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product.show',  $result->product_id)->with('success', "Product log successfully added.");
    }
}
