<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use App\Enums\StockDelimiterType;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProductSerialMerchantService;

class ProductSerialMerchantController extends Controller
{
    private $_productSerialMerchantService;
    private $_stockDelimiterTypes;

    public function __construct(
        ProductSerialMerchantService $productSerialMerchantService
    ) {
        $this->_productSerialMerchantService = $productSerialMerchantService;

        $this->_stockDelimiterTypes = [];
        foreach (StockDelimiterType::asArray() as $key => $stockDelimiterType) {
            $this->_stockDelimiterTypes[] = [
                'value' => StockDelimiterType::fromValue($stockDelimiterType)->value,
                'description' => StockDelimiterType::fromValue($stockDelimiterType)->description
            ];
        }
    }

    public function index()
    {
        return view('merchant/product_serial/index');
    }

    public function destroy($id)
    {
        $result = $this->_productSerialMerchantService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productSerialMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_serial.index')->with('success', "Product serial key successfully deleted.");
    }

    public function show($id)
    {
        $productSerial = $this->_productSerialMerchantService->getById($id);

        if ($productSerial == false) {
            abort(404);
        }

        if ($productSerial == null) {
            $errorMessage = implode("<br>", $this->_productSerialMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/product_serial/show', compact('productSerial'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'order_id',
        ]);

        $data = $this->_productSerialMerchantService->getDataTable($filterData);

        return $data;
    }

    public function create()
    {
        $stockDelimiterTypes = $this->_stockDelimiterTypes;

        return view('merchant/product_serial/create', compact('stockDelimiterTypes'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'product_id',
            'serials',
            'stock_delimiter_type',
            'remove_duplicate_serials',
            'custom_delimiter',
        ]);
        $data['remove_duplicate_serials'] = $request->has('remove_duplicate_serials') ? true : false;

        $result = $this->_productSerialMerchantService->createProductSerial($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productSerialMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_serial.index')->with('success', "Serial key successfully added.");
    }

    public function export(Request $request)
    {
        $data = $request->only([
            'product_id',
            'is_sold',
            'is_export_all',
            'qty',
            'delete_after_export',
        ]);

        $data['is_sold'] = $data['is_sold'] == "null" ? null : $data['is_sold'];


        $result = $this->_productSerialMerchantService->exportProductSerials($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productSerialMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return $result;
    }
}
