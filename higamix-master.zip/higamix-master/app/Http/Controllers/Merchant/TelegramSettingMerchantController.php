<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ShopMerchantService;

class TelegramSettingMerchantController extends Controller
{
    private $_shopMerchantService;

    public function __construct(
        ShopMerchantService $shopMerchantService
    ) {
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function index()
    {
        $shop = $this->_shopMerchantService->getShopDetails();

        if ($shop == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/my_shop/telegram_setting/index', compact('shop'));
    }

    public function edit()
    {
        $shop = $this->_shopMerchantService->getShopDetails();

        if ($shop == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/my_shop/telegram_setting/edit', compact('shop'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'telegram_channel_username',
            'telegram_bot_api_key',
            'telegram_channel_url',
            'is_enabled_telegram_notification',
            'is_enable_telegram_send_product_link',
        ]);

        $result = $this->_shopMerchantService->updateTelegramSetting($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_shopMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.shop.telegram_setting.index')->with('success', "Telegram setting successfully updated.");
    }

    public function tutorialIndex()
    {

        return view('merchant/my_shop/telegram_setting/tutorial/index');
    }
}
