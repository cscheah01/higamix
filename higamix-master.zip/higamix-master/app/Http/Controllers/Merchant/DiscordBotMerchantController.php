<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\DiscordBotMerchantService;

class DiscordBotMerchantController extends Controller
{
    private $_discordBotMerchantService;

    public function __construct(
        DiscordBotMerchantService $discordBotMerchantService
    ) {
        $this->_discordBotMerchantService = $discordBotMerchantService;
    }

    public function index()
    {
        return view('merchant/discord_bot/index');
    }

    public function create()
    {
        return view('merchant/discord_bot/create');
    }

    public function dataTable()
    {
        $data = $this->_discordBotMerchantService->getDataTable();

        return $data;
    }

    public function show($id)
    {
        $discordBot = $this->_discordBotMerchantService->getById($id);

        if ($discordBot == false) {
            abort(404);
        }

        if ($discordBot == null) {
            $errorMessage = implode("<br>", $this->_discordBotMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/discord_bot/show', compact('discordBot'));
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'username',
            'avatar_image',
            'webhook_url',
            'is_enable_send_product_link',
        ]);

        $result = $this->_discordBotMerchantService->createDiscordBot($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_discordBotMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.discord_bot.show',  $result->id)->with('success', "Discord bot successfully added.");
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'username',
            'avatar_image',
            'remove_avatar_image',
            'webhook_url',
            'is_enable_send_product_link',
        ]);
        $result = $this->_discordBotMerchantService->updateDiscordBot($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_discordBotMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.discord_bot.show',  $result->id)->with('success', "Discord bot successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_discordBotMerchantService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_discordBotMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.discord_bot.index')->with('success', "Discord bot successfully deleted.");
    }

    public function edit($id)
    {
        $discordBot = $this->_discordBotMerchantService->getById($id);

        if ($discordBot == false) {
            abort(404);
        }

        if ($discordBot == null) {
            $errorMessage = implode("<br>", $this->_discordBotMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/discord_bot/edit', compact('discordBot'));
    }

    public function selectOption(Request $request)
    {
        $data = [
            "search_term" => $request->search_term ?? null,
            "page" => $request->page ?? 1,
        ];

        $discordBotList = $this->_discordBotMerchantService->getSelectOption($data);

        return $discordBotList;
    }

    public function tutorialIndex()
    {
        return view('merchant/discord_bot/tutorial/index');
    }
}
