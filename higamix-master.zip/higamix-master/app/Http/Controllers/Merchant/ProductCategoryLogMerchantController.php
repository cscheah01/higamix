<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use App\Enums\NotificationType;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProductLogMerchantService;

class ProductCategoryLogMerchantController extends Controller
{
    private $_productLogMerchantService;
    public function __construct(
        ProductLogMerchantService $productLogMerchantService
    ) {
        $this->_productLogMerchantService = $productLogMerchantService;
    }

    public function datatable($productCategoryId)
    {
        $type = NotificationType::ProductCategory();
        $data = $this->_productLogMerchantService->getDataTable($productCategoryId, $type);

        return $data;
    }

    public function store(Request $request, $productCategoryId)
    {
        $data = $request->only([
            'content',
        ]);
        $type = NotificationType::ProductCategory();
        $result = $this->_productLogMerchantService->createLog($data, $productCategoryId, $type);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productLogMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_category.show',  $result->product_category_id)->with('success', "Product category log successfully added.");
    }
}
