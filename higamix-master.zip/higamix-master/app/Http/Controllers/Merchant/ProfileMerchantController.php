<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProfileMerchantService;
use App\Services\Merchant\AccountVerifyRequestMerchantService;

class ProfileMerchantController extends Controller
{
    private $_profileMerchantService;
    private $_accountVerifyRequestMerchantService;


    public function __construct(
        ProfileMerchantService $profileMerchantService,
        AccountVerifyRequestMerchantService $accountVerifyRequestMerchantService
    ) {
        $this->_profileMerchantService = $profileMerchantService;
        $this->_accountVerifyRequestMerchantService = $accountVerifyRequestMerchantService;
    }

    public function index()
    {
        $profile = $this->_profileMerchantService->getProfile();

        if ($profile == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $accountVerifyRequest = $this->_accountVerifyRequestMerchantService->getAccountVerificationRequest();

        return view('merchant/account_setting/index', compact('profile', 'accountVerifyRequest'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'email',
        ]);

        $result = $this->_profileMerchantService->updateProfile($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.profile.index')->with('success', "Profile details successfully updated.");
    }

    public function resetApiSecretKey()
    {
        $result = $this->_profileMerchantService->regenerateApiSecretKey();

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.profile.index')->with('success', "API secret key successfully reset.");
    }

    public function resetApiPublicKey()
    {

        $result = $this->_profileMerchantService->regenerateApiPublicKey();

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.profile.index')->with('success', "API public key successfully reset.");
    }

    public function edit()
    {
        $profile = $this->_profileMerchantService->getProfile();

        if ($profile == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/account_setting/edit', compact('profile'));
    }

    public function editPassword()
    {
        return view('merchant/account_setting/password/edit');
    }

    public function updatePassword(Request $request)
    {
        $data = $request->only([
            'current_password',
            'password',
            'password_confirmation',
        ]);

        $result = $this->_profileMerchantService->updatePassword($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Password successfully updated.");
    }
}
