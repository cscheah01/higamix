<?php

namespace App\Http\Controllers\Merchant;

use App\Services\Merchant\ProfileMerchantService;
use App\Services\Merchant\AccountVerifyRequestMerchantService;

class AccountVerifyRequestMerchantController extends Controller
{
    private $_profileMerchantService;
    private $_accountVerifyRequestMerchantService;

    public function __construct(
        ProfileMerchantService $profileMerchantService,
        AccountVerifyRequestMerchantService $accountVerifyRequestMerchantService
    ) {
        $this->_profileMerchantService = $profileMerchantService;
        $this->_accountVerifyRequestMerchantService = $accountVerifyRequestMerchantService;
    }

    public function store()
    {
        $result = $this->_accountVerifyRequestMerchantService->createAccountVerificationRequest();

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Account verify request successfully sent.");
    }
}
