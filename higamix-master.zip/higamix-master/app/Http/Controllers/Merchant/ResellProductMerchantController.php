<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ResellProductMerchantService;
use App\Services\Merchant\ProductDiscountMerchantService;

class ResellProductMerchantController extends Controller
{
    private $_productDiscountMerchantService;
    private $_resellProductMerchantService;

    public function __construct(
        ProductDiscountMerchantService $productDiscountMerchantService,
        ResellProductMerchantService $resellProductMerchantService
    ) {
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_resellProductMerchantService = $resellProductMerchantService;
    }

    public function index()
    {
        return view('merchant/resell_product/index');
    }

    public function show($id)
    {
        $product = $this->_resellProductMerchantService->getResellProductById($id);

        if ($product == false) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_resellProductMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($product->parent_product_id);

        return view('merchant/resell_product/show', compact('product', 'productDiscounts'));
    }

    public function dataTable()
    {
        $data = $this->_resellProductMerchantService->getResellProductDataTable();

        return $data;
    }

    public function agentResellProductDatatable()
    {
        $data = $this->_resellProductMerchantService->getAgentResellProductDataTable();

        return $data;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'price',
            'product_category_id',
            'product_sub_category_id',
            'discord_bot_id',
        ]);

        $result = $this->_resellProductMerchantService->updateResellProduct($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_resellProductMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.resell_product.show',  $result->id)->with('success', "Resell product successfully updated.");
    }

    public function edit($id)
    {

        $product = $this->_resellProductMerchantService->getResellProductById($id);

        if ($product == false) {
            abort(404);
        }

        if ($product == null) {
            $errorMessage = implode("<br>", $this->_resellProductMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/resell_product/edit', compact('product'));
    }

    public function destroy($id)
    {
        $result = $this->_resellProductMerchantService->deleteResellProductById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_resellProductMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.resell_product.index')->with('success', "Resell product successfully deleted.");
    }

    public function store(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'price',
            'product_category_id',
            'product_sub_category_id',
            'discord_bot_id',
        ]);

        $result = $this->_resellProductMerchantService->createResellProduct($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_resellProductMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        if ($result->sendRequest) {
            return Redirect::route('merchant.resell_product.show',  $result->id)->with('success_confirm', "Resell request successfully sent.");
        } else {
            return Redirect::route('merchant.resell_product.show',  $result->id)->with('success', "Resell product successfully added.");
        }
    }

    public function get($id)
    {
        $resellProduct = $this->_resellProductMerchantService->getResellerResellProduct($id);

        return $resellProduct;
    }
}
