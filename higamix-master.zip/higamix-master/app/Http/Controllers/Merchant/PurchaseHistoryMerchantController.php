<?php

namespace App\Http\Controllers\Merchant;

use App\Enums\OrderStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\NotificationService;
use App\Services\Merchant\OrderMerchantService;
use App\Services\Merchant\OrderCommentMerchantService;
use App\Services\Merchant\OrderProductMerchantService;

class PurchaseHistoryMerchantController extends Controller
{
    private $_orderMerchantService;
    private $_orderProductMerchantService;
    private $_orderCommentMerchantService;
    private $_notificationService;
    private $_orderStatuses;

    public function __construct(
        OrderMerchantService $orderMerchantService,
        OrderProductMerchantService $orderProductMerchantService,
        OrderCommentMerchantService $orderCommentMerchantService,
        NotificationService $notificationService
    ) {
        $this->_orderMerchantService = $orderMerchantService;
        $this->_orderProductMerchantService = $orderProductMerchantService;
        $this->_orderCommentMerchantService = $orderCommentMerchantService;
        $this->_notificationService = $notificationService;

        $this->_orderStatuses = [];
        foreach (OrderStatus::asArray() as $key => $status) {
            $this->_orderStatuses[] = [
                'value' => $key,
                'description' => OrderStatus::fromValue($status)->description
            ];
        }
    }

    public function index()
    {
        $orderStatuses = $this->_orderStatuses;

        return view('merchant/purchase_history/index', compact('orderStatuses'));
    }

    public function show($id)
    {
        $order = $this->_orderMerchantService->getOrderById($id);
        $userId = Auth::id();

        if ($order == false || $order->user_id != $userId) {
            abort(404);
        }

        if ($order == null) {
            $errorMessage = implode("<br>", $this->_orderMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $orderProducts = $this->_orderProductMerchantService->getAllByOrderId($id);
        $orderComments = $this->_orderCommentMerchantService->getAllByOrderId($id);
        $this->_notificationService->updateSeenByOrderId($id);

        return view('merchant/purchase_history/show', compact('order', 'orderProducts', 'orderComments'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
            'id',
        ]);
        $data = $this->_orderMerchantService->getPurchaseOrderDataTable($filterData);
        return $data;
    }
}
