<?php

namespace App\Http\Controllers\Merchant;

use App\Services\LoginHistoryService;

class LoginHistoryMerchantController extends Controller
{
    private $_loginHistoryService;

    public function __construct(
        LoginHistoryService $loginHistoryService
    ) {
        $this->_loginHistoryService = $loginHistoryService;
    }

    public function index()
    {
        return view('merchant/login_history/index');
    }

    public function dataTable()
    {
        $data = $this->_loginHistoryService->getDataTable();

        return $data;
    }
}
