<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProductCategoryMerchantService;

class ProductCategoryMerchantController extends Controller
{
    private $_productCategoryMerchantService;

    public function __construct(
        ProductCategoryMerchantService $productCategoryMerchantService
    ) {
        $this->_productCategoryMerchantService = $productCategoryMerchantService;
    }

    public function index()
    {
        return view('merchant/product_category/index');
    }

    public function create()
    {
        return view('merchant/product_category/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'sub_category',
        ]);

        $result = $this->_productCategoryMerchantService->createProductCategory($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_category.show',  $result->id)->with('success', "Product category successfully added.");
    }

    public function show($id)
    {
        $productCategory = $this->_productCategoryMerchantService->getById($id);

        if ($productCategory == false) {
            abort(404);
        }

        if ($productCategory == null) {
            $errorMessage = implode("<br>", $this->_productCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/product_category/show', compact('productCategory'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
        ]);

        $result = $this->_productCategoryMerchantService->updateProductCategory($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_category.show',  $result->id)->with('success', "Product category successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_productCategoryMerchantService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_category.index')->with('success', "Product category successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_productCategoryMerchantService->getDataTable();

        return $data;
    }


    public function edit($id)
    {
        $productCategory = $this->_productCategoryMerchantService->getById($id);

        if ($productCategory == false) {
            abort(404);
        }

        if ($productCategory == null) {
            $errorMessage = implode("<br>", $this->_productCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/product_category/edit', compact('productCategory'));
    }

    public function selectOption(Request $request)
    {
        $data = [
            "search_term" => $request->search_term ?? null,
            "page" => $request->page ?? 1,
        ];

        $results = $this->_productCategoryMerchantService->getSelectOption($data);

        return $results;
    }
}
