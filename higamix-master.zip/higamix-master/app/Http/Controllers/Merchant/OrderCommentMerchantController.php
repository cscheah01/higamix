<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\OrderCommentMerchantService;

class OrderCommentMerchantController extends Controller
{
    private $_orderCommentMerchantService;

    public function __construct(
        OrderCommentMerchantService $orderCommentMerchantService
    ) {
        $this->_orderCommentMerchantService = $orderCommentMerchantService;
    }

    public function store(Request $request, $id)
    {
        $data = $request->only([
            'content',
        ]);

        $result = $this->_orderCommentMerchantService->createOrderComment($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_orderCommentMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Order comment successfully save.");
    }
}
