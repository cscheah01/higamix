<?php

namespace App\Http\Controllers\Merchant;

use App\Services\ZixiPayService;
use App\Http\Controllers\Controller;
use App\Services\PlatformSettingService;

class ZixiPayMerchantController extends Controller
{
    private $_zixiPayService;
    private $_platformSettingService;

    public function __construct(
        ZixiPayService $zixiPayService,
        PlatformSettingService $platformSettingService
    ) {
        $this->_zixiPayService = $zixiPayService;
        $this->_platformSettingService = $platformSettingService;
    }

    public function topUp()
    {
        $wallet = $this->_zixiPayService->getUserWallet();

        if ($wallet == null) {
            $errorMessage = implode("<br>", $this->_zixiPayService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $minTopUpAmount = $this->_platformSettingService->getMinimumTopUpAmount();

        return view('merchant/wallet/zixi_pay/top_up', compact('wallet', 'minTopUpAmount'));
    }
}
