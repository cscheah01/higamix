<?php

namespace App\Http\Controllers\Merchant;

use App\Enums\OrderStatus;
use Illuminate\Http\Request;
use App\Services\NotificationService;
use App\Services\Merchant\OrderMerchantService;
use App\Services\Merchant\OrderCommentMerchantService;
use App\Services\Merchant\OrderProductMerchantService;
use App\Services\Merchant\ShopMerchantService;

class SalesHistoryMerchantController extends Controller
{
    private $_orderMerchantService;
    private $_orderProductMerchantService;
    private $_orderCommentMerchantService;
    private $_notificationService;
    private $_orderStatuses;
    private $_shopMerchantService;

    public function __construct(
        OrderMerchantService $orderMerchantService,
        OrderProductMerchantService $orderProductMerchantService,
        OrderCommentMerchantService $orderCommentMerchantService,
        NotificationService $notificationService,
        ShopMerchantService $shopMerchantService,
    ) {
        $this->_orderMerchantService = $orderMerchantService;
        $this->_orderProductMerchantService = $orderProductMerchantService;
        $this->_orderCommentMerchantService = $orderCommentMerchantService;
        $this->_notificationService = $notificationService;
        $this->_shopMerchantService = $shopMerchantService;

        $this->_orderStatuses = [];
        foreach (OrderStatus::asArray() as $key => $status) {
            $this->_orderStatuses[] = [
                'value' => $key,
                'description' => OrderStatus::fromValue($status)->description
            ];
        }
    }

    public function index()
    {
        $orderStatuses = $this->_orderStatuses;

        return view('merchant/sales_history/index', compact('orderStatuses'));
    }

    public function show($id)
    {
        $order = $this->_orderMerchantService->getOrderById($id);

        $shopId = $this->_shopMerchantService->getShopId();

        if ($order == false || $order->shop_id != $shopId) {
            abort(404);
        }

        if ($order == null) {
            $errorMessage = implode("<br>", $this->_orderMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $orderProducts = $this->_orderProductMerchantService->getAllByOrderId($id);

        $orderComments = $this->_orderCommentMerchantService->getAllByOrderId($id);

        $this->_notificationService->updateSeenByOrderId($id);

        return view('merchant/sales_history/show', compact('order', 'orderProducts', 'orderComments'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
            'id',
        ]);
        $data = $this->_orderMerchantService->getSalesOrderDataTable($filterData);
        return $data;
    }

    public function dailyTotalProfit($date)
    {
        $data['date'] = $date;
        $totalProfit = $this->_orderMerchantService->getDailyTotalProfit($data);

        return $totalProfit;
    }

    public function monthlyTotalProfit($year, $month)
    {
        $data['year'] = $year;
        $data['month'] = $month;

        $totalProfit = $this->_orderMerchantService->getMonthlyTotalProfit($data);

        return $totalProfit;
    }

    public function yearlyTotalProfit($year)
    {
        $data['year'] = $year;

        $totalProfit = $this->_orderMerchantService->getYearlyTotalProfit($data);

        return $totalProfit;
    }
}
