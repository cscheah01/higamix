<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\Merchant\ProductSubCategoryMerchantService;

class ProductSubCategoryMerchantController extends Controller
{
    private $_productSubCategoryMerchantService;

    public function __construct(
        ProductSubCategoryMerchantService $productSubCategoryMerchantService
    ) {
        $this->_productSubCategoryMerchantService = $productSubCategoryMerchantService;
    }

    public function index()
    {
        return view('merchant/product_sub_category/index');
    }

    public function create()
    {
        return view('merchant/product_sub_category/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'product_category_id',
            'product_sub_category',
        ]);

        $result = $this->_productSubCategoryMerchantService->createProductSubCategory($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productSubCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_sub_category.index')->with('success', "Product sub category successfully added.");
    }

    public function show($id)
    {
        $productSubCategory = $this->_productSubCategoryMerchantService->getById($id);

        if ($productSubCategory == false) {
            abort(404);
        }

        if ($productSubCategory == null) {
            $errorMessage = implode("<br>", $this->_productSubCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/product_sub_category/show', compact('productSubCategory'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
        ]);

        $result = $this->_productSubCategoryMerchantService->updateProductSubCategory($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productSubCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_sub_category.show',  $result->id)->with('success', "Product sub category successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_productSubCategoryMerchantService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_productSubCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('merchant.product_sub_category.index')->with('success', "Product sub category successfully deleted.");
    }

    public function dataTable()
    {
        $data = $this->_productSubCategoryMerchantService->getDataTable();

        return $data;
    }


    public function edit($id)
    {
        $productSubCategory = $this->_productSubCategoryMerchantService->getById($id);

        if ($productSubCategory == false) {
            abort(404);
        }

        if ($productSubCategory == null) {
            $errorMessage = implode("<br>", $this->_productSubCategoryMerchantService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('merchant/product_sub_category/edit', compact('productSubCategory'));
    }

    public function selectOption(Request $request)
    {
        $data = [
            "search_term" => $request->search_term ?? null,
            "page" => $request->page ?? 1,
            "product_main_category_id" => $request->product_main_category_id ?? null
        ];

        $productSubCategoryList = $this->_productSubCategoryMerchantService->getSelectOption($data);

        return $productSubCategoryList;
    }
}
