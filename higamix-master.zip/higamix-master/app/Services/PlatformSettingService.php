<?php

namespace App\Services;

use App\Enums\SettingMeta;
use Exception;
use App\Repositories\SettingRepository;

class PlatformSettingService extends Service
{
    protected $_settingRepository;

    public function __construct(
        SettingRepository $settingRepository,
    ) {
        $this->_settingRepository = $settingRepository;
    }

    public function getMinimumTopUpAmount()
    {
        try {
            $platformSetting = $this->_settingRepository->getByMetaKey(SettingMeta::fromValue(SettingMeta::MinimumTopUpAmount)->key);



            return number_format(floatval($platformSetting->meta_value), 2, '.', '');
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get platform minimum top up amount.");

            return null;
        }
    }

    public function getMinimumWithdrawAmount()
    {
        try {
            $platformSetting = $this->_settingRepository->getByMetaKey(SettingMeta::fromValue(SettingMeta::MinimumWithdrawAmount)->key);

            return number_format(floatval($platformSetting->meta_value), 2, '.', '');
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get platform minimum withdraw amount.");

            return null;
        }
    }
}
