<?php

namespace App\Services;

use Exception;
use App\Enums\NotificationType;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\ProductRepository;
use Yajra\DataTables\Facades\DataTables;
use App\Repositories\ProductLogRepository;
use App\Repositories\NotificationRepository;
use App\Services\Merchant\ShopMerchantService;

class NotificationService extends Service
{
    protected $_notificationRepository;
    protected $_productLogRepository;
    protected $_productRepository;
    protected $_shopMerchantService;

    public function __construct(
        NotificationRepository $notificationRepository,
        ProductLogRepository $productLogRepository,
        ProductRepository $productRepository,
        ShopMerchantService $shopMerchantService
    ) {
        $this->_notificationRepository = $notificationRepository;
        $this->_productLogRepository = $productLogRepository;
        $this->_productRepository = $productRepository;
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function createNotification($data)
    {

        DB::beginTransaction();

        try {
            $notification = $this->_notificationRepository->save($data);
            DB::commit();
            return $notification;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add notification.");

            DB::rollBack();
            return null;
        }
    }

    public function createNewLogNotification($log, $type)
    {
        DB::beginTransaction();

        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $userIdList = [];
            if ($type == NotificationType::Product()) {
                $products = $this->_productRepository->getAllByParentProductId($log->product_id);

                $data['product_id'] = $log->product_id;

                foreach ($products as $product) {
                    $userIdList[] = $product->shop->user_id;
                }
            } else if ($type == NotificationType::ProductCategory()) {

                $products = $this->_productRepository->getAllByProductCategoryId($log->product_category_id, $shopId);

                $data['product_category_id'] = $log->product_category_id;
                foreach ($products as $product) {
                    $userIdList[] = $product->reseller_user_id;
                }
            } else if ($type == NotificationType::ProductSubCategory()) {
                $products = $this->_productRepository->getAllByProductSubCategoryId($log->product_sub_category_id, $shopId);

                $data['product_sub_category_id'] = $log->product_sub_category_id;

                foreach ($products as $product) {
                    $userIdList[] = $product->reseller_user_id;
                }
            }

            $data['content'] = $log->content;

            $notification = $this->_notificationRepository->bulkSave($data, $userIdList);

            DB::commit();
            return $notification;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add notification.");

            DB::rollBack();
            return null;
        }
    }

    public function updateSeenByProductId($id)
    {
        DB::beginTransaction();

        try {
            $data['product_id'] = $id;
            $data['user_id'] = Auth::id();
            $data['is_seen'] = true;

            $this->_notificationRepository->update($data);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update notification.");

            DB::rollBack();
            return null;
        }
    }

    public function updateSeenById($id)
    {
        DB::beginTransaction();

        try {
            $data['id'] = $id;
            $data['user_id'] = Auth::id();
            $data['is_seen'] = true;

            $this->_notificationRepository->update($data);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update notification.");

            DB::rollBack();
            return null;
        }
    }

    public function updateSeenByOrderId($id)
    {
        DB::beginTransaction();

        try {
            $data['order_id'] = $id;
            $data['user_id'] = Auth::id();
            $data['is_seen'] = true;
            $this->_notificationRepository->update($data);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update notification.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('notifications')
            ->leftjoin('products', 'notifications.product_id', '=', 'products.id')
            ->leftjoin('shops', 'products.shop_id', '=', 'shops.id')
            ->leftJoin('orders', 'notifications.order_id', '=', 'orders.id')
            ->select([
                'notifications.id',
                'notifications.content',
                'notifications.created_at',
                'notifications.is_seen',
                'notifications.product_category_id',
                'notifications.product_sub_category_id',
                'products.id as product_id',
                'orders.id as order_id',
                'orders.user_id as order_user_id',
            ])
            ->where('notifications.user_id', '=', Auth::id());
        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function markAllNotificationAsSeen($data)
    {
        DB::beginTransaction();

        try {
            $data['user_id'] = Auth::id();
            $this->_notificationRepository->update($data);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to mark all notification as seen.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        try {
            $notification = $this->_notificationRepository->getById($id);

            if (
                $notification == null
            ) {
                return false;
            }

            return $notification;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get notification details.");

            return null;
        }
    }
}
