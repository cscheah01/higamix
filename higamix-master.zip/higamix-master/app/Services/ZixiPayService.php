<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\WalletRepository;
use App\Services\PlatformSettingService;
use Illuminate\Support\Facades\Validator;
use App\Services\Merchant\WalletMerchantService;
use App\Repositories\WalletTransactionRepository;

class ZixiPayService extends Service
{
    private $_uid;
    private $_apiKey;
    private $_ipnKey;
    protected $_walletTransactionRepository;
    protected $_walletRepository;
    private $_platformSettingService;
    private $_walletMerchantService;

    public function __construct(
        WalletTransactionRepository $walletTransactionRepository,
        WalletRepository $walletRepository,
        PlatformSettingService $platformSettingService,
        WalletMerchantService $walletMerchantService
    ) {
        $this->_uid = config('services.zixipay.uid');
        $this->_apiKey = config('services.zixipay.api_key');
        $this->_ipnKey = config('services.zixipay.ipn_key');

        $this->_walletTransactionRepository = $walletTransactionRepository;
        $this->_walletRepository = $walletRepository;
        $this->_platformSettingService = $platformSettingService;
        $this->_walletMerchantService = $walletMerchantService;
    }

    function zixiPayApiCall($endPoint, $params)
    {
        $apiUrl = 'https://api.zixipay.com/apiv2/';

        $payload = http_build_query($params);

        $signature = hash_hmac(
            'sha256',
            $payload,
            $this->_apiKey
        );

        $params['sig'] = $signature;

        $ch = curl_init();

        curl_setopt_array(
            $ch,
            array(
                CURLOPT_POST            => true,
                CURLOPT_HEADER            => false,
                CURLOPT_HTTPHEADER        => array('Content-Type: application/x-www-form-urlencoded'),
                CURLOPT_ENCODING        => 'gzip',
                CURLOPT_RETURNTRANSFER        => true,
                CURLOPT_URL            => $apiUrl . $endPoint,
                CURLOPT_POSTFIELDS        => http_build_query($params)
            )
        );

        $result = curl_exec($ch);

        curl_close($ch);

        if (!$result) {
            return false;
        }

        //demo data for debug
        // $result = '{
        //     "result":"ok",
        //     "payload":[
        //         {
        //         "name":"Tether TRC20",
        //         "code":"USDT",
        //         "address":"TH53ejapLDKDFxxqP2RREfxCNtW26gFKeb",
        //         "qr-code":"https://qrg.zixipay.com/api/qr.php?data=TH53ejapLDKDFxxqP2RREfxCNtW26gFKeb",
        //         "confirm":20
        //         },
        //         {
        //         "name":"Tether ERC20",
        //         "code":"USDT",
        //         "address":"0x0ed8991afc868c45ffbcd4afdf7ebc273cf38ed2",
        //         "qr-code":"https://qrg.zixipay.com/api/qr.php?data=0x0ed8991afc868c45ffbcd4afdf7ebc273cf38ed2",
        //         "confirm":3
        //         },
        //         {
        //         "name":"Tether OMNI",
        //         "code":"USDT",
        //         "address":"1PkYiGCF3zVif5vm1ogXYuvtGaK3p7qLgK",
        //         "qr-code":"https://qrg.zixipay.com/api/qr.php?data=1PkYiGCF3zVif5vm1ogXYuvtGaK3p7qLgK",
        //         "confirm":1
        //         }
        //     ]
        // }';

        // $result = '{
        //     "result":"ok",
        //     "payload":[
        //         {
        //         "name":"Zixi Dollar",
        //         "code":"USDZ",
        //         "balance":"0.00"
        //         },
        //         {
        //         "name":"Zixi Euro",
        //         "code":"EURZ",
        //         "balance":"0.00"
        //         },
        //         {
        //         "name":"Litecoin",
        //         "code":"LTC",
        //         "balance":"0.00000000"
        //         },
        //         {
        //         "name":"Bitcoin",
        //         "code":"BTC",
        //         "balance":"560.00000000"
        //         },
        //         {
        //         "name":"Ethereum",
        //         "code":"ETH",
        //         "balance":"0.00000000"
        //         },
        //         {
        //         "name":"Tether",
        //         "code":"USDT",
        //         "balance":"15520.00"
        //         }
        //     ]
        // }';

        return json_decode($result, true);
    }

    public function getUserWallet()
    {
        try {
            $endPoint = "getpaymentwallet";

            $userId = Auth::id();
            $userPlatformWallet = $this->_walletMerchantService->getWalletByUserId($userId);

            $params = array(
                'currency'  => 'USDT',
                'ref'       => $userPlatformWallet['id'],
                'uid'       => $this->_uid,
                'ts'        => time()
            );

            $response = $this->zixiPayApiCall($endPoint, $params);

            if (!$response || empty($response['result'])) {
                throw new Exception();
            }

            foreach ($response['payload'] as $payload) {
                if ($payload['name'] == "Tether TRC20") {
                    $wallet["wallet_address"] = $payload['address'];
                    $wallet["qr"] = $payload['qr-code'];
                }
            }

            if (empty($wallet)) {
                throw new Exception();
            }

            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet details.");

            return null;
        }
    }


    public function getWalletBalance()
    {
        try {
            $endPoint = "getbalances";

            $params = array(
                'uid'       => $this->_uid,
                'ts'        => time()
            );

            $response = $this->zixiPayApiCall($endPoint, $params);

            if (!$response || empty($response['result'])) {
                throw new Exception();
            }


            foreach ($response['payload'] as $payload) {
                if ($payload['code'] == "USDT") {
                    $balance = $payload['balance'];
                }
            }

            if (empty($balance)) {
                throw new Exception();
            }

            return $balance;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet balance.");

            return null;
        }
    }


    public function handleCallback($data)
    {
        DB::beginTransaction();

        try {
            $signature = $data['sig'] ?? null;

            $post = http_build_query($_POST);
            $payload = explode('&sig=', $post)[0];


            if (!isset($signature) || hash_hmac('sha256', $payload, $this->_ipnKey) != $signature) {
                throw new Exception();
            }

            //demo data for debug
            // $data = array(
            //     'ref'        => '1',
            //     'wallet'    => 'TQmB7S6GtXcwoR64ZbFmXFjSa3EgBz9nqf',
            //     'amount'    => '500',
            //     'fee'        => '5',
            //     'currency'    => 'USDT',
            //     'txid'        => '49af4314ab3adcb9b04dc182cb0dd815ecdd01dec1216e856a4b8cb07fc098f4',
            //     'zxid'        => '1TsDABsCDEFGHIJsKLMNOPQRST',
            //     'time'        => time()
            // );


            //check if this IS not a duplicate callback by making sure no previous transaction has been processed with the same zxid (ZixiPay transaction id)
            $walletTransaction = $this->_walletTransactionRepository->getByZixiPayTransactionId($data['zxid']);

            if ($walletTransaction != null) {
                return null;
            }


            //get wallet by wallet id (ref from zixi pay)
            $wallet = $this->_walletRepository->getById($data['ref']);

            if ($wallet == null) {
                throw new Exception();
            }


            //get platform minimum top up amount
            $platformMinTopUpAmount = $this->_platformSettingService->getMinimumTopUpAmount();


            //update wallet amount
            $isDebitActiveBalance = false;
            $totalCreditInactiveAmount = 0;
            $totalDebitActiveAmount = 0;
            if ($wallet['inactive_balance'] + $data['amount'] >= $platformMinTopUpAmount) {
                $isDebitActiveBalance = true;
                $totalCreditInactiveAmount = $wallet['inactive_balance'];
                $totalDebitActiveAmount = $wallet['inactive_balance'] + $data['amount'];

                $wallet['balance'] += $totalDebitActiveAmount;

                $wallet['inactive_balance'] = 0.00;
            } else {
                $wallet['inactive_balance'] += $data['amount'];
            }

            $wallet = $this->_walletRepository->update($wallet, $data['ref']);


            //insert wallet transaction
            $walletTransaction['wallet_id'] = $data['ref'];
            $walletTransaction['debit'] = $data['amount'];
            $walletTransaction['balance'] = $wallet['balance'];

            if ($isDebitActiveBalance) {
                $walletTransaction['description'] = "Received top up " . number_format($data['amount'], 2, '.', '') . " USDT into wallet. Active Balance: +" . number_format($totalDebitActiveAmount, 2, '.', '') . " USDT, Inactive Balance: -" . number_format($totalCreditInactiveAmount, 2, '.', '') . " USDT";
            } else {
                $walletTransaction['description'] = "Received top up " . number_format($data['amount'], 2, '.', '') . " USDT into wallet. Active Balance: +" . number_format($totalDebitActiveAmount, 2, '.', '') . " USDT, Inactive Balance: +" . number_format($data['amount'], 2, '.', '') . " USDT";
            }

            $walletTransaction['zixi_pay_transaction_id'] = $data['zxid'];
            $walletTransaction['api_response'] = json_encode($data);

            $walletTransaction = $this->_walletTransactionRepository->save($walletTransaction);


            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to handle Zixi pay IPN callback.");

            DB::rollBack();
            return null;
        }
    }


    public function withdraw($data)
    {
        try {
            $validator = Validator::make($data, [
                'amount' => 'required|numeric|min:0',
                'withdraw_address' => 'required|string'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }


            $endPoint = "withdraw";

            $params = array(
                'amount'  => $data['amount'],
                'currency'  => 'USDT',
                'recipient'  => $data['withdraw_address'],
                'feein'  => 0,
                'uid'       => $this->_uid,
                'ts'        => time()
            );

            $response = $this->zixiPayApiCall($endPoint, $params);

            if (!$response || empty($response['result'])) {
                throw new Exception();
            }


            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to make withdrawal.");

            return null;
        }
    }
}
