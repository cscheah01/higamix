<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Repositories\ShopRepository;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use App\Services\LoginHistoryService;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Repositories\InviteCodeRepository;
use App\Services\Merchant\WalletMerchantService;

class AuthService extends Service
{
    protected $_userRepository;
    protected $_inviteCodeRepository;
    protected $_shopRepository;
    protected $_loginHistoryService;
    protected $_walletMerchantService;

    public function __construct(
        UserRepository $userRepository,
        InviteCodeRepository $inviteCodeRepository,
        ShopRepository $shopRepository,
        LoginHistoryService $loginHistoryService,
        WalletMerchantService $walletMerchantService,
    ) {
        $this->_userRepository = $userRepository;
        $this->_inviteCodeRepository = $inviteCodeRepository;
        $this->_shopRepository = $shopRepository;
        $this->_loginHistoryService = $loginHistoryService;
        $this->_walletMerchantService = $walletMerchantService;
    }

    public function loginUser($data)
    {
        try {
            $validator = Validator::make($data, [
                'email' => 'required',
                'password' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            if (auth()->attempt(array('email' => $data['email'], 'password' => $data['password']))) {

                $loginHistory = $this->_loginHistoryService->createLoginHistory();
                return true;
            } else {
                array_push($this->_errorMessage, 'Invalid email or password.');

                return null;
            }
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to login.");

            return null;
        }
    }

    public function logoutUser()
    {
        try {
            Auth::logout();
            Session::flush();

            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to logout.");

            return null;
        }
    }

    public function registerUser($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'user.email' => 'required|string|email|max:255|unique:users,email',
                'user.password' => 'required|confirmed|min:8',
                'shop.name' => 'required|string|max:255',
                'invite_code' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $inviteCode = $this->_inviteCodeRepository->getByCode($data['invite_code']);

            if ($inviteCode == null || $inviteCode->is_used == 1) {
                array_push($this->_errorMessage, "Invite code is invalid or has been used.");

                return null;
            }

            $google2fa = app('pragmarx.google2fa');
            $data['user']['google_2fa_secret'] = $google2fa->generateSecretKey();
            $data['user']['api_secret_key'] = Str::random(5) . Str::uuid() . Str::random(5);
            $data['user']['api_public_key'] = Str::random(5) . Str::uuid() . Str::random(5);
            $user = $this->_userRepository->save($data['user']);
            $user->assignRole('merchant');

            $data['shop']['user_id'] = $user->id;
            $shop = $this->_shopRepository->save($data['shop']);

            $inviteCode->is_used = true;
            $inviteCode->used_by = $user->id;
            $inviteCode = $this->_inviteCodeRepository->update($inviteCode, $inviteCode->id);

            $wallet = $this->_walletMerchantService->createWalletByUserId($user->id);


            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to register.");

            DB::rollBack();
            return null;
        }
    }
}
