<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Str;
use App\Mail\ResetPasswordRequest;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Mail;
use App\Services\PasswordResetService;
use Illuminate\Support\Facades\Validator;

class ForgetPasswordService extends Service
{
    protected $_userRepository;
    protected $_passwordResetService;

    public function __construct(
        UserRepository $userRepository,
        PasswordResetService $passwordResetService
    ) {
        $this->_userRepository = $userRepository;
        $this->_passwordResetService = $passwordResetService;
    }

    public function forgotPassword($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'email' => 'required|email',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $user = $this->_userRepository->getByEmail($data['email']);

            if ($user != null) {
                $data['user_id'] = $user->id;
                $data['token'] = Str::random(30);
                $data['expired_minutes'] = $this->_passwordResetService->_expiredMinutes;

                $passwordReset = $this->_passwordResetService->createPasswordReset($data);

                Mail::to($data['email'])->send(new ResetPasswordRequest($data));
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to send forgot password email.");
            DB::rollBack();
            return null;
        }
    }
}
