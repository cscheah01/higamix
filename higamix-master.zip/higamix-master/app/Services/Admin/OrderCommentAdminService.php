<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Services\NotificationService;
use Illuminate\Support\Facades\Validator;
use App\Repositories\OrderCommentRepository;


class OrderCommentAdminService extends Service
{
    protected $_orderCommentRepository;
    protected $_notificationAdminService;

    public function __construct(
        OrderCommentRepository $orderCommentRepository,
        NotificationService $notificationService
    ) {
        $this->_orderCommentRepository = $orderCommentRepository;
        $this->_notificationService = $notificationService;
    }

    public function getAllByOrderId($orderId)
    {
        try {
            $orderComments = $this->_orderCommentRepository->getAllByOrderId($orderId);

            return $orderComments;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get order comments.");

            return null;
        }
    }

    public function createOrderComment($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'content' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $data['order_id'] = $id;
            $data['user_id'] = Auth::id();
            $orderComment = $this->_orderCommentRepository->save($data);

            $commenterEmail = Auth::user()->email;

            $data['notification']['order_id'] = $data['order_id'];
            $data['notification']['content'] = $commenterEmail . ' : ' . $data['content'];
            $data['notification']['user_id'] = $orderComment->order->shop->user_id; //seller

            $this->_notificationService->createNotification($data['notification']); //notification for seller

            $data['notification']['user_id'] = $orderComment->order->user_id; //buyer
            $this->_notificationService->createNotification($data['notification']); //notification for buyer

            DB::commit();
            return $orderComment;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add order comment.");

            DB::rollBack();
            return null;
        }
    }
}
