<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\ProductRepository;
use App\Services\Admin\ShopAdminService;


class ResellProductAdminService extends Service
{
    protected $_productRepository;
    protected $_shopAdminService;

    public function __construct(
        ProductRepository $productRepository,
        ShopAdminService $shopAdminService
    ) {
        $this->_productRepository = $productRepository;
        $this->_shopMerchantService = $shopAdminService;
    }

    public function getShopResellProductDataTable($shopId)
    {
        $data = DB::table('products')
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftJoin('shop_agents', 'parent_product.shop_id', '=', 'shop_agents.shop_id')
            ->leftJoin('shops', 'parent_product.shop_id', '=', 'shops.id')
            ->leftJoin('shops as agent_shops', 'products.shop_id', '=', 'agent_shops.id')
            ->select([
                'products.id',
                'products.name',
                'agent_shops.id as agent_shop_id',
                'agent_shops.name as agent_shop_name',
                DB::raw('(parent_product.resell_cost_price + products.resell_profit) as price')
            ])
            ->where('products.is_resell', '=', true)
            ->where('products.deleted_at', '=', null)
            ->where('shops.id', '=', $shopId)
            ->whereColumn('shop_agents.is_waiting_approved', '!=', 'shop_agents.is_approved');


        $result = DataTables::of($data)
            ->make();

        return $result;
    }
}
