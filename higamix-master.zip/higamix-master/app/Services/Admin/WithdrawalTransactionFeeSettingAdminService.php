<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\WithdrawalTransactionFeeRepository;

class WithdrawalTransactionFeeSettingAdminService extends Service
{
    protected $_withdrawalTransactionFeeRepository;

    public function __construct(
        WithdrawalTransactionFeeRepository $withdrawalTransactionFeeRepository

    ) {
        $this->_withdrawalTransactionFeeRepository = $withdrawalTransactionFeeRepository;
    }

    public function getAll()
    {
        try {
            $withdrawalTransactionFees = $this->_withdrawalTransactionFeeRepository->getAll();

            return $withdrawalTransactionFees;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get withdrawal transaction fee setting details.");
            return null;
        }
    }

    public function updateWithdrawalTransactionFeesSetting($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'withdrawal_transaction_fees' => 'array|nullable',
                'withdrawal_transaction_fees.*.amount_more_than_equal' => 'required|numeric|between: 0.00,99999999999.99',
                'withdrawal_transaction_fees.*.fee' => 'required|numeric|between: 0.00,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            //sort to ascending
            $columns = array_column($data['withdrawal_transaction_fees'], 'amount_more_than_equal');
            array_multisort($columns, SORT_ASC, $data['withdrawal_transaction_fees']);

            $withdrawalTransactionFeeSetting = $this->_withdrawalTransactionFeeRepository->deleteAll();

            if (!empty($data['withdrawal_transaction_fees'])) {
                $withdrawalTransactionFeeSetting =  $this->_withdrawalTransactionFeeRepository->bulkSave($data['withdrawal_transaction_fees']);
            }

            DB::commit();
            return $withdrawalTransactionFeeSetting;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update withdrawal transaction fee setting.");

            DB::rollBack();
            return null;
        }
    }
}
