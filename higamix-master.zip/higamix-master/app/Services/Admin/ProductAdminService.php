<?php

namespace App\Services\Admin;

use Exception;

use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\ProductRepository;

class ProductAdminService extends Service
{
    protected $_productRepository;

    public function __construct(
        ProductRepository $productRepository
    ) {
        $this->_productRepository = $productRepository;
    }

    public function getDataTable()
    {
        $data = DB::table('products')
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftjoin('shops', 'products.shop_id', '=', 'shops.id')
            ->select([
                'products.id',
                'products.price',
                'products.is_available',
                'products.is_open_resell',
                'products.name',
                'products.created_at',
                'products.product_category_id',
                'products.is_resell',
                'shops.id as shop_id',
                'shops.name as shop_name',
                DB::raw('(CASE
                         WHEN products.parent_product_id IS NULL THEN products.product_type
                         WHEN products.parent_product_id IS NOT NULL THEN parent_product.product_type
                         END) as product_type'),
                DB::raw('(CASE
                         WHEN products.parent_product_id IS NULL THEN products.product_type
                         WHEN products.parent_product_id IS NOT NULL THEN parent_product.product_type
                         END) as product_type_key'),
                DB::raw('
                    CASE
                    WHEN
                        products.is_resell
                    THEN
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.parent_product_id AND is_sold = 0)
                    ELSE
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.id AND is_sold = 0)
                    END
                    as stock_qty'),
            ])
            ->where('products.deleted_at', '=', null);

        $result = DataTables::of($data)
            ->filterColumn('product_type', function ($query, $keyword) {
                $query->whereRaw("(CASE
                            WHEN products.parent_product_id IS NULL THEN products.product_type
                            WHEN products.parent_product_id IS NOT NULL THEN parent_product.product_type
                            END) = ?", ["{$keyword}"]);
            })
            ->editColumn('product_type', '{{App\Enums\ProductType::fromkey($product_type)->description}}')
            ->make();

        return $result;
    }
    public function getById($id)
    {
        try {
            $product = $this->_productRepository->getById($id);

            if ($product == null) {
                return false;
            }

            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product details.");

            return null;
        }
    }
}
