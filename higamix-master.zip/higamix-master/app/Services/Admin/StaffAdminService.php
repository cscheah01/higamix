<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Illuminate\Support\Str;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Validator;

class StaffAdminService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function createStaff($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'email' => 'required|string|email|max:255|unique:users,email',
                'password' => 'required|confirmed|min:8',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $google2fa = app('pragmarx.google2fa');
            $data['google_2fa_secret'] = $google2fa->generateSecretKey();
            $data['api_secret_key'] = Str::random(5) . Str::uuid() . Str::random(5);
            $data['api_public_key'] = Str::random(5) . Str::uuid() . Str::random(5);

            $staff = $this->_userRepository->save($data);
            $staff->assignRole('admin');

            DB::commit();
            return $staff;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add staff.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $data = DB::table('users')
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->select(['users.id', 'users.email', 'users.created_at', 'users.is_enabled_two_factor'])
            ->where('users.deleted_at', '=', null)
            ->where('roles.name', '=', 'admin');

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $staff = $this->_userRepository->getById($id);

            if ($staff != null && $staff->hasRole('admin') != true) {
                return false;
            }

            return $staff;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get staff details.");

            return null;
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $staff = $this->_userRepository->deleteById($id);

            DB::commit();
            return $staff;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete staff.");

            DB::rollBack();
            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'email' => 'required|string|email|max:255|unique:users,email,' . $id,
                'password' => 'nullable|confirmed|min:8'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $staff = $this->_userRepository->update($data, $id);

            DB::commit();
            return $staff;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update staff details.");

            DB::rollBack();
            return null;
        }
    }
}
