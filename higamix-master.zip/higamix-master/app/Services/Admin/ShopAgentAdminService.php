<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\ShopAgentRepository;

class ShopAgentAdminService extends Service
{
    protected $_shopAgentRepository;

    public function __construct(
        ShopAgentRepository $shopAgentRepository
    ) {
        $this->_shopAgentRepository = $shopAgentRepository;
    }

    public function getDataTable()
    {
        $data = DB::table('shop_agents')
            ->leftjoin('shops as agent', 'shop_agents.agent_shop_id', '=', 'agent.id')
            ->leftJoin('shops', 'shop_agents.shop_id', '=', 'shops.id')
            ->select([
                'shop_agents.id',
                'shops.id as shop_id',
                'shops.name as shop_name',
                'agent.id as agent_id',
                'agent.name as agent_name',
                'shop_agents.is_waiting_approved',
                'shop_agents.is_approved',
                'shop_agents.created_at',
            ]);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $shopAgent = $this->_shopAgentRepository->getById($id);

            if ($shopAgent == null) {
                return false;
            }

            return $shopAgent;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get shop agent details.");

            return null;
        }
    }
}
