<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;



class LoginHistoryAdminService extends Service
{

    public function getDataTable()
    {
        $data = DB::table('login_histories')
            ->select([
                'user_id',
                'ip_address',
                'country',
                'created_at'
            ]);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }
}
