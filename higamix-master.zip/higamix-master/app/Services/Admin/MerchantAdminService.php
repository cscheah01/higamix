<?php

namespace App\Services\Admin;

use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Validator;
use App\Repositories\AccountVerifyRequestRepository;

class MerchantAdminService extends Service
{
    protected $_userRepository;
    protected $_accountVerifyRequestRepository;

    public function __construct(
        UserRepository $userRepository,
        AccountVerifyRequestRepository $accountVerifyRequestRepository
    ) {
        $this->_userRepository = $userRepository;
        $this->_accountVerifyRequestRepository = $accountVerifyRequestRepository;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('users')
            ->leftjoin('shops', 'users.id', '=', 'shops.user_id')
            ->leftJoin('wallets', 'users.id', '=', 'wallets.user_id')
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->select([
                'users.id',
                'users.email',
                'users.created_at',
                'users.is_verified',
                'shops.id as shop_id',
                'shops.name as shop_name',
                'wallets.balance as wallet_balance',
            ])
            ->where('roles.name', '=', 'merchant')
            ->where('users.deleted_at', '=', null);

        if (!empty($filterData['date_from'])) {
            $data->where('users.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('users.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $merchant = $this->_userRepository->getById($id);

            if ($merchant == null || !$merchant->hasRole('merchant')) {
                return false;
            }

            return $merchant;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get merchant details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'email' => 'required|string|email|max:255|unique:users,email,' . $id,
                'password' => 'nullable|confirmed|min:8'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_userRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update merchant details.");

            DB::rollBack();
            return null;
        }
    }

    public function updateAccountVerify($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'is_verified' => 'required|boolean'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $user = $this->_userRepository->update($data, $id);
            $user = $user->toArray();


            $data['account_verify_request']['is_waiting_approved'] = false;
            $data['account_verify_request']['is_approved'] = $data['is_verified'];
            $accountVerifyRequest = $this->_accountVerifyRequestRepository->updateWaitingApproavalByUserId($data['account_verify_request'], $user['id']);

            DB::commit();
            return $user;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update account verify status.");

            DB::rollBack();
            return null;
        }
    }

    public function getTodayNewRegisterMerchantCount()
    {
        try {
            $date = Carbon::now()->format('Y-m-d');
            $merchant = $this->_userRepository->getTotalCountByCreatedAt($date);

            return $merchant;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get today total new register merchant count.");

            return null;
        }
    }

    public function getCurrentYearEachMonthNewRegisterMerchant()
    {
        try {
            $year = Carbon::now()->format('Y');
            $monthlyNewMerchant = $this->_userRepository->getEachMonthTotalCountByYear($year);

            $data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            foreach ($monthlyNewMerchant as $newMerchant) {
                $data[$newMerchant->month - 1] = $newMerchant->total;
            }

            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get each month new register merchant.");

            return null;
        }
    }
}
