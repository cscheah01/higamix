<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class TwoFactorAdminService extends Service
{
    protected $_userRepository;
    protected $_google2fa;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
        $this->_google2fa = app('pragmarx.google2fa');
    }

    public function getTwoFactorSetupDetails()
    {
        try {
            $id = Auth::id();
            $user = $this->_userRepository->getById($id);

            $twoFactor['google_2fa_secret'] = decrypt($user['google_2fa_secret']);

            $twoFactor['qr_image_url'] = $this->_google2fa->getQRCodeUrl(
                config('app.name'),
                $user['email'],
                decrypt($user['google_2fa_secret'])
            );

            return $twoFactor;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get two-factor authentication setup details.");

            return null;
        }
    }

    public function enableTwoFactor($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'code' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $user = $this->_userRepository->getById($userId);

            if ($this->_google2fa->verifyKey(decrypt($user->google_2fa_secret), $data['code']) == true) {
                $data['is_enabled_two_factor'] = true;
                $result = $this->_userRepository->update($data, $userId);
                Session::put('passedTwoFactor', true);
            } else {
                array_push($this->_errorMessage, "Code is invalid.");

                DB::rollBack();
                return null;
            }

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to setup two-factor authentication.");

            DB::rollBack();
            return null;
        }
    }

    public function disableTwoFactor($data, $userId = null)
    {
        DB::beginTransaction();

        try {
            $userId = $userId ?? Auth::id();

            $validator = Validator::make($data, [
                'is_enabled_two_factor' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $user = $this->_userRepository->update($data, $userId);
            Session::put('passedTwoFactor', false);

            DB::commit();
            return $user;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to disable two-factor authentication.");

            DB::rollBack();
            return null;
        }
    }
}
