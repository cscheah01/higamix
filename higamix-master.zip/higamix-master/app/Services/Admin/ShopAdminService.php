<?php

namespace App\Services\Admin;

use Image;
use Exception;
use App\Services\Service;
use Illuminate\Support\Str;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\ShopRepository;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class ShopAdminService extends Service
{
    protected $_shopRepository;

    public function __construct(
        ShopRepository $shopRepository
    ) {
        $this->_shopRepository = $shopRepository;
    }

    public function getDataTable()
    {

        $data = DB::table('shops')
            ->leftjoin('users', 'shops.user_id', '=', 'users.id')
            ->select([
                'shops.id',
                'shops.name',
                'shops.created_at',
                'users.id as user_id',
                'users.email as user_email'
            ]);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $shop = $this->_shopRepository->getById($id);

            if ($shop == null) {
                return false;
            }

            return $shop;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get shop details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'logo_image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'name' => 'required|string|max:255',
                'remove_image' => 'required|boolean',
                'general_description' => 'nullable|string|max:1000',
                'description' => 'nullable|string|max:16777215',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shop = $this->_shopRepository->getById($id);

            if ($data['remove_image'] == false && !empty($data['logo_image'])) {
                $image = $data['logo_image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['logo_image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/shop_logo');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                if (Storage::exists('public/shop_logo/' . $shop->logo_image)) {
                    Storage::delete('public/shop_logo/' . $shop->logo_image);
                }

                $data['logo_image'] = $fileName;
            } else if ($data['remove_image'] == true) {
                if (Storage::exists('public/shop_logo/' . $shop->logo_image)) {
                    Storage::delete('public/shop_logo/' . $shop->logo_image);
                }
                $data['logo_image'] = null;
            }

            $shop = $this->_shopRepository->updateById($data, $id);

            DB::commit();
            return $shop;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update shop details.");
            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }
}
