<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use App\Enums\SettingMeta;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\SettingRepository;

class PlatformSettingAdminService extends Service
{
    protected $_settingRepository;

    public function __construct(
        SettingRepository $settingRepository
    ) {
        $this->_settingRepository = $settingRepository;
    }

    public function update($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'platform_setting' => 'required|array',
                'platform_setting.' . SettingMeta::PlatformCommission()->key => 'required|numeric|between: 0.00,99999999999.99',
                'platform_setting.' . SettingMeta::MinimumTopUpAmount()->key => 'required|numeric|between: 0.00,99999999999.99',
                'platform_setting.' . SettingMeta::MinimumWithdrawAmount()->key => 'required|numeric|between: 0.00,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            foreach ($data['platform_setting'] as $metaKey => $metaValue) {
                $this->_settingRepository->updateByMetaKey($metaKey, $metaValue);
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update platform setting.");
            DB::rollBack();
            return null;
        }
    }

    public function getAllPlatformSetting()
    {
        try {
            $platformSettings = $this->_settingRepository->getAll();

            return $platformSettings;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get platform setting details.");

            return null;
        }
    }
}
