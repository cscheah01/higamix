<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Services\Admin\MerchantAdminService;
use App\Repositories\AccountVerifyRequestRepository;

class AccountVerifyRequestAdminService extends Service
{
    protected $_accountVerifyRequestRepository;
    protected $_merchantAdminService;

    public function __construct(
        AccountVerifyRequestRepository $accountVerifyRequestRepository,
        MerchantAdminService $merchantAdminService
    ) {
        $this->_accountVerifyRequestRepository = $accountVerifyRequestRepository;
        $this->_merchantAdminService = $merchantAdminService;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('account_verify_requests')
            ->leftjoin('users', 'account_verify_requests.user_id', '=', 'users.id')
            ->leftJoin('shops', 'account_verify_requests.user_id', '=', 'shops.user_id')
            ->select([
                'account_verify_requests.id',
                'account_verify_requests.is_waiting_approved',
                'account_verify_requests.is_approved',
                'account_verify_requests.created_at',
                'users.email as user_email',
                'users.id as user_id',
                'shops.id as shop_id',
                'shops.name as shop_name'
            ])->where('account_verify_requests.is_waiting_approved', '=', true);

        if (!empty($filterData['date_from'])) {
            $data->where('account_verify_requests.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('account_verify_requests.created_at', '<=', $filterData['date_to']);
        }
        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getRejectedDataTable($filterData)
    {
        $data = DB::table('account_verify_requests')
            ->leftjoin('users', 'account_verify_requests.user_id', '=', 'users.id')
            ->leftJoin('shops', 'account_verify_requests.user_id', '=', 'shops.user_id')
            ->select([
                'account_verify_requests.id',
                'account_verify_requests.is_waiting_approved',
                'account_verify_requests.is_approved',
                'account_verify_requests.created_at',
                'users.email as user_email',
                'users.id as user_id',
                'shops.id as shop_id',
                'shops.name as shop_name'
            ])->where('account_verify_requests.is_approved', '=', false)
            ->where('users.is_verified', '=', false)
            ->where('account_verify_requests.is_waiting_approved', '=', false);

        if (!empty($filterData['date_from'])) {
            $data->where('account_verify_requests.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('account_verify_requests.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'is_approved' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $data['is_waiting_approved'] = false;
            $accountVerifyRequest = $this->_accountVerifyRequestRepository->update($data, $id);

            $data['user']['is_verified'] = $accountVerifyRequest->is_approved;
            $user = $this->_merchantAdminService->updateAccountVerify($data['user'], $accountVerifyRequest->user_id);

            DB::commit();
            return $accountVerifyRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update the account verify request.");

            DB::rollBack();
            return null;
        }
    }

    public function getTotalPendingAccountVerifyRequestApprovalCount()
    {
        try {
            $total = $this->_accountVerifyRequestRepository->getTotalPendingApprovalCount();

            return $total;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total account verify request count.");

            return null;
        }
    }
}
