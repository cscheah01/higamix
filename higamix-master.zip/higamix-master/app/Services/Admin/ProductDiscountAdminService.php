<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use App\Repositories\ProductDiscountRepository;

class ProductDiscountAdminService extends Service
{
    protected $_productDiscountRepository;

    public function __construct(
        ProductDiscountRepository $productDiscountRepository
    ) {
        $this->_productDiscountRepository = $productDiscountRepository;
    }

    public function getAllByProductId($id)
    {
        try {
            $productDiscounts = $this->_productDiscountRepository->getAllByProductId($id);

            return $productDiscounts;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product discounts.");
            return null;
        }
    }
}
