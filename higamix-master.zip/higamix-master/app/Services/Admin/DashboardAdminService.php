<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use App\Services\Admin\OrderAdminService;
use App\Services\Admin\MerchantAdminService;
use App\Services\Admin\AccountVerifyRequestAdminService;
use App\Services\Admin\WalletWithdrawalRequestAdminService;
use App\Services\Admin\PlatformCommissionTransactionAdminService;
use App\Services\ZixiPayService;

class DashboardAdminService extends Service
{
    protected $_orderAdminService;
    protected $_merchantAdminService;
    protected $_platformCommissionTransactionAdminService;
    protected $_accountVerifyRequestAdminService;
    protected $_walletWithdrawalRequestAdminService;
    protected $_zixiPayService;

    public function __construct(
        OrderAdminService $orderAdminService,
        MerchantAdminService $merchantAdminService,
        PlatformCommissionTransactionAdminService $platformCommissionTransactionAdminService,
        AccountVerifyRequestAdminService $accountVerifyRequestAdminService,
        WalletWithdrawalRequestAdminService $walletWithdrawalRequestAdminService,
        ZixiPayService $zixiPayService
    ) {
        $this->_orderAdminService = $orderAdminService;
        $this->_merchantAdminService = $merchantAdminService;
        $this->_platformCommissionTransactionAdminService = $platformCommissionTransactionAdminService;
        $this->_accountVerifyRequestAdminService = $accountVerifyRequestAdminService;
        $this->_walletWithdrawalRequestAdminService = $walletWithdrawalRequestAdminService;
        $this->_zixiPayService = $zixiPayService;
    }

    public function getData()
    {
        try {
            $data['total_sales'] = $this->_orderAdminService->getCurrentMonthTotalSales();
            $data['total_earned_commission'] = $this->_platformCommissionTransactionAdminService->getCurrentMonthTotalEarnedPlatformCommission();
            $data['withdrawal_request'] = $this->_walletWithdrawalRequestAdminService->getPendingWithdrawalRequestApprovalTotalCount();
            $data['account_verify_request'] = $this->_accountVerifyRequestAdminService->getTotalPendingAccountVerifyRequestApprovalCount();
            $data['today_total_register_merchant'] = $this->_merchantAdminService->getTodayNewRegisterMerchantCount();
            $data['each_month_new_register_merchant'] = $this->_merchantAdminService->getCurrentYearEachMonthNewRegisterMerchant();
            $data['each_month_sales'] = $this->_orderAdminService->getCurrentYearEachMonthSales();
            $data['each_month_earned_platform_commission'] = $this->_platformCommissionTransactionAdminService->getCurrentYearEachMonthEarnedPlatformCommission();
            $data['zixipay_balance'] = $this->_zixiPayService->getWalletBalance();

            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get dashboard data.");

            return null;
        }
    }
}
