<?php

namespace App\Services\Admin;

use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\OrderRepository;
use App\Repositories\ProductRepository;
use App\Repositories\PlatformCommissionTransactionRepository;

class PlatformCommissionTransactionAdminService extends Service
{
    protected $_productRepository;
    protected $_orderRepository;
    protected $_platformCommissionTransactionRepository;

    public function __construct(
        ProductRepository $productRepository,
        OrderRepository $orderRepository,
        PlatformCommissionTransactionRepository $platformCommissionTransactionRepository
    ) {
        $this->_productRepository = $productRepository;
        $this->_orderRepository = $orderRepository;
        $this->_platformCommissionTransactionRepository = $platformCommissionTransactionRepository;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('platform_commission_transactions')
            ->select([
                'id',
                'order_id',
                'percentage',
                'amount',
                'created_at',
            ]);

        if (!empty($filterData['date_from'])) {
            $data->where('created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getCurrentMonthTotalEarnedPlatformCommission()
    {
        try {
            $year = Carbon::now()->format('Y');
            $month = Carbon::now()->format('m');
            $totalEarnedPlatformCommission = $this->_platformCommissionTransactionRepository->getTotalByMonthAndYear($month, $year);

            return $totalEarnedPlatformCommission;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total earned platform commission.");

            return null;
        }
    }

    public function getCurrentYearEachMonthEarnedPlatformCommission()
    {
        try {
            $year = Carbon::now()->format('Y');

            $monthlyTotal = $this->_platformCommissionTransactionRepository->getEachMonthTotalEarnedPlatformCommission($year);

            $dataList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

            foreach ($monthlyTotal as $platformCommission) {
                $dataList[$platformCommission->month] = $platformCommission->total_platform_commission;
            }

            return $dataList;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get each month total earned platform commission.");

            return null;
        }
    }
}
