<?php

namespace App\Services\Admin;

use Exception;

use App\Services\Service;
use App\Repositories\OrderProductRepository;

class OrderProductAdminService extends Service
{
    protected $_orderProductRepository;

    public function __construct(
        OrderProductRepository $orderProductRepository
    ) {
        $this->_orderProductRepository = $orderProductRepository;
    }

    public function getAllByOrderId($orderId)
    {
        try {
            $orderProducts = $this->_orderProductRepository->getAllByOrderId($orderId);

            return $orderProducts;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get order products.");

            return null;
        }
    }
}
