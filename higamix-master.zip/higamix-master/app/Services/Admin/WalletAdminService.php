<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\WalletRepository;
use Illuminate\Support\Facades\Validator;

class WalletAdminService extends Service
{
    protected $_walletRepository;

    public function __construct(
        WalletRepository $walletRepository
    ) {
        $this->_walletRepository = $walletRepository;
    }

    public function getDataTable()
    {
        $data = DB::table('wallets')
            ->leftjoin('users', 'wallets.user_id', '=', 'users.id')
            ->leftJoin('shops', 'wallets.user_id', '=', 'shops.user_id')
            ->select([
                'wallets.id',
                'wallets.balance',
                'wallets.withdraw_address',
                'users.id as user_id',
                'users.email as user_email',
                'shops.id as shop_id',
                'shops.name as shop_name',
            ]);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $wallet = $this->_walletRepository->getByUserId($id);

            if ($wallet == null) {
                return false;
            }

            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet details.");

            return null;
        }
    }

    public function updateBalanceByUserId($data, $userId)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'balance' => 'required|numeric|between: 0.00,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }
                return null;
            }

            $wallet = $this->_walletRepository->updateByUserId($data, $userId);

            DB::commit();
            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update wallet balance.");

            DB::rollBack();
            return null;
        }
    }

    public function getWalletByUserId($userId)
    {
        try {
            $wallet = $this->_walletRepository->getByUserId($userId);
            $wallet = $wallet->toArray();

            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet details.");

            return null;
        }
    }
}
