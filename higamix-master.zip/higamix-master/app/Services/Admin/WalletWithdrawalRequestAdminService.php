<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Services\Admin\WalletAdminService;
use App\Services\Admin\WalletTransactionAdminService;
use App\Repositories\WalletWithdrawalRequestRepository;
use App\Services\ZixiPayService;

class WalletWithdrawalRequestAdminService extends Service
{
    protected $_walletWithdrawalRequestRepository;
    protected $_walletTransactionAdminService;
    protected $_walletAdminService;
    protected $_zixiPayService;

    public function __construct(
        WalletWithdrawalRequestRepository $walletWithdrawalRequestRepository,
        WalletTransactionAdminService $walletTransactionAdminService,
        WalletAdminService $walletAdminService,
        ZixiPayService $zixiPayService
    ) {
        $this->_walletWithdrawalRequestRepository = $walletWithdrawalRequestRepository;
        $this->_walletTransactionAdminService = $walletTransactionAdminService;
        $this->_walletAdminService = $walletAdminService;
        $this->_zixiPayService = $zixiPayService;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('wallet_withdrawal_requests')
            ->leftjoin('users', 'wallet_withdrawal_requests.user_id', '=', 'users.id')
            ->leftJoin('shops', 'wallet_withdrawal_requests.user_id', '=', 'shops.user_id')
            ->select([
                'wallet_withdrawal_requests.id',
                'wallet_withdrawal_requests.amount',
                'wallet_withdrawal_requests.is_approved',
                'wallet_withdrawal_requests.is_rejected',
                'wallet_withdrawal_requests.created_at',
                'wallet_withdrawal_requests.remark',
                'users.email as user_email',
                'users.id as user_id',
                'shops.id as shop_id',
                'shops.name as shop_name'
            ]);
        if (!empty($filterData['date_from'])) {
            $data->where('wallet_withdrawal_requests.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('wallet_withdrawal_requests.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->getById($id);

            if ($walletWithdrawalRequest == null) {
                return false;
            }

            return $walletWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet withdrawal request details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'is_approved' => 'required|boolean',
                'remark' => 'nullable|required_if:is_approved,=,false|string|max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->getById($id);

            if ($walletWithdrawalRequest->is_approved || $walletWithdrawalRequest->is_rejected) {
                throw new Exception();
            }


            if ($data['is_approved']) {
                $data['is_rejected'] = false;

                $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->update($data, $id);

                //zixipay
                $data['zixi_pay']['amount'] = $walletWithdrawalRequest['amount'] - $walletWithdrawalRequest['transaction_fee'];
                $data['zixi_pay']['withdraw_address'] = $walletWithdrawalRequest['withdraw_address'];
                $zixiPayWithdraw = $this->_zixiPayService->withdraw($data['zixi_pay']);

                if ($zixiPayWithdraw == null) {
                    foreach ($this->_zixiPayService->_errorMessage as $zixiPayErrorMessage) {
                        array_push($this->_errorMessage, $zixiPayErrorMessage);
                    }

                    throw new Exception();
                }
            } else {
                $data['is_rejected'] = true;
                $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->update($data, $id);


                $wallet = $this->_walletAdminService->getWalletByUserId($walletWithdrawalRequest->user_id);

                $data['wallet']['balance'] = $wallet['balance'] + $walletWithdrawalRequest->amount;

                $wallet = $this->_walletAdminService->updateBalanceByUserId($data['wallet'], $walletWithdrawalRequest->user_id);


                $walletTransaction['wallet_id'] = $wallet->id;
                $walletTransaction['balance'] = $wallet->balance;
                $walletTransaction['debit'] = $walletWithdrawalRequest->amount;
                $walletTransaction['description'] = 'Staff rejected withdraw request for ' . $walletWithdrawalRequest->amount . ' USDT. Reason: ' . $data['remark'];

                $walletTransaction = $this->_walletTransactionAdminService->createWalletTransaction($walletTransaction['wallet_id'], $walletTransaction);
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update withdrawal request.");

            DB::rollBack();
            return null;
        }
    }

    public function getPendingWithdrawalRequestApprovalTotalCount()
    {
        try {
            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->getPendingApprovalTotalCount();

            return $walletWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total pending withdrawal request approval count.");

            return null;
        }
    }
}
