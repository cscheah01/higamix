<?php

namespace App\Services\Admin;

use Exception;

use Carbon\Carbon;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\OrderRepository;
use App\Services\Admin\ShopAdminService;
use App\Services\Admin\WalletAdminService;

class OrderAdminService extends Service
{
    protected $_shopAdminService;
    protected $_orderRepository;
    protected $_walletAdminService;
    protected $_walletTransactionAdminService;

    public function __construct(
        ShopAdminService $shopAdminService,
        OrderRepository $orderRepository,
        WalletAdminService $walletAdminService,
        WalletTransactionAdminService $walletTransactionAdminService
    ) {
        $this->_shopAdminService = $shopAdminService;
        $this->_orderRepository = $orderRepository;
        $this->_walletAdminService = $walletAdminService;
        $this->_walletTransactionAdminService = $walletTransactionAdminService;
    }

    public function getDataTable($filterData)
    {

        $data = DB::table('orders')
            ->leftJoin('users', 'orders.user_id', '=', 'users.id')
            ->leftJoin('shops', 'orders.shop_id', '=', 'shops.id')
            ->select([
                'orders.id',
                'orders.buyer_email',
                'orders.total',
                'orders.created_at',
                'orders.status',
                'orders.is_api_sales',
                'users.id as user_id',
                'users.email as user_email',
                'shops.id as shop_id',
                'shops.name as shop_name'
            ]);

        if (!empty($filterData['id'])) {
            $data->where('orders.id', '=', $filterData['id']);
        }

        if (!empty($filterData['date_from'])) {
            $data->where('orders.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('orders.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->addColumn('status_label', '{{\App\Enums\OrderStatus::fromKey($status)->description}}')
            ->make();

        return $result;
    }

    public function getOrderById($id)
    {
        try {
            $order = $this->_orderRepository->getById($id);

            if ($order == null) {
                return false;
            }

            return $order;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get order details.");

            return null;
        }
    }

    public function getCurrentMonthTotalSales()
    {
        try {
            $year = Carbon::now()->format('Y');
            $month = Carbon::now()->format('m');
            $totalSales = $this->_orderRepository->getTotalSalesByMonthAndYear($month, $year);

            return $totalSales;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total sales.");

            return null;
        }
    }

    public function getCurrentYearEachMonthSales()
    {
        try {
            $year = Carbon::now()->format('Y');
            $dataList = $this->_orderRepository->getEachMonthSalesByYear($year);

            $eachMonthSales = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

            foreach ($dataList as $monthlySales) {
                $eachMonthSales[$monthlySales->month] = $monthlySales->total_amount;
            }

            return $eachMonthSales;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get each month total sales.");

            return null;
        }
    }
}
