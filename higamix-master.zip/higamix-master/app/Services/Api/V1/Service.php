<?php

namespace App\Services\Api\V1;

use App\Models\InternalErrorHistory;

class Service
{
    public $_errorMessage = array();

    public function storeInternalErrorHistory($className, $functionName, $exceptionMessage, $functionParameter = null)
    {
        $model = new InternalErrorHistory;
        $model->class_name = $className;
        $model->function_name = $functionName;
        $model->exception_message = $exceptionMessage;
        $model->function_parameter = $functionParameter ?? null;

        $model->save();
    }
}
