<?php

namespace App\Services\Api\V1;

use App\Repositories\WalletRepository;
use Exception;
use Illuminate\Http\Response;

class WalletApiV1Service extends Service
{
    protected $_walletRepository;

    public function __construct(
        WalletRepository $walletRepository
    ) {
        $this->_walletRepository = $walletRepository;
    }

    public function getUserWalletBalance($userId)
    {
        try {
            $wallet = $this->_walletRepository->getByUserId($userId);

            if ($wallet == null) {
                return response([
                    "success" => false,
                    "message" => "We didn't found wallet data for this user.",
                ], Response::HTTP_NOT_FOUND);
            }


            $wallet = $wallet->only([
                'balance',
            ]);

            return response([
                "success" => true,
                "data" => $wallet
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            $this->storeInternalErrorHistory(__CLASS__, __FUNCTION__, $e->getMessage(), json_encode(func_get_args()));

            return response([
                "success" => false,
                "message" => 'Server Error - Fail to get wallet balance.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
