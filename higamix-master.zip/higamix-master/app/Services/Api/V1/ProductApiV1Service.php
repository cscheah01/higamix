<?php

namespace App\Services\Api\V1;

use Exception;
use App\Enums\ProductType;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\ProductRepository;
use App\Repositories\ProductDiscountRepository;

class ProductApiV1Service extends Service
{
    protected $_productRepository;
    protected $_productDiscountRepository;

    public function __construct(
        ProductRepository $productRepository,
        ProductDiscountRepository $productDiscountRepository
    ) {
        $this->_productRepository = $productRepository;
        $this->_productDiscountRepository = $productDiscountRepository;
    }

    public function getProductList($data)
    {
        try {
            $data['limit'] = 25;
            $data['skip'] = ($data['page'] - 1) * $data['limit'];

            $products =
                DB::table('products')
                ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
                ->leftJoin('product_categories', 'products.product_category_id', 'product_categories.id')
                ->leftJoin('product_sub_categories', 'products.product_sub_category_id', 'product_sub_categories.id')
                ->select([
                    'products.id',
                    'products.name',
                    'products.image',
                    'parent_product.image as parent_product_image',
                    'products.description',
                    'parent_product.description as parent_product_description',
                    'products.price',
                    DB::raw('(parent_product.resell_cost_price + products.resell_profit) as resell_price'),
                    'products.min_purchase_qty',
                    'products.max_purchase_qty',
                    'parent_product.min_purchase_qty as parent_product_min_purchase_qty',
                    'parent_product.max_purchase_qty as parent_product_max_purchase_qty',
                    'products.product_type',
                    'parent_product.product_type as parent_product_product_type',
                    'products.service_description',
                    'parent_product.service_description as parent_product_service_description',
                    'product_categories.name as product_category_name',
                    'product_sub_categories.name as product_sub_category_name',
                    'products.is_resell',
                    DB::raw('
                    CASE
                    WHEN
                        products.is_resell
                    THEN
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.parent_product_id AND is_sold = 0)
                    ELSE
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.id AND is_sold = 0)
                    END
                    as stock_qty'),
                ])
                ->where('products.is_available', '=', true)
                ->where('products.shop_id', '=', $data['shop_id'])
                ->where('products.deleted_at', '=', null)
                ->skip($data['skip'])
                ->take($data['limit'])
                ->get();

            $productList = [];
            foreach ($products as $product) {
                $formattedData = [
                    'id' => $product->id,
                    'name' => $product->name,
                    'description' => $product->is_resell ? $product->parent_product_description : $product->description,
                    'image' => ($product->parent_product_image != null || $product->image != null) ? url('storage/product_image/' . ($product->is_resell ? $product->parent_product_image : $product->image)) : null,
                    'price' => $product->is_resell ? $product->resell_price : $product->price,
                    'min_purchase_qty' => $product->is_resell ? $product->parent_product_min_purchase_qty : $product->min_purchase_qty,
                    'max_purchase_qty' => $product->is_resell ? $product->parent_product_min_purchase_qty : $product->max_purchase_qty,
                    'product_type' => ProductType::fromKey($product->is_resell ? $product->parent_product_product_type : $product->product_type)->description,
                    'product_category_name' => $product->product_category_name,
                    'product_sub_category_name' => $product->product_sub_category_name,
                ];

                if ($product->product_type == ProductType::fromValue(ProductType::Service)->key || $product->parent_product_product_type == ProductType::fromValue(ProductType::Service)->key) {
                    $formattedData['service_description'] = $product->is_resell ? $product->parent_product_service_description : $product->service_description;
                }

                if ($product->product_type == ProductType::fromValue(ProductType::SerialKey)->key || $product->parent_product_product_type == ProductType::fromValue(ProductType::SerialKey)->key) {
                    $formattedData['stock_qty'] = $product->stock_qty;
                }

                $productList[] = $formattedData;
            }

            return response([
                "success" => true,
                "data" => $productList
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            $this->storeInternalErrorHistory(__CLASS__, __FUNCTION__, $e->getMessage(), json_encode(func_get_args()));

            return response([
                "success" => false,
                "message" => 'Server Error - Fail to get product list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getProductDetails($shopId, $id)
    {
        try {
            $product =
                DB::table('products')
                ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
                ->leftJoin('product_categories', 'products.product_category_id', 'product_categories.id')
                ->leftJoin('product_sub_categories', 'products.product_sub_category_id', 'product_sub_categories.id')
                ->select([
                    'products.id',
                    'products.name',
                    'products.image',
                    'parent_product.image as parent_product_image',
                    'products.description',
                    'parent_product.description as parent_product_description',
                    'products.price',
                    DB::raw('(parent_product.resell_cost_price + products.resell_profit) as resell_price'),
                    'products.min_purchase_qty',
                    'products.max_purchase_qty',
                    'parent_product.min_purchase_qty as parent_product_min_purchase_qty',
                    'parent_product.max_purchase_qty as parent_product_max_purchase_qty',
                    'products.product_type',
                    'parent_product.product_type as parent_product_product_type',
                    'products.service_description',
                    'parent_product.service_description as parent_product_service_description',
                    'product_categories.name as product_category_name',
                    'product_sub_categories.name as product_sub_category_name',
                    'products.is_resell',
                    DB::raw('
                    CASE
                    WHEN
                        products.is_resell
                    THEN
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.parent_product_id AND is_sold = 0)
                    ELSE
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.id AND is_sold = 0)
                    END
                    as stock_qty'),
                ])
                ->where('products.is_available', '=', true)
                ->where('products.id', '=', $id)
                ->where('products.shop_id', '=', $shopId)
                ->where('products.deleted_at', '=', null)
                ->first();

            if ($product == null) {
                return response([
                    "success" => false,
                    "message" => "Product not found.",
                ], Response::HTTP_NOT_FOUND);
            }


            $formattedProduct = [
                'id' => $product->id,
                'name' => $product->name,
                'description' => $product->is_resell ? $product->parent_product_description : $product->description,
                'image' => ($product->parent_product_image != null || $product->image != null) ? url('storage/product_image/' . ($product->is_resell ? $product->parent_product_image : $product->image)) : null,
                'price' => $product->is_resell ? $product->resell_price : $product->price,
                'min_purchase_qty' => $product->is_resell ? $product->parent_product_min_purchase_qty : $product->min_purchase_qty,
                'max_purchase_qty' => $product->is_resell ? $product->parent_product_min_purchase_qty : $product->max_purchase_qty,
                'product_type' => ProductType::fromKey($product->is_resell ? $product->parent_product_product_type : $product->product_type)->description,
                'product_category_name' => $product->product_category_name,
                'product_sub_category_name' => $product->product_sub_category_name,
            ];

            if ($product->product_type == ProductType::fromValue(ProductType::Service)->key || $product->parent_product_product_type == ProductType::fromValue(ProductType::Service)->key) {
                $formattedProduct['service_description'] = $product->is_resell ? $product->parent_product_service_description : $product->service_description;
            }

            if ($product->product_type == ProductType::fromValue(ProductType::SerialKey)->key || $product->parent_product_product_type == ProductType::fromValue(ProductType::SerialKey)->key) {
                $formattedProduct['stock_qty'] = $product->stock_qty;
            }


            //discount
            $productDiscounts = $this->_productDiscountRepository->getAllByProductId($id);

            $discountList = [];

            foreach ($productDiscounts as $productDiscount) {
                $discountList[] = [
                    'min_qty' => $productDiscount->min_qty,
                    'discounted_price' => $productDiscount->discounted_price,
                ];
            }

            $formattedProduct['promotion'] = $discountList;

            return response([
                "success" => true,
                "data" => $formattedProduct
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            $this->storeInternalErrorHistory(__CLASS__, __FUNCTION__, $e->getMessage(), json_encode(func_get_args()));

            return response([
                "success" => false,
                "message" => 'Server Error - Fail to get product details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
