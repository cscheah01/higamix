<?php

namespace App\Services\Api\V1;

use App\Enums\OrderStatus;
use Exception;
use App\Enums\ProductType;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\OrderRepository;
use App\Services\Merchant\OrderProductMerchantService;

class SalesHistoryApiV1Service extends Service
{
    protected $_orderRepository;
    protected $_orderProductMerchantService;

    public function __construct(
        OrderRepository $orderRepository,
        OrderProductMerchantService $orderProductMerchantService
    ) {
        $this->_orderRepository = $orderRepository;
        $this->_orderProductMerchantService = $orderProductMerchantService;
    }

    public function getSalesHistoryList($data)
    {
        try {
            $data['limit'] = 25;
            $data['skip'] = ($data['page'] - 1) * $data['limit'];

            $orders = DB::table('orders')
                ->select([
                    'orders.id',
                    'orders.buyer_email',
                    'orders.total',
                    'orders.platform_commission_percentage',
                    'orders.platform_commission_amount',
                    'orders.product_cost',
                    'orders.seller_profit',
                    'orders.status',
                    'orders.created_at',
                ])
                ->where('orders.shop_id', '=', $data['shop_id'])
                ->get();

            $orderList = [];
            foreach ($orders as $order) {
                $order->status = OrderStatus::fromKey($order->status)->description;

                $orderList[] = $order;
            }

            return response([
                "success" => true,
                "data" => $orderList
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            $this->storeInternalErrorHistory(__CLASS__, __FUNCTION__, $e->getMessage(), json_encode(func_get_args()));

            return response([
                "success" => false,
                "message" => 'Server Error - Fail to get sales order list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getSalesHistoryDetails($shopId, $id)
    {
        try {
            $order = $this->_orderRepository->getById($id);

            if ($order == null || $order->shop_id != $shopId) {
                return response([
                    "success" => false,
                    "message" => "Order not found.",
                ], Response::HTTP_NOT_FOUND);
            }

            $orderProducts = $this->_orderProductMerchantService->getAllByOrderId($id);

            $orderProductList = [];

            foreach ($orderProducts as $orderProduct) {
                $product = [
                    'name' => $orderProduct->name,
                    'product_type' => ProductType::fromKey($orderProduct->product_type)->description,
                    'qty' => $orderProduct->qty,
                    'unit_price' => $orderProduct->unit_price,
                    'sub_total' => $orderProduct->sub_total,

                ];

                if ($orderProduct->product_type == ProductType::SerialKey()->key) {
                    $serialNumbers = [];

                    foreach ($orderProduct->productSerials as $productSerial) {
                        $serialNumbers[] = $productSerial->serial_number;
                    }

                    $product['serial_number'] = $serialNumbers;
                }

                $orderProductList[] = $product;
            }

            $order['product'] = $orderProductList;

            $order = $order->only([
                'id',
                'buyer_email',
                'total',
                'platform_commission_percentage',
                'platform_commission_amount',
                'product_cost',
                'seller_profit',
                'status',
                'product',
                'created_at',
            ]);

            $order['created_at'] = $order['created_at']->format('d-m-Y H:i:s');
            $order['status'] = OrderStatus::fromKey($order['status'])->description;


            return response([
                "success" => true,
                "data" => $order
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            $this->storeInternalErrorHistory(__CLASS__, __FUNCTION__, $e->getMessage(), json_encode(func_get_args()));

            return response([
                "success" => false,
                "message" => 'Server Error - Fail to get sales order details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
