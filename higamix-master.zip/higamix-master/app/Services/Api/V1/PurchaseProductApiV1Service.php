<?php

namespace App\Services\Api\V1;

use Exception;
use App\Enums\OrderStatus;
use App\Enums\ProductType;
use App\Enums\SettingMeta;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\OrderRepository;
use App\Repositories\ProductRepository;
use App\Repositories\SettingRepository;
use Illuminate\Support\Facades\Validator;
use App\Services\Merchant\WalletMerchantService;
use App\Services\Merchant\OrderProductMerchantService;
use App\Services\Merchant\ProductDiscountMerchantService;
use App\Services\Merchant\WalletTransactionMerchantService;
use App\Repositories\PlatformCommissionTransactionRepository;
use App\Repositories\ProductSerialRepository;

class PurchaseProductApiV1Service extends Service
{
    protected $_productRepository;
    protected $_orderRepository;
    protected $_walletMerchantService;
    protected $_walletTransactionMerchantService;
    protected $_orderProductMerchantService;
    protected $_productDiscountMerchantService;
    protected $_settingRepository;
    protected $_platformCommissionTransactionRepository;
    protected $_productSerialRepository;

    public function __construct(
        OrderRepository $orderRepository,
        ProductRepository $productRepository,
        WalletMerchantService $walletMerchantService,
        WalletTransactionMerchantService $walletTransactionMerchantService,
        OrderProductMerchantService $orderProductMerchantService,
        ProductDiscountMerchantService $productDiscountMerchantService,
        SettingRepository $settingRepository,
        PlatformCommissionTransactionRepository $platformCommissionTransactionRepository,
        ProductSerialRepository $productSerialRepository
    ) {
        $this->_productRepository = $productRepository;
        $this->_orderRepository = $orderRepository;
        $this->_walletMerchantService = $walletMerchantService;
        $this->_walletTransactionMerchantService = $walletTransactionMerchantService;
        $this->_orderProductMerchantService = $orderProductMerchantService;
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_settingRepository = $settingRepository;
        $this->_platformCommissionTransactionRepository = $platformCommissionTransactionRepository;
        $this->_productSerialRepository = $productSerialRepository;
    }

    public function createOrder($shopId, $userId, $data)
    {

        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                "buyer_email" => 'required|string|email|max:255',
                "product" => 'required|array',
                'product.*.product_id' => 'required',
                'product.*.qty' => 'required|min:1|numeric',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }


            $data['order']['total'] = 0.00;
            $data['order']['product_cost'] = 0.00;

            $orderProducts = [];
            $parentProductSales = [];

            foreach ($data['product'] as $orderProduct) {
                //get product details
                $product = $this->_productRepository->getById($orderProduct['product_id']);

                if ($product == null || !$product->is_available || $product->shop_id != $shopId) {
                    return response([
                        "success" => false,
                        "message" => "Some product is not found or unavailable.",
                    ], Response::HTTP_UNPROCESSABLE_ENTITY);
                }


                //get parent product details
                $parentProduct = $this->_productRepository->getById($product->parent_product_id);


                //check purchase quantity cannot more than max purchase qty of the product
                $maxPurchaseQuantity = $product->parent_product_id ? $parentProduct->max_purchase_qty : $product->max_purchase_qty;

                if ($maxPurchaseQuantity != 0 && $orderProduct['qty'] > $maxPurchaseQuantity) {
                    DB::rollBack();

                    return response([
                        "success" => false,
                        "message" => "Your purchase quantity is over the maximum purchase quantity.",
                    ], Response::HTTP_UNPROCESSABLE_ENTITY);
                }


                //check serial key stock
                $orderProduct['product_type'] = $product->parent_product_id ? $parentProduct->product_type : $product->product_type;

                if ($orderProduct['product_type'] == ProductType::SerialKey()->key) {
                    $totalAvailableProductSerial = $this->_productSerialRepository->getTotalUnSoldCountByProductId($product->parent_product_id ? $product->parent_product_id : $product->id);

                    if ($orderProduct['qty'] > $totalAvailableProductSerial) {
                        DB::rollBack();

                        return response([
                            "success" => false,
                            "message" => "The purchase quantity is over the product stock.",
                        ], Response::HTTP_UNPROCESSABLE_ENTITY);
                    }
                }

                //unit price
                $orderProduct['unit_price'] = $product->parent_product_id ? ($product->resell_profit + $parentProduct->resell_cost_price) : $product->price;


                //discount
                if (!$product->is_resell) {
                    $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($product->id);

                    if ($productDiscounts != null) {

                        foreach ($productDiscounts as $productDiscount) {

                            if ($orderProduct['qty'] >= $productDiscount->min_qty && $orderProduct['unit_price'] > $productDiscount->discounted_price) {
                                $orderProduct['unit_price'] = $productDiscount->discounted_price;
                            }
                        }
                    }
                }

                $orderProduct['name'] =  $product->name;
                $orderProduct['sub_total'] = $orderProduct['unit_price'] * $orderProduct['qty'];
                $orderProduct['is_resell'] =  $product->is_resell;
                $orderProduct['parent_product_id'] = $product->parent_product_id ?? null;

                $cost = ($product->is_resell) ? ($parentProduct->resell_cost_price * $orderProduct['qty']) : 0.00;

                $data['order']['product_cost'] += $cost;
                $data['order']['total'] += $orderProduct['sub_total'];

                $orderProducts[] = $orderProduct;


                if ($product->is_resell) {
                    $parrentProductShopUserId = $parentProduct->shop->user_id;

                    if (array_key_exists($parrentProductShopUserId, $parentProductSales)) {
                        $parentProductSales[$parrentProductShopUserId] += $cost;
                    } else {
                        $parentProductSales[$parrentProductShopUserId] = $cost;
                    }
                }
            }

            //platform commission
            $platformCommission = $this->_settingRepository->getByMetaKey(SettingMeta::PlatformCommission()->key);
            $platformCommission = $platformCommission->meta_value;

            //insert order
            $data['order']['user_id'] = $userId;
            $data['order']['buyer_email'] = $data['buyer_email'];
            $data['order']['shop_id'] = $shopId;
            $data['order']['platform_commission_percentage'] = $platformCommission;
            $data['order']['platform_commission_amount'] =  ($data['order']['total'] - $data['order']['product_cost']) * ($data['order']['platform_commission_percentage'] / 100);
            $data['order']['seller_profit'] = $data['order']['total'] - $data['order']['product_cost'] - $data['order']['platform_commission_amount'];
            $data['order']['status'] = OrderStatus::CompletePayment()->key;
            $data['order']['is_api_sales'] = true;

            $order = $this->_orderRepository->save($data['order']);


            //insert order products
            $orderProduct = $this->_orderProductMerchantService->bulkCreateOrderProduct($orderProducts, $order->id);

            if ($orderProduct == null) {
                throw new Exception();
            }


            //check shop wallet balance
            $shopWallet = $this->_walletMerchantService->getWalletByUserId($userId);

            if ($shopWallet == null) {
                throw new Exception();
            }

            if ($shopWallet['balance'] < $data['order']['platform_commission_amount']) {
                DB::rollBack();

                return response([
                    "success" => false,
                    "message" => "Your wallet balance is not enough to deduct for platform commission.",
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }


            //update shop wallet balance
            $shopWallet['balance'] -= $data['order']['platform_commission_amount'];

            $data['shop_wallet_transaction']['balance'] = $shopWallet['balance'];
            $data['shop_wallet_transaction']['description'] = "Platform commission for sales order #" . $order->id . " via API.";
            $data['shop_wallet_transaction']['debit'] = null;
            $data['shop_wallet_transaction']['credit'] = $data['order']['platform_commission_amount'];

            $shopWallet = $this->_walletMerchantService->updateBalance($userId, $shopWallet['balance']);

            if ($shopWallet == null) {
                throw new Exception();
            }

            $shopWalletTransaction = $this->_walletTransactionMerchantService->createWalletTransaction($shopWallet['id'], $data['shop_wallet_transaction']);

            if ($shopWalletTransaction == null) {
                throw new Exception();
            }



            //update product's parent product owner wallet balance
            foreach ($parentProductSales as $productOwnerUserId => $parentProductSale) {
                $productOwnerWallet = $this->_walletMerchantService->getWalletByUserId($productOwnerUserId);

                $productOwnerWallet['balance'] = $productOwnerWallet['balance'] + $parentProductSale;

                $data['product_owner_wallet_transaction']['balance'] = $productOwnerWallet['balance'];
                $data['product_owner_wallet_transaction']['debit'] = $parentProductSale;
                $data['product_owner_wallet_transaction']['credit'] = null;
                $data['product_owner_wallet_transaction']['description'] = "Agent sales order #" . $order->id;

                $productOwnerWallet = $this->_walletMerchantService->updateBalance($productOwnerUserId, $productOwnerWallet['balance']);

                if ($shopWallet == null) {
                    throw new Exception();
                }

                $productOwnerWalletTransaction = $this->_walletTransactionMerchantService->createWalletTransaction($productOwnerWallet['id'], $data['product_owner_wallet_transaction']);

                if ($productOwnerWalletTransaction == null) {
                    throw new Exception();
                }
            }


            //platform commission transaction
            $data['platform_commission_transaction']['platform_commission_percentage'] = $platformCommission;
            $data['platform_commission_transaction']['platform_commission_amount'] = $data['order']['total'] * ($data['order']['platform_commission_percentage'] / 100);
            $data['platform_commission_transaction']['order_id'] = $order->id;

            $this->_platformCommissionTransactionRepository->save($data['platform_commission_transaction']);


            DB::commit();
            return response([
                "success" => true,
                "data" => [
                    'id' => $order->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            $this->storeInternalErrorHistory(__CLASS__, __FUNCTION__, $e->getMessage(), json_encode(func_get_args()));

            DB::rollBack();
            return response([
                "success" => false,
                "message" => 'Server Error - Fail to create sales order.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
