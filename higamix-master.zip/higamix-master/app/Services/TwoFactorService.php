<?php

namespace App\Services;

use Exception;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;


class TwoFactorService extends Service
{
    protected $_userRepository;
    protected $_google2fa;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
        $this->_google2fa = app('pragmarx.google2fa');
    }

    public function validateTwoFactorCode($data)
    {
        try {
            $validator = Validator::make($data, [
                'code' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $id = Auth::id();

            $user = $this->_userRepository->getById($id);


            if ($this->_google2fa->verifyKey(decrypt($user['google_2fa_secret']), $data['code']) == false) {
                array_push($this->_errorMessage, "Invalid 2fa code.");

                return null;
            }

            Session::put('passedTwoFactor', true);
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to verify two-factor authentication code.");

            return null;
        }
    }
}
