<?php

namespace App\Services\Merchant;

use Exception;
use Yajra\DataTables\DataTables;
use App\Enums\StockDelimiterType;
use App\Exports\ProductSerialExport;
use App\Repositories\OrderProductRepository;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\Validator;
use App\Repositories\ProductSerialRepository;
use App\Services\Merchant\ShopMerchantService;

class ProductSerialMerchantService extends Service
{
    protected $_productRepository;
    protected $_shopMerchantService;
    protected $_productSerialRepository;
    protected $_orderProductRepository;

    public function __construct(
        ProductRepository $productRepository,
        ShopMerchantService $shopMerchantService,
        ProductSerialRepository $productSerialRepository,
        OrderProductRepository $orderProductRepository
    ) {
        $this->_productRepository = $productRepository;
        $this->_productSerialRepository = $productSerialRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_orderProductRepository = $orderProductRepository;
    }

    public function getById($id)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();

            $productSerial = $this->_productSerialRepository->getById($id);

            if ($productSerial->product->shop_id != $shopId) {
                return false;
            }


            if ($productSerial->is_sold) {
                $productSerial->order_product = $this->_orderProductRepository->getById($productSerial->order_product_id);
            }


            return $productSerial;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product serial details.");

            return null;
        }
    }

    public function getDataTable($filterData)
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('product_serials')
            ->leftJoin('products', 'product_serials.product_id', '=', 'products.id')
            ->leftJoin('order_products', 'product_serials.order_product_id', '=', 'order_products.id')
            ->select([
                'product_serials.id',
                'product_serials.serial_number',
                'product_serials.is_sold',
                'product_serials.created_at',
                'products.name as product_name',
                'order_products.is_resell as order_product_is_resell',
                'order_products.order_id as order_product_order_id'
            ])
            ->where('products.deleted_at', '=', null)
            ->where('products.shop_id', '=', $shopId);

        if (!empty($filterData['order_id'])) {
            $data->where('order_products.order_id', '=', $filterData['order_id']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $productSerial = $this->_productSerialRepository->deleteById($id);

            if ($productSerial->product->shop_id != $shopId || $productSerial->is_sold) {
                throw new Exception();
            }

            DB::commit();
            return $productSerial;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete product serial key.");
            DB::rollBack();
            return null;
        }
    }

    public function updateSoldProductSerial($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'is_sold' => 'required|boolean',
                'order_product_id' => 'required',
                'qty' => 'required|numeric|min:0',
                'product_id' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $totalAvailableProductSerial = $this->getTotalAvailableProductSerialByProductId($data['product_id']);

            if ($data['qty'] > $totalAvailableProductSerial) {
                array_push($this->_errorMessage, "The quantity is over the stock.");

                DB::rollBack();
                return null;
            }

            $productSerialKey = $this->_productSerialRepository->updateSold($data);

            DB::commit();
            return $productSerialKey;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update product serial key.");
            DB::rollBack();
            return null;
        }
    }

    public function getTotalAvailableProductSerialByProductId($productId)
    {
        try {
            $totalUnSoldProductSerial = $this->_productSerialRepository->getTotalUnSoldCountByProductId($productId);

            return $totalUnSoldProductSerial;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total available product serial count.");
            return null;
        }
    }

    public function createProductSerial($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'product_id' => 'required',
                'serials' => 'required',
                'stock_delimiter_type' => 'required|in:' . implode(",", StockDelimiterType::getValues()),
                'remove_duplicate_serials' => 'boolean',
                'custom_delimiter' => 'nullable|required_if:stock_delimiter_type,=,' . StockDelimiterType::Custom,
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $product = $this->_productRepository->getById($data['product_id']);
            $shopId = $this->_shopMerchantService->getShopId();

            if ($product == null || $product->shop_id != $shopId) {
                throw new Exception();
            }

            if ($data['stock_delimiter_type'] == StockDelimiterType::Comma) {
                $delimiter = ",";
            } else if ($data['stock_delimiter_type'] == StockDelimiterType::NewLine) {
                $delimiter = PHP_EOL;
            } else if ($data['stock_delimiter_type'] == StockDelimiterType::Custom) {
                $delimiter = $data["custom_delimiter"];
            }

            $data['serials'] = explode($delimiter, $data['serials']);

            if ($data['remove_duplicate_serials']) {
                $data['serials'] = array_unique($data['serials']);
            }

            $this->_productSerialRepository->bulkSave($data['serials'], $data['product_id']);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add serial key.");
            DB::rollBack();
            return null;
        }
    }

    public function exportProductSerials($data)
    {
        try {
            $validator = Validator::make($data, [
                'product_id' => 'required',
                'is_sold' => 'nullable|boolean',
                'is_export_all' => 'required|boolean',
                'qty' => 'nullable|required_if:is_export_all,=,0|numeric|min:1',
                'delete_after_export' => 'nullable|required_if:is_sold,=,0|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $product = $this->_productRepository->getById($data['product_id']);
            $shopId = $this->_shopMerchantService->getShopId();

            if ($product == null || $product->shop_id != $shopId) {
                throw new Exception();
            }

            return Excel::download(new ProductSerialExport($data), 'product_stock.csv');
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to export product serials.");

            return null;
        }
    }
}
