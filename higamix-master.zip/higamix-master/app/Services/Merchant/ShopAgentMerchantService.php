<?php

namespace App\Services\Merchant;

use App\Repositories\ProductRepository;
use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\ShopAgentRepository;
use App\Services\Merchant\ShopMerchantService;

class ShopAgentMerchantService extends Service
{
    protected $_shopAgentRepository;
    protected $_shopMerchantService;
    protected $_productRepository;

    public function __construct(
        ShopAgentRepository $shopAgentRepository,
        ShopMerchantService $shopMerchantService,
        ProductRepository $productRepository
    ) {
        $this->_shopAgentRepository = $shopAgentRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productRepository = $productRepository;
    }

    public function getDataTable()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('shop_agents')
            ->leftJoin('shops', 'shop_agents.agent_shop_id', '=', 'shops.id')
            ->select([
                'shop_agents.id',
                'shop_agents.shop_id',
                'shops.id as shop_id',
                'shops.name as shop_name',
                'shop_agents.agent_shop_id',
                'shop_agents.is_waiting_approved',
                'shop_agents.is_approved',
                'shop_agents.created_at',
                'shop_agents.updated_at',
            ])
            ->where('shop_agents.shop_id', '=', $shopId);


        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function updateShopAgentRequest($data, $id)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'is_approved' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shopId = $this->_shopMerchantService->getShopId();

            $data['is_waiting_approved'] = false;
            $shopAgent = $this->_shopAgentRepository->update($data, $id);

            if ($shopAgent->shop_id != $shopId) {
                throw new Exception();
            }

            if (!$data['is_approved']) {
                $this->_productRepository->deleteProductByShopIdAndParentProductShopId($shopAgent->agent_shop_id, $shopAgent->shop_id);
            } else {
                $isAvailable = true;
                $this->_productRepository->updateAvailableByParentProductShopIdAndShopId($isAvailable, $shopId, $shopAgent->agent_shop_id);
            }

            DB::commit();
            return $shopAgent;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update shop agent request.");
            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $shopAgent = $this->_shopAgentRepository->getById($id);

            if (
                $shopAgent->shop_id !=
                $shopId
            ) {
                return false;
            }

            return $shopAgent;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get shop agent details.");

            return null;
        }
    }

    public function getPendingAgentRequestTotalCount()
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $total = $this->_shopAgentRepository->getPendingAgentRequestTotalCountByShopId($shopId);

            return $total;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total pending agent request count.");

            return null;
        }
    }
}
