<?php

namespace App\Services\Merchant;

use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Services\Merchant\ShopMerchantService;
use App\Repositories\ProductCategoryRepository;
use App\Repositories\ProductRepository;
use App\Repositories\ProductSubCategoryRepository;

class ProductCategoryMerchantService extends Service
{
    protected $_productCategoryRepository;
    protected $_productSubCategoryRepository;
    protected $_shopMerchantService;
    protected $_productRepository;

    public function __construct(
        ProductCategoryRepository $productCategoryRepository,
        ProductSubCategoryRepository $productSubCategoryRepository,
        ShopMerchantService $shopMerchantService,
        ProductRepository $productRepository
    ) {
        $this->_productCategoryRepository = $productCategoryRepository;
        $this->_productSubCategoryRepository = $productSubCategoryRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productRepository = $productRepository;
    }

    public function createProductCategory($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'sub_category.*.name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $data['shop_id'] = $this->_shopMerchantService->getShopId();
            $productCategory = $this->_productCategoryRepository->save($data);

            if (!empty($data['sub_category'])) {
                $productCategory->sub_category =  $this->_productSubCategoryRepository->bulkSave($data['sub_category'], $productCategory->id);
            }

            DB::commit();
            return $productCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add product category.");

            DB::rollBack();
            return null;
        }
    }

    public function getDataTable()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('product_categories')
            ->select(['id', 'name', 'created_at'])
            ->where('shop_id', '=', $shopId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $productCategory = $this->_productCategoryRepository->getById($id);

            $shopId = $this->_shopMerchantService->getShopId();

            if (
                $productCategory->shop_id !=
                $shopId
            ) {
                return false;
            }

            return $productCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product category details.");

            return null;
        }
    }


    public function updateProductCategory($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $productCategory = $this->_productCategoryRepository->update($data, $id);

            $shopId = $this->_shopMerchantService->getShopId();
            if (
                $productCategory->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            DB::commit();
            return $productCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update product category.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $this->_productRepository->removeProductCategoryIdByProductCategoryId($id);

            $productCategory = $this->_productCategoryRepository->deleteById($id);

            $shopId = $this->_shopMerchantService->getShopId();
            if (
                $productCategory->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            DB::commit();
            return $productCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete product category.");

            DB::rollBack();
            return null;
        }
    }

    public function getSelectOption($data)
    {
        try {
            $data['result_count'] = 5;
            $data['offset'] = ($data['page'] - 1) * $data['result_count'];

            $shopId = $this->_shopMerchantService->getShopId();
            $productCategories = $this->_productCategoryRepository->getAllByShopIdAndSerchTerm($data, $shopId);

            $totalCount = $this->_productCategoryRepository->getTotalCountByShopIdAndSerchTerm($data, $shopId);

            $results = array(
                "results" => $productCategories->toArray(),
                "pagination" => array(
                    "more" => $totalCount < $data['offset'] + $data['result_count'] ? false : true
                )
            );

            return $results;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product category select option list.");

            return null;
        }
    }
}
