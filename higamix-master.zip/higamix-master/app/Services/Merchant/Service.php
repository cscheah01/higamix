<?php

namespace App\Services\Merchant;

class Service
{
    public $_errorMessage = array();
}
