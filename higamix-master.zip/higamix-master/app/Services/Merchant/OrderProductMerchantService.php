<?php

namespace App\Services\Merchant;

use Exception;
use App\Enums\ProductType;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\OrderProductRepository;
use App\Services\Merchant\ProductSerialMerchantService;


class OrderProductMerchantService extends Service
{
    protected $_orderProductRepository;
    protected $_productSerialMerchantService;
    protected $_shopMerchantService;

    public function __construct(
        OrderProductRepository $orderProductRepository,
        ProductSerialMerchantService $productSerialMerchantService,
        ShopMerchantService $shopMerchantService
    ) {
        $this->_orderProductRepository = $orderProductRepository;
        $this->_productSerialMerchantService = $productSerialMerchantService;
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function createOrderProduct($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'order_id' => 'required',
                'product_id' => 'required',
                'name' => 'required|string|max:255',
                'product_type' => 'required|in:' . implode(",", ProductType::getKeys()),
                'qty' => 'required|numeric|min:1',
                'unit_price' => 'required|numeric|between: 0.00,99999999999.99',
                'sub_total' => 'required|numeric|between: 0.00,99999999999.99',
                'is_resell' => 'required|boolean',
                'parent_product_id' => 'nullable',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $orderProduct = $this->_orderProductRepository->save($data);

            if ($data['product_type'] == ProductType::SerialKey()->key) {
                $data['product_serial']['is_sold'] = true;
                $data['product_serial']['qty'] = $data['qty'];
                $data['product_serial']['order_product_id'] = $orderProduct->id;
                $data['product_serial']['product_id'] = $data['parent_product_id'] ?? $data['product_id'];
                $this->_productSerialMerchantService->updateSoldProductSerial($data['product_serial']);
            }

            DB::commit();
            return $orderProduct;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to create order product.");

            DB::rollBack();
            return null;
        }
    }

    public function bulkCreateOrderProduct($data, $orderId)
    {
        DB::beginTransaction();
        try {
            foreach ($data as $eachProduct) {
                $validator = Validator::make($eachProduct, [
                    'product_id' => 'required',
                    'name' => 'required|string|max:255',
                    'product_type' => 'required|in:' . implode(",", ProductType::getKeys()),
                    'qty' => 'required|numeric|min:1',
                    'unit_price' => 'required|numeric|between: 0.00,99999999999.99',
                    'sub_total' => 'required|numeric|between: 0.00,99999999999.99',
                    'is_resell' => 'required|boolean',
                    'parent_product_id' => 'nullable',
                ]);

                if ($validator->fails()) {
                    foreach ($validator->errors()->all() as $error) {
                        array_push($this->_errorMessage, $error);
                    }

                    return null;
                }
            }

            $orderProducts = $this->_orderProductRepository->bulkSave($data, $orderId);

            $productType = ProductType::SerialKey()->key;
            $orderProductId = $this->_orderProductRepository->getSerialKeyProductOrderId($orderId, $productType);

            $i = 0;
            foreach ($data as $product) {
                if ($product['product_type'] == ProductType::SerialKey()->key) {
                    $data['product_serial']['is_sold'] = true;
                    $data['product_serial']['qty'] = $product['qty'];
                    $data['product_serial']['order_product_id'] = $orderProductId[$i]->id;
                    $data['product_serial']['product_id'] = $product['parent_product_id'] ?? $product['product_id'];
                    $serialKey = $this->_productSerialMerchantService->updateSoldProductSerial($data['product_serial']);
                    $i++;
                }
            }
            DB::commit();
            return $orderProducts;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to create order product.");

            DB::rollBack();
            return null;
        }
    }

    public function getAllByOrderId($orderId)
    {
        try {
            $orderProducts = $this->_orderProductRepository->getAllByOrderId($orderId);

            return $orderProducts;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get order product list.");

            return null;
        }
    }

    public function getAgentSalesProductDataTable($filterData)
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('order_products')
            ->leftJoin('orders', 'order_products.order_id', '=', 'orders.id')
            ->leftJoin('products', 'order_products.product_id', '=', 'products.id')
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftJoin('shops', 'orders.shop_id', '=', 'shops.id')
            ->select([
                'order_products.order_id',
                'shops.name as agent_shop_name',
                'parent_product.name as parent_product_name',
                'order_products.product_type',
                'order_products.qty',
                'order_products.created_at',
            ])
            ->where('order_products.is_resell', '=', true)
            ->where('parent_product.shop_id', '=', $shopId);

        if (!empty($filterData['order_id'])) {
            $data->where('order_products.order_id', '=', $filterData['order_id']);
        }

        if (!empty($filterData['date_from'])) {
            $data->where('order_products.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('order_products.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->addColumn('product_type_label', '{{App\Enums\ProductType::fromKey($product_type)->description}}')
            ->make();

        return $result;
    }
}
