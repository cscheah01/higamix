<?php

namespace App\Services\Merchant;

use Exception;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ProfileMerchantService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }


    public function getProfile()
    {
        try {
            $id = Auth::id();
            $profile = $this->_userRepository->getById($id);
            $profile = $profile->toArray();
            $profile['api_secret_key'] = decrypt($profile['api_secret_key']);

            return $profile;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get profile details.");

            return null;
        }
    }

    public function updateProfile($data)
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();

            $validator = Validator::make($data, [
                'email' => 'required|string|email|max:255|unique:users,email,' . $id,
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_userRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update profile details.");

            DB::rollBack();
            return null;
        }
    }

    public function regenerateApiSecretKey()
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();
            $data['api_secret_key'] = Str::random(5) . Str::uuid() . Str::random(5);

            $result = $this->_userRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to reset API secret key.");

            DB::rollBack();
            return null;
        }
    }

    public function regenerateApiPublicKey()
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();
            $data['api_public_key'] = Str::random(5) . Str::uuid() . Str::random(5);

            $result = $this->_userRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to reset API public key.");

            DB::rollBack();
            return null;
        }
    }

    public function updatePassword($data)
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();
            $user = $this->_userRepository->getById($id);


            $validator = Validator::make($data, [
                'current_password' => ['required', function ($attribute, $value, $fail) use ($user) {
                    if (!Hash::check($value, $user->password)) {
                        return $fail(__('The current password is incorrect.'));
                    }
                }],
                'password' => 'required|confirmed|min:8',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }


            $this->_userRepository->update($data, $id);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update password.");

            DB::rollBack();
            return null;
        }
    }
}
