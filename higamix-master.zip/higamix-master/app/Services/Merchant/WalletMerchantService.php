<?php

namespace App\Services\Merchant;

use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\WalletRepository;
use App\Services\PlatformSettingService;
use Illuminate\Support\Facades\Validator;
use App\Repositories\WalletTransactionRepository;
use App\Repositories\WalletWithdrawalRequestRepository;
use App\Repositories\WithdrawalTransactionFeeRepository;

class WalletMerchantService extends Service
{
    protected $_walletRepository;
    protected $walletWithdrawalRequestRepository;
    protected $_settingRepository;
    protected $_walletTransactionRepository;
    protected $_withdrawalTransactionFeeRepository;

    public function __construct(
        WalletRepository $walletRepository,
        WalletWithdrawalRequestRepository $walletWithdrawalRequestRepository,
        PlatformSettingService $platformSettingService,
        WalletTransactionRepository $walletTransactionRepository,
        WithdrawalTransactionFeeRepository $withdrawalTransactionFeeRepository
    ) {
        $this->_walletRepository = $walletRepository;
        $this->_walletWithdrawalRequestRepository = $walletWithdrawalRequestRepository;
        $this->_platformSettingService = $platformSettingService;
        $this->_walletTransactionRepository = $walletTransactionRepository;
        $this->_withdrawalTransactionFeeRepository = $withdrawalTransactionFeeRepository;
    }

    public function createWalletByUserId($userId)
    {
        DB::beginTransaction();
        try {
            $data['user_id'] = $userId;
            $wallet = $this->_walletRepository->save($data);

            DB::commit();
            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to create wallet.");
            DB::rollBack();
            return null;
        }
    }

    public function getWalletByUserId($userId)
    {
        try {
            $data = $this->_walletRepository->getByUserId($userId);
            $wallet = $data->toArray();

            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet details.");

            return null;
        }
    }

    public function getDataTable()
    {
        $wallet = $this->_walletRepository->getByUserId(Auth::id());
        $walletId = $wallet->id;

        $data = DB::table('wallet_transactions')

            ->select([
                'wallet_transactions.created_at',
                'wallet_transactions.debit',
                'wallet_transactions.credit',
                'wallet_transactions.balance',
                'wallet_transactions.description',
                'wallet_transactions.order_id',
            ])
            ->where('wallet_id', '=', $walletId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function updateBalance($userId, $balance)
    {
        DB::beginTransaction();
        try {
            $data['balance'] = $balance;

            $wallet = $this->_walletRepository->updateByUserId($data, $userId);

            DB::commit();
            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update wallet balance.");
            DB::rollBack();
            return null;
        }
    }

    public function updateWithdrawalSetting($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'withdraw_address' => 'nullable|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $wallet = $this->_walletRepository->updateByUserId($data, $userId);

            DB::commit();
            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update payment setting.");
            DB::rollBack();
            return null;
        }
    }

    public function walletWithdrawRequest($data)
    {
        DB::beginTransaction();
        try {
            $minimumWithdrawAmount = $this->_platformSettingService->getMinimumWithdrawAmount();

            $validator = Validator::make($data, [
                'amount' => 'required|numeric|between: 0.00,99999999999.99|min:' . $minimumWithdrawAmount,
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $wallet = $this->getWalletByUserId($userId);

            //checking withdrawal address
            if ($wallet['withdraw_address'] == null) {
                array_push($this->_errorMessage, "Withdrawal wallet address have not set.");
                throw new Exception();
            }

            //checking balance
            if ($data['amount'] > $wallet['balance']) {
                array_push($this->_errorMessage, "Insufficient wallet balance.");
                throw new Exception();
            }


            //update balance
            $data['balance'] = $wallet['balance'] - $data['amount'];
            $wallet = $this->_walletRepository->updateByUserId($data, $userId);


            //create withdrawal request
            $data['wallet_withdrawal_request']['transaction_fee'] = 0;

            $walletTransactionFees = $this->_withdrawalTransactionFeeRepository->getAll();

            foreach ($walletTransactionFees as $walletTransactionFee) {
                if ($data['amount'] >= $walletTransactionFee['amount_more_than_equal']) {
                    $data['wallet_withdrawal_request']['transaction_fee'] = $walletTransactionFee['fee'];
                }
            }

            $data['wallet_withdrawal_request']['user_id'] = $userId;
            $data['wallet_withdrawal_request']['amount'] = $data['amount'];
            $data['wallet_withdrawal_request']['withdraw_address'] = $wallet['withdraw_address'];
            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->save($data['wallet_withdrawal_request']);


            //create wallet transaction log
            $data['wallet_transaction']['wallet_id'] = $wallet['id'];
            $data['wallet_transaction']['balance'] = $data['balance'];
            $data['wallet_transaction']['credit'] = $data['amount'];
            $data['wallet_transaction']['description'] = 'Request withdraw ' . $data['amount'] . ' USDT. Transaction fee: ' . $data['wallet_withdrawal_request']['transaction_fee'] . ' USDT';

            $walletTransaction = $this->_walletTransactionRepository->save($data['wallet_transaction']);

            DB::commit();
            return $walletWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to send wallet withdrawal request.");
            DB::rollBack();
            return null;
        }
    }
}
