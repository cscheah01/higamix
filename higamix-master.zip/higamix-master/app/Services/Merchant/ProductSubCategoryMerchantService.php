<?php

namespace App\Services\Merchant;

use Exception;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\ProductCategoryRepository;
use App\Repositories\ProductRepository;
use App\Repositories\ProductSubCategoryRepository;

class ProductSubCategoryMerchantService extends Service
{
    protected $_productSubCategoryRepository;
    protected $_shopMerchantService;
    protected $_productCategoryRepository;
    protected $_productRepository;

    public function __construct(
        ProductSubCategoryRepository $productSubCategoryRepository,
        ShopMerchantService $shopMerchantService,
        ProductCategoryRepository $productCategoryRepository,
        ProductRepository $productRepository
    ) {
        $this->_productSubCategoryRepository = $productSubCategoryRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productCategoryRepository = $productCategoryRepository;
        $this->_productRepository = $productRepository;
    }


    public function getDataTable()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('product_sub_categories')
            ->leftjoin('product_categories', 'product_sub_categories.product_category_id', '=', 'product_categories.id')
            ->select([
                'product_sub_categories.id',
                'product_sub_categories.name',
                'product_sub_categories.created_at',
                'product_sub_categories.product_category_id',
                'product_categories.name as product_category_name'
            ])
            ->where('product_categories.shop_id', '=', $shopId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {

            $this->_productRepository->removeProductSubCategoryIdByProductSubCategoryId($id);
            $productSubCategory = $this->_productSubCategoryRepository->deleteById($id);
            $shopId = $this->_shopMerchantService->getShopId();

            if (
                $productSubCategory->productCategory->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            DB::commit();
            return $productSubCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete product sub category.");

            DB::rollBack();
            return null;
        }
    }

    public function getById($id)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $productSubCategory = $this->_productSubCategoryRepository->getById($id);

            if (
                $productSubCategory->productCategory->shop_id !=
                $shopId
            ) {
                return false;
            }

            return $productSubCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product sub category details.");

            return null;
        }
    }

    public function updateProductSubCategory($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $productSubCategory = $this->_productSubCategoryRepository->update($data, $id);
            $shopId = $this->_shopMerchantService->getShopId();

            if (
                $productSubCategory->productCategory->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            DB::commit();
            return $productSubCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update product sub category.");

            DB::rollBack();
            return null;
        }
    }

    public function createProductSubCategory($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'product_category_id' => 'required',
                'product_sub_category.*.name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $productCategory = $this->_productCategoryRepository->getById($data['product_category_id']);
            $shopId = $this->_shopMerchantService->getShopId();

            if (
                $productCategory->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            $productSubCategory = $this->_productSubCategoryRepository->bulkSave($data['product_sub_category'], $productCategory->id);


            DB::commit();
            return $productSubCategory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add product sub category.");

            DB::rollBack();
            return null;
        }
    }

    public function getSelectOption($data)
    {
        $data['result_count'] = 5;
        $data['offset'] = ($data['page'] - 1) * $data['result_count'];

        $producrSubCategories = $this->_productSubCategoryRepository->getAllByProductCategoryIdAndSerchTerm($data);

        $totalCount = $this->_productSubCategoryRepository->getTotalCountByProductCategoryIdAndSerchTerm($data);

        $results = array(
            "results" => $producrSubCategories->toArray(),
            "pagination" => array(
                "more" => $totalCount < $data['offset'] + $data['result_count'] ? false : true
            )
        );

        return $results;
    }
}
