<?php

namespace App\Services\Merchant;

use Image;
use Exception;
use App\Enums\ProductType;
use Illuminate\Support\Str;
use Yajra\DataTables\DataTables;
use App\Enums\StockDelimiterType;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Services\Merchant\ShopMerchantService;
use App\Repositories\ProductCategoryRepository;
use App\Repositories\ProductDiscountRepository;
use App\Repositories\ProductSubCategoryRepository;
use App\Services\Merchant\ProductDiscountMerchantService;

class ProductMerchantService extends Service
{
    protected $_productRepository;
    protected $_shopMerchantService;
    protected $_productDiscountRepository;
    protected $_productDiscountMerchantService;
    protected $_productCategoryRepository;
    protected $_productSubCategoryRepository;
    protected $_productSerialMerchantService;

    public function __construct(
        ProductRepository $productRepository,
        ShopMerchantService $shopMerchantService,
        ProductDiscountRepository $productDiscountRepository,
        ProductDiscountMerchantService $productDiscountMerchantService,
        ProductCategoryRepository $productCategoryRepository,
        ProductSubCategoryRepository $productSubCategoryRepository,
        ProductSerialMerchantService $productSerialMerchantService
    ) {
        $this->_productRepository = $productRepository;
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productDiscountRepository = $productDiscountRepository;
        $this->_productCategoryRepository = $productCategoryRepository;
        $this->_productSubCategoryRepository = $productSubCategoryRepository;
        $this->_productSerialMerchantService = $productSerialMerchantService;
    }

    public function createProduct($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'description' => 'nullable|string|max:16777215',
                'product_category_id' => 'required',
                'product_sub_category_id' => 'nullable',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'is_open_resell' => 'required|boolean',
                'resell_cost_price' => 'nullable|required_if:is_open_resell,=,1|numeric|between: 0.00,99999999999.99',
                'suggested_min_resell_price' => 'nullable|required_if:is_open_resell,=,1|numeric|between: 0.00,99999999999.99|min:' . $data['resell_cost_price'],
                'min_purchase_qty' => 'required|integer|min:1',
                'max_purchase_qty' => ['required', 'integer', function ($attribute, $value, $fail) use ($data) {
                    if ($value != 0 && $value < $data['min_purchase_qty']) {
                        return $fail(__('The max purchase quantity should not less than min purchase quantity.'));
                    }
                }],
                'product_type' => 'required|in:' . implode(",", ProductType::getKeys()),
                'service_description' => 'nullable|string|max:16777215|required_if:product_type,=,' . ProductType::Service()->key,
                'is_available' => 'required|boolean',
                'serials' => 'nullable',
                'stock_delimiter_type' => 'nullable|required_if:product_type,=,' . ProductType::SerialKey()->key . '|in:' . implode(",", StockDelimiterType::getValues()),
                'remove_duplicate_serials' => 'nullable|required_if:product_type,=,' . ProductType::SerialKey()->key . '|boolean',
                'custom_delimiter' => 'nullable|required_if:stock_delimiter_type,=,' . StockDelimiterType::Custom,
                'product_discount' => 'array|nullable',
                'product_discount.*.min_qty' => 'required|integer|min:1',
                'product_discount.*.discounted_price' => 'required|numeric|between: 0.00,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }


            $data['shop_id'] = $this->_shopMerchantService->getShopId();

            //check product category id
            $productCategory = $this->_productCategoryRepository->getById($data['product_category_id']);
            if ($productCategory == null || $productCategory->shop_id != $data['shop_id']) {
                throw new Exception();
            }

            //check product sub category id
            if (!empty($data['product_sub_category_id'])) {
                $productSubCategory = $this->_productSubCategoryRepository->getById($data['product_sub_category_id']);

                if ($productSubCategory == null || $productSubCategory->product_category_id != $data['product_category_id']) {
                    throw new Exception();
                }
            }

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/product_image');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                $data['image'] = $fileName;
            } else {
                $data['image'] = null;
            }

            $product = $this->_productRepository->save($data);

            if (!empty($data['product_discount'])) {
                $product->productDiscount =  $this->_productDiscountRepository->bulkSave($data['product_discount'], $product->id);
            }

            if (!empty($data['serials'])) {
                if ($data['product_type'] == ProductType::SerialKey()->key) {
                    $data['product_serial']['product_id'] = $product->id;
                    $data['product_serial']['serials'] = $data['serials'];
                    $data['product_serial']['stock_delimiter_type'] = $data['stock_delimiter_type'];
                    $data['product_serial']['remove_duplicate_serials'] = $data['remove_duplicate_serials'];
                    $data['product_serial']['custom_delimiter'] = $data["custom_delimiter"] ?? null;

                    $this->_productSerialMerchantService->createProductSerial($data['product_serial']);
                }
            }

            DB::commit();
            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to create product.");

            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getProductById($id)
    {
        try {
            $product = $this->_productRepository->getById($id);

            if (
                $product == null || $product->is_resell == true
            ) {
                return false;
            }

            if ($product->product_type == ProductType::SerialKey()->key) {
                $product->stock_qty = $this->_productSerialMerchantService->getTotalAvailableProductSerialByProductId($product->id);
            }

            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product details.");

            return null;
        }
    }

    public function getDataTableByShopId($shopId)
    {
        $data = DB::table('products')
            ->leftJoin('product_categories', 'products.product_category_id', 'product_categories.id')
            ->leftJoin('product_sub_categories', 'products.product_sub_category_id', 'product_sub_categories.id')
            ->select([
                'products.id',
                'products.product_type',
                'products.product_type as product_type_key',
                'products.price',
                'products.is_available',
                'products.is_open_resell',
                'products.min_purchase_qty',
                'products.max_purchase_qty',
                'products.name',
                'products.created_at',
                'products.shop_id',
                'products.is_resell',
                'products.resell_cost_price',
                'products.suggested_min_resell_price',
                'product_categories.id as product_category_id',
                'product_sub_categories.id as product_sub_category_id',
                DB::raw('
                    CASE
                    WHEN
                        products.is_resell
                    THEN
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.parent_product_id AND is_sold = 0)
                    ELSE
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.id AND is_sold = 0)
                    END
                    as stock_qty'),
            ])
            ->where('products.is_resell', '=', false)
            ->where('products.shop_id', '=', $shopId)
            ->where('products.deleted_at', '=', null);

        $result = DataTables::of($data)
            ->editColumn('product_type', '{{App\Enums\ProductType::fromkey($product_type)->description}}')
            ->make();

        return $result;
    }

    public function deleteProductById($id)
    {
        DB::beginTransaction();

        try {
            $product = $this->_productRepository->deleteById($id);
            $this->_productRepository->deleteByParentProductId($id);

            $shopId = $this->_shopMerchantService->getShopId();

            if (
                $product->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            DB::commit();
            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete product.");

            DB::rollBack();
            return null;
        }
    }

    public function updateProduct($data, $id)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'nullable|max:2048',
                'remove_image' => 'required|boolean',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'description' => 'nullable|string|max:16777215',
                'is_open_resell' => 'required|boolean',
                'resell_cost_price' => 'nullable|required_if:is_open_resell,=,1|numeric|between: 0.00,99999999999.99',
                'suggested_min_resell_price' => 'nullable|required_if:is_open_resell,=,1|numeric|between: 0.00,99999999999.99|min:' . $data['resell_cost_price'],
                'product_category_id' => 'required',
                'product_sub_category_id' => 'nullable',
                'min_purchase_qty' => 'required|integer|min:1',
                'max_purchase_qty' => ['required', 'integer', function ($attribute, $value, $fail) use ($data) {
                    if ($value != 0 && $value < $data['min_purchase_qty']) {
                        return $fail(__('The max purchase quantity should not less than min purchase quantity.'));
                    }
                }],
                'is_available' => 'required|boolean',
                'service_description' => 'nullable|string|max:16777215|required_if:product_type,=,' . ProductType::Service()->key,
                'product_discount' => 'array|nullable',
                'product_discount.*.min_qty' => 'required|integer|min:1',
                'product_discount.*.discounted_price' => 'required|numeric|between: 0.00,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $data['shop_id'] = $this->_shopMerchantService->getShopId();

            $product = $this->_productRepository->getById($id);

            if ($product->shop_id != $data['shop_id']) {
                throw new Exception();
            }

            $productCategory = $this->_productCategoryRepository->getById($data['product_category_id']);
            if ($productCategory == null || $productCategory->shop_id != $data['shop_id']) {
                throw new Exception();
            }

            if (!empty($data['product_sub_category_id'])) {
                $productSubCategory = $this->_productSubCategoryRepository->getById($data['product_sub_category_id']);

                if ($productSubCategory == null || $productSubCategory->product_category_id != $data['product_category_id']) {
                    throw new Exception();
                }
            }

            if ($data['remove_image']) {
                if (Storage::exists('public/product_image/' . $product->image)) {
                    Storage::delete('public/product_image/' . $product->image);
                }

                $data['image'] = null;
            } else if (!$data['remove_image'] && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/product_image');
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                if (Storage::exists('public/product_image/' . $product->image)) {
                    Storage::delete('public/product_image/' . $product->image);
                }

                $data['image'] = $fileName;
            }

            $product = $this->_productRepository->updateProduct($data, $id);

            $this->_productDiscountMerchantService->deleteByProductId($id);
            if (!empty($data['product_discount'])) {
                $product->productDiscount =  $this->_productDiscountRepository->bulkSave($data['product_discount'], $product->id);
            }

            if (!$data['is_open_resell']) {
                $this->_productRepository->deleteByParentProductId($id);
            }


            $this->_productRepository->updateAvailableByParentProductIdAndShopId($data['is_available'], $id, $data['shop_id']);


            DB::commit();
            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update product.");
            DB::rollBack();
            return null;
        }
    }

    public function getSelectOption($data)
    {
        $data['result_count'] = 5;
        $data['offset'] = ($data['page'] - 1) * $data['result_count'];

        $shopId = $this->_shopMerchantService->getShopId();
        $productType = ProductType::SerialKey()->key;
        $products = $this->_productRepository->getAllByShopIdAndSerchTermAndProductType($data, $shopId, $productType);

        $totalCount = $this->_productRepository->getTotalCountByShopIdAndSerchTermAndProductType($data, $shopId, $productType);

        $results = array(
            "results" => $products->toArray(),
            "pagination" => array(
                "more" => $totalCount < $data['offset'] + $data['result_count'] ? false : true
            )
        );

        return $results;
    }

    public function getDataTable()
    {
        $data = DB::table('products')
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftJoin('shops', 'products.shop_id', '=', 'shops.id')
            ->leftJoin('shop_agents', 'products.shop_id', '=', 'shop_agents.shop_id')
            ->select([
                'products.id',
                'products.product_type',
                'parent_product.product_type as resell_product_type',
                'products.price',
                'products.name',
                'products.resell_cost_price',
                'products.product_category_id',
                'products.min_purchase_qty',
                'products.max_purchase_qty',
                'products.shop_id',
                'parent_product.shop_id as parent_product_shop_id',
                'shops.id as shop_id',
                'shops.name as shop_name',
                'shops.agent_connect_code as shops_agent_connect_code',
                'parent_product.min_purchase_qty as parent_product_min_purchase_qty',
                'parent_product.max_purchase_qty as parent_product_max_purchase_qty',
                'shop_agents.agent_shop_id as agent_shop_id',
                DB::raw('(parent_product.resell_cost_price + products.resell_profit) as resell_price'),
            ])
            ->where('products.is_available', '=', true)
            ->where('products.deleted_at', '=', null);

        $result = DataTables::of($data)
            ->addColumn('product_type', '{{App\Enums\ProductType::fromKey($product_type??$resell_product_type)->description}}')
            ->make();

        return $result;
    }
}
