<?php

namespace App\Services\Merchant;

use Exception;
use App\Enums\NotificationType;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Services\NotificationService;
use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\Validator;
use App\Repositories\ProductLogRepository;
use App\Services\Merchant\ShopMerchantService;
use App\Repositories\ProductCategoryRepository;
use App\Repositories\ProductSubCategoryRepository;

class ProductLogMerchantService extends Service
{
    protected $_productLogRepository;
    protected $_shopMerchantService;
    protected $_productRepository;
    protected $_discordBotMerchantService;
    protected $_notificationService;
    protected $_productCategoryRepository;
    protected $_productSubCategoryRepository;

    public function __construct(
        ProductLogRepository $productLogRepository,
        ShopMerchantService $shopMerchantService,
        ProductRepository $productRepository,
        DiscordBotMerchantService $discordBotMerchantService,
        NotificationService $notificationService,
        ProductCategoryRepository $productCategoryRepository,
        ProductSubCategoryRepository $productSubCategoryRepository
    ) {
        $this->_productLogRepository = $productLogRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productRepository = $productRepository;
        $this->_discordBotMerchantService = $discordBotMerchantService;
        $this->_notificationService = $notificationService;
        $this->_productCategoryRepository = $productCategoryRepository;
        $this->_productSubCategoryRepository = $productSubCategoryRepository;
    }

    public function getDataTable($id, $type)
    {

        $data = DB::table('product_logs')
            ->select([
                'product_logs.id',
                'product_logs.product_id',
                'product_logs.product_category_id',
                'product_logs.product_sub_category_id',
                'product_logs.content',
                'product_logs.created_at'
            ]);

        if ($type == NotificationType::Product()) {
            $data->where('product_logs.product_id', '=', $id);
        } else if ($type == NotificationType::ProductCategory()) {
            $data->where('product_logs.product_category_id', '=', $id);
        } else if ($type == NotificationType::ProductSubCategory()) {
            $data->where('product_logs.product_sub_category_id', '=', $id);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function createLog($data, $id, $type)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'content' => 'required|string|max:2000',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }
            $shopId = $this->_shopMerchantService->getShopId();

            if ($type == NotificationType::Product()) {
                $product = $this->_productRepository->getById($id);

                if ($product->shop_id != $shopId) {
                    throw new Exception();
                }

                $data['product_id'] = $id;
            } else if ($type == NotificationType::ProductCategory()) {
                $productCategory = $this->_productCategoryRepository->getById($id);

                if ($productCategory->shop_id != $shopId) {
                    throw new Exception();
                }

                $product = $this->_productRepository->getByProductCategoryId($id);

                $data['product_category_id'] = $id;
            } else if ($type == NotificationType::ProductSubCategory()) {
                $productSubCategory = $this->_productSubCategoryRepository->getById($id);

                if ($productSubCategory->productCategory->shop_id != $shopId) {
                    throw new Exception();
                }

                $product = $this->_productRepository->getByProductCategoryId($id);

                $data['product_sub_category_id'] = $id;
            }

            $productLog = $this->_productLogRepository->save($data);

            //discord notification
            $this->_discordBotMerchantService->sendDiscordNotificationToAllReseller($data['content'], $id, $type);

            //telegram notification
            $shop = $this->_shopMerchantService->getShopDetails();
            if ($shop['is_enabled_telegram_notification'] == true) {
                $sendTelegramNotification = $this->_shopMerchantService->sendTelegramNotification($data['content'], $product, $type);
            }

            //platform notification
            $this->_notificationService->createNewLogNotification($productLog, $type);

            DB::commit();
            return $productLog;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add product log.");

            DB::rollBack();
            return null;
        }
    }
}
