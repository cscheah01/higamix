<?php

// namespace App\Services\Merchant;

// use Exception;
// use Yajra\DataTables\DataTables;
// use Illuminate\Support\Facades\DB;
// use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\Validator;
// use App\Repositories\InviteCodeRepository;

// class InviteCodeMerchantService extends Service
// {
//     protected $_inviteCodeRepository;
//     protected $_shopMerchantService;

//     public function __construct(
//         InviteCodeRepository $inviteCodeRepository,
//         ShopMerchantService $shopMerchantService
//     ) {
//         $this->_inviteCodeRepository = $inviteCodeRepository;
//         $this->_shopMerchantService = $shopMerchantService;
//     }

//     public function createInviteCode($data)
//     {
//         DB::beginTransaction();

//         try {
//             $validator = Validator::make($data, [
//                 'code' => 'required|string|max:255|min:10|unique:invite_codes,code',
//             ]);

//             if ($validator->fails()) {
//                 foreach ($validator->errors()->all() as $error) {
//                     array_push($this->_errorMessage, $error);
//                 }

//                 return null;
//             }

//             $data['user_id'] = Auth::id();;

//             $inviteCode = $this->_inviteCodeRepository->save($data);

//             DB::commit();
//             return $inviteCode;
//         } catch (Exception $e) {
//             array_push($this->_errorMessage, "Fail to add invite code.");

//             DB::rollBack();
//             return null;
//         }
//     }

//     public function getDataTable()
//     {
//         $userId = Auth::id();;
//         $data = DB::table('invite_codes')
//             ->leftJoin('users', 'invite_codes.used_by', 'users.id')
//             ->select([
//                 'invite_codes.id',
//                 'invite_codes.code',
//                 'invite_codes.is_used',
//                 'users.email as user_email',
//                 'invite_codes.created_at'
//             ])->where('invite_codes.user_id', '=', $userId);

//         $result = DataTables::of($data)
//             ->make();

//         return $result;
//     }

//     public function deleteById($id)
//     {
//         DB::beginTransaction();

//         try {
//             $inviteCode = $this->getById($id);

//             $userId = Auth::id();
//             if (
//                 $inviteCode->user_id !=
//                 $userId || $inviteCode->is_used
//             ) {
//                 throw new Exception();
//             }

//             $inviteCode = $this->_inviteCodeRepository->deleteById($id);

//             DB::commit();
//             return $inviteCode;
//         } catch (Exception $e) {
//             array_push($this->_errorMessage, "Fail to delete invite code.");

//             DB::rollBack();
//             return null;
//         }
//     }

//     public function getById($id)
//     {
//         try {
//             $userId = Auth::id();;
//             $inviteCode = $this->_inviteCodeRepository->getById($id);

//             if (
//                 $inviteCode->user_id !=
//                 $userId
//             ) {
//                 return false;
//             }

//             return $inviteCode;
//         } catch (Exception $e) {
//             array_push($this->_errorMessage, "Fail to get invite code details.");

//             return null;
//         }
//     }
// }
