<?php

namespace App\Services\Merchant;

use Exception;
use App\Repositories\ProductDiscountRepository;
use Illuminate\Support\Facades\DB;

class ProductDiscountMerchantService extends Service
{
    protected $_productDiscountRepository;

    public function __construct(
        ProductDiscountRepository $productDiscountRepository
    ) {
        $this->_productDiscountRepository = $productDiscountRepository;
    }

    public function deleteByProductId($productId)
    {
        DB::beginTransaction();
        try {
            $productDiscount = $this->_productDiscountRepository->deleteByProductId($productId);

            DB::commit();
            return $productDiscount;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete product discount.");
            DB::rollBack();
            return null;
        }
    }

    public function getAllProductDiscountByProductId($productId)
    {
        try {
            $productDiscounts = $this->_productDiscountRepository->getAllByProductId($productId);

            return $productDiscounts;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get product discount list.");
            return null;
        }
    }
}
