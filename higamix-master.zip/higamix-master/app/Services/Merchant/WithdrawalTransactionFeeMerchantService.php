<?php

namespace App\Services\Merchant;

use Exception;

use App\Repositories\WithdrawalTransactionFeeRepository;

class WithdrawalTransactionFeeMerchantService extends Service
{
    protected $_withdrawalTransactionFeeRepository;

    public function __construct(

        WithdrawalTransactionFeeRepository $withdrawalTransactionFeeRepository
    ) {

        $this->_withdrawalTransactionFeeRepository = $withdrawalTransactionFeeRepository;
    }

    public function getWithdrawalTransactionFee()
    {
        try {
            $data = $this->_withdrawalTransactionFeeRepository->getAll();

            $withdrawalTransactionFee = $data->toArray();

            return $withdrawalTransactionFee;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get withdrawal transaction fee.");

            return null;
        }
    }
}
