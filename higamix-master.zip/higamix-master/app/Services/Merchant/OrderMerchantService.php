<?php

namespace App\Services\Merchant;

use Exception;
use Carbon\Carbon;
use App\Enums\OrderStatus;
use App\Enums\ProductType;
use App\Enums\SettingMeta;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\OrderRepository;
use App\Repositories\PlatformCommissionTransactionRepository;
use App\Repositories\ProductRepository;
use App\Repositories\SettingRepository;
use App\Repositories\ShopAgentRepository;
use Illuminate\Support\Facades\Validator;
use App\Services\Merchant\ShopMerchantService;
use App\Services\Merchant\WalletMerchantService;
use App\Services\Merchant\OrderProductMerchantService;
use App\Services\Merchant\ProductSerialMerchantService;
use App\Services\Merchant\WalletTransactionMerchantService;

class OrderMerchantService extends Service
{
    protected $_productRepository;
    protected $_orderRepository;
    protected $_productSerialMerchantService;
    protected $_walletMerchantService;
    protected $_walletTransactionMerchantService;
    protected $_orderProductMerchantService;
    protected $_shopMerchantService;
    protected $_productDiscountMerchantService;
    protected $_settingRepository;
    protected $_platformCommissionTransactionRepository;
    protected $_shopAgentRepository;

    public function __construct(
        ProductRepository $productRepository,
        OrderRepository $orderRepository,
        ProductSerialMerchantService $productSerialMerchantService,
        WalletMerchantService $walletMerchantService,
        WalletTransactionMerchantService $walletTransactionMerchantService,
        OrderProductMerchantService $orderProductMerchantService,
        ShopMerchantService $shopMerchantService,
        ProductDiscountMerchantService $productDiscountMerchantService,
        SettingRepository $settingRepository,
        PlatformCommissionTransactionRepository $platformCommissionTransactionRepository,
        ShopAgentRepository $shopAgentRepository
    ) {
        $this->_productRepository = $productRepository;
        $this->_orderRepository = $orderRepository;
        $this->_productSerialMerchantService = $productSerialMerchantService;
        $this->_walletMerchantService = $walletMerchantService;
        $this->_walletTransactionMerchantService = $walletTransactionMerchantService;
        $this->_orderProductMerchantService = $orderProductMerchantService;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productDiscountMerchantService = $productDiscountMerchantService;
        $this->_settingRepository = $settingRepository;
        $this->_platformCommissionTransactionRepository = $platformCommissionTransactionRepository;
        $this->_shopAgentRepository = $shopAgentRepository;
    }

    public function getSalesOrderDataTable($filterData)
    {
        $shopId = $this->_shopMerchantService->getShopId();
        $data = DB::table('orders')
            ->leftJoin('users', 'orders.user_id', '=', 'users.id')
            ->select([
                'orders.id',
                'users.email',
                'orders.buyer_email',
                'orders.total',
                'orders.created_at',
                'orders.status',
                'orders.is_api_sales',
            ])
            ->where('orders.shop_id', '=', $shopId);

        if (!empty($filterData['id'])) {
            $data->where('orders.id', '=', $filterData['id']);
        }

        if (!empty($filterData['date_from'])) {
            $data->where('orders.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('orders.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->addColumn('status_label', '{{App\Enums\OrderStatus::fromKey($status)->description}}')
            ->make();

        return $result;
    }

    public function getPurchaseOrderDataTable($filterData)
    {
        $userId = Auth::id();
        $data = DB::table('orders')
            ->leftJoin('shops', 'orders.shop_id', '=', 'shops.id')
            ->select([
                'orders.id',
                'orders.total',
                'orders.status',
                'orders.created_at',
                'shops.id as shop_id',
                'shops.name as shop_name'
            ])
            ->where('orders.user_id', '=', $userId)
            ->where('orders.is_api_sales', '=', false);

        if (!empty($filterData['id'])) {
            $data->where('orders.id', '=', $filterData['id']);
        }

        if (!empty($filterData['date_from'])) {
            $data->where('orders.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('orders.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->addColumn('status_label', '{{App\Enums\OrderStatus::fromKey($status)->description}}')
            ->make();

        return $result;
    }

    public function getOrderById($id)
    {
        try {
            $order = $this->_orderRepository->getById($id);

            $shopId = $this->_shopMerchantService->getShopId();
            $userId = Auth::id();

            if ($order->shop_id != $shopId && $order->user_id != $userId) {
                return false;
            }

            return $order;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get order details.");

            return null;
        }
    }

    public function createOrder($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'qty' => 'required|numeric|min:1',
                'product_id' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            //get buyer id
            $data['user_id'] = Auth::id();
            $data['buyer_email'] = Auth::user()->email;
            $shopId = $this->_shopMerchantService->getShopId();

            //get product details
            $product = $this->_productRepository->getById($data['product_id']);

            if ($product == null || !$product->is_available) {
                throw new Exception();
            }

            $parentProduct = $this->_productRepository->getById($product->parent_product_id);
            $parentProductShopId = $parentProduct != null ? $parentProduct->shop_id : null;

            if ($product->shop_id == $shopId || $parentProductShopId == $shopId) {
                array_push($this->_errorMessage, "Not allowed to purchase own product.");
                DB::rollBack();
                return null;
            }

            //check purchase quantity cannot more than max purchase qty of the product
            $maxPurchaseQuantity = $product->parent_product_id ? $parentProduct->max_purchase_qty : $product->max_purchase_qty;

            if ($maxPurchaseQuantity != 0 && $data['qty'] > $maxPurchaseQuantity) {
                array_push($this->_errorMessage, "Your purchase quantity is over the maximum purchase quantity.");
                DB::rollBack();
                return null;
            }

            //check serial key stock
            $data['product_type'] = $product->parent_product_id ? $parentProduct->product_type : $product->product_type;

            if ($data['product_type'] == ProductType::SerialKey()->key) {
                $totalAvailableProductSerial = $this->_productSerialMerchantService->getTotalAvailableProductSerialByProductId($product->parent_product_id ? $product->parent_product_id : $data['product_id']);

                if ($data['qty'] > $totalAvailableProductSerial) {
                    array_push($this->_errorMessage, "The purchase quantity is over the product stock. Remaining stock: " . $totalAvailableProductSerial);
                    DB::rollBack();
                    return null;
                }
            }

            //unit price
            $data['unit_price'] = $product->parent_product_id ? ($product->resell_profit + $parentProduct->resell_cost_price) : $product->price;

            //discount
            if (!$product->is_resell) {
                $productDiscounts = $this->_productDiscountMerchantService->getAllProductDiscountByProductId($data['product_id']);

                foreach ($productDiscounts as $productDiscount) {
                    if ($data['qty'] >= $productDiscount->min_qty && $data['unit_price'] > $productDiscount->discounted_price) {
                        $data['unit_price'] = $productDiscount->discounted_price;
                    }
                }
            }


            //unit price for reseller
            $resellProduct = $this->_productRepository->getByParentProductIdAndShopId($data['product_id'], $shopId);

            if ($product->is_open_resell && $resellProduct != null && $resellProduct->is_available && $product->resell_cost_price < $data['unit_price']) {
                $data['unit_price'] =  $product->resell_cost_price;
            }


            $data['shop_id'] = $product->shop_id;
            $data['total'] = $data['unit_price'] * $data['qty'];
            $data['status'] = OrderStatus::CompletePayment()->key;

            //calculate platform commission and seller profit
            $platformCommission = $this->_settingRepository->getByMetaKey(SettingMeta::PlatformCommission()->key);
            $platformCommission = $platformCommission->meta_value;
            $data['platform_commission_percentage'] = $platformCommission;


            //insert order
            $data['product_cost'] = ($product->is_resell) ? ($parentProduct->resell_cost_price * $data['qty']) : 0.00;
            $data['platform_commission_amount'] =  ($product->parent_product_id != null) ? (($data['total'] - $data['product_cost']) * ($data['platform_commission_percentage'] / 100)) : ($data['total'] * ($data['platform_commission_percentage'] / 100));
            $data['seller_profit'] = $data['total'] - $data['product_cost'] - $data['platform_commission_amount'];

            $order = $this->_orderRepository->save($data);


            //insert order products
            $data['order_product']['order_id'] = $order->id;
            $data['order_product']['product_id'] = $data['product_id'];
            $data['order_product']['name'] = $product->name;
            $data['order_product']['product_type'] = $data['product_type'];
            $data['order_product']['qty'] = $data['qty'];
            $data['order_product']['unit_price'] = $data['unit_price'];
            $data['order_product']['sub_total'] = $data['order_product']['unit_price'] * $data['qty'];
            $data['order_product']['is_resell'] = $product->is_resell;
            $data['order_product']['parent_product_id'] = $product->parent_product_id ?? null;

            $orderProduct = $this->_orderProductMerchantService->createOrderProduct($data['order_product']);


            //check buyer wallet balance
            $buyerWallet = $this->_walletMerchantService->getWalletByUserId($data['user_id']);

            if ($buyerWallet['balance'] < $data['total']) {
                array_push($this->_errorMessage, "Your wallet balance is not enough.");

                DB::rollBack();
                return null;
            }


            //update buyer wallet balance
            $buyerWallet['balance'] = $buyerWallet['balance'] - $data['total'];

            $data['wallet_transaction']['balance'] = $buyerWallet['balance'];
            $data['wallet_transaction']['description'] = "Purchase for order #" . $order->id;
            $data['wallet_transaction']['debit'] = null;
            $data['wallet_transaction']['credit'] = $data['total'];

            $wallet = $this->_walletMerchantService->updateBalance($data['user_id'], $buyerWallet['balance']);
            $walletTransaction = $this->_walletTransactionMerchantService->createWalletTransaction($buyerWallet['id'], $data['wallet_transaction']);


            //update product's parent product owner wallet balance
            if ($product->is_resell) {
                $productOwnerUserId = $parentProduct->shop->user_id;
                $productOwnerWallet = $this->_walletMerchantService->getWalletByUserId($productOwnerUserId);

                $profit = $data['product_cost'] - ($data['product_cost'] * ($data['platform_commission_percentage'] / 100));
                $productOwnerWallet['balance'] = $productOwnerWallet['balance'] + $profit;

                $data['wallet_transaction']['balance'] = $productOwnerWallet['balance'];
                $data['wallet_transaction']['debit'] = $profit;
                $data['wallet_transaction']['credit'] = null;
                $data['wallet_transaction']['description'] = "Agent sales order #" . $order->id;

                $wallet = $this->_walletMerchantService->updateBalance($productOwnerUserId, $productOwnerWallet['balance']);
                $walletTransaction = $this->_walletTransactionMerchantService->createWalletTransaction($productOwnerWallet['id'], $data['wallet_transaction']);
            }


            //update seller wallet balance
            $productSellerUserId = $product->shop->user_id;
            $sellerWallet = $this->_walletMerchantService->getWalletByUserId($productSellerUserId);

            $sellerWallet['balance'] = $sellerWallet['balance'] + $data['seller_profit'];

            $data['wallet_transaction']['balance'] = $sellerWallet['balance'];
            $data['wallet_transaction']['debit'] = $data['seller_profit'];
            $data['wallet_transaction']['credit'] = null;
            $data['wallet_transaction']['description'] = "Sales order #" . $order->id;

            $wallet = $this->_walletMerchantService->updateBalance($productSellerUserId, $sellerWallet['balance']);
            $walletTransaction = $this->_walletTransactionMerchantService->createWalletTransaction($sellerWallet['id'], $data['wallet_transaction']);


            //platform commission transaction
            $data['platform_commission_transaction']['platform_commission_percentage'] = $data['platform_commission_percentage'];
            $data['platform_commission_transaction']['platform_commission_amount'] = $data['total'] * ($data['platform_commission_percentage'] / 100);
            $data['platform_commission_transaction']['order_id'] = $order->id;
            $platformCommissionTransaction = $this->_platformCommissionTransactionRepository->save($data['platform_commission_transaction']);

            DB::commit();
            return $order;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to make order.");
            DB::rollBack();
            return null;
        }
    }

    public function getTodayTotalSales($data)
    {
        try {
            $validator = Validator::make($data, [
                'date' => 'required|date_format:Y-m-d',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shopId = $this->_shopMerchantService->getShopId();
            $totalSales = $this->_orderRepository->getTotalSalesByShopIdAndCreatedAt($shopId, $data['date']);

            return $totalSales;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get today total sales.");

            return null;
        }
    }

    public function getDailyTotalProfit($data)
    {
        try {
            $validator = Validator::make($data, [
                'date' => 'required|date_format:Y-m-d',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shopId = $this->_shopMerchantService->getShopId();
            $totalProfit = $this->_orderRepository->getTotalProfitByShopIdAndCreatedAt($shopId, $data['date']);

            return $totalProfit;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get daily total profit.");

            return null;
        }
    }

    public function getMonthlyTotalProfit($data)
    {
        try {
            $validator = Validator::make($data, [
                'month' => 'required|date_format:m',
                'year' => 'required|date_format:Y',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shopId = $this->_shopMerchantService->getShopId();
            $totalProfit = $this->_orderRepository->getTotalProfitByShopIdAndMonthAndYear($shopId, $data);

            return $totalProfit;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get monthly total profit.");

            return null;
        }
    }

    public function getYearlyTotalProfit($data)
    {
        try {
            $validator = Validator::make($data, [
                'year' => 'required|date_format:Y',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shopId = $this->_shopMerchantService->getShopId();
            $totalProfit = $this->_orderRepository->getTotalProfitByShopIdAndYear($shopId, $data['year']);

            return $totalProfit;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get yearly total profit.");

            return null;
        }
    }

    public function getCurrentYearEachMonthSales()
    {
        try {
            $year = Carbon::now()->format('Y');
            $shopId = $this->_shopMerchantService->getShopId();
            $monthlySales = $this->_orderRepository->getEachMonthSalesByShopIdAndYear($shopId, $year);

            $dataList = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            foreach ($monthlySales as $data) {
                $dataList[$data->month - 1] = $data->total_amount;
            }

            return $dataList;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get each month sales.");

            return null;
        }
    }
}
