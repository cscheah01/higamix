<?php

namespace App\Services\Merchant;

use Image;
use Exception;
use Illuminate\Support\Str;
use App\Enums\NotificationType;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Repositories\DiscordBotRepository;
use App\Services\Merchant\ShopMerchantService;

class DiscordBotMerchantService extends Service
{
    protected $_discordBotRepository;
    protected $_shopMerchantService;
    protected $_productRepository;

    public function __construct(
        DiscordBotRepository $discordBotRepository,
        ShopMerchantService $shopMerchantService,
        ProductRepository $productRepository
    ) {
        $this->_discordBotRepository = $discordBotRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productRepository = $productRepository;
    }

    public function getDataTable()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('discord_bots')
            ->select(['id', 'username', 'avatar_image', 'created_at'])
            ->where('shop_id', '=', $shopId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function createDiscordBot($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'username' => 'required|string|max:255',
                'avatar_image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'webhook_url' => 'required|string|max:2048',
                'is_enable_send_product_link' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            if (isset($data['avatar_image']) && !empty($data['avatar_image'])) {
                $image = $data['avatar_image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['avatar_image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/discord_bot/avatar_image');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                $data['avatar_image'] = $fileName;
            }

            $data['shop_id'] = $this->_shopMerchantService->getShopId();

            $discordBot = $this->_discordBotRepository->save($data);

            DB::commit();
            return $discordBot;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add discord bot.");

            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getById($id)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();

            $discordBot = $this->_discordBotRepository->getById($id);

            if (
                $discordBot->shop_id !=
                $shopId
            ) {
                return false;
            }

            $discordBot['webhook_url'] = decrypt($discordBot['webhook_url']);

            return $discordBot;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get discord bot details.");

            return null;
        }
    }

    public function updateDiscordBot($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'username' => 'required|string|max:255',
                'avatar_image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'remove_avatar_image' => 'required|boolean',
                'webhook_url' => 'required|string|max:2048',
                'is_enable_send_product_link' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $discordBot = $this->_discordBotRepository->getById($id);
            $data['shop_id'] = $this->_shopMerchantService->getShopId();

            if ($discordBot->shop_id != $data['shop_id']) {
                throw new Exception();
            }

            if ($data['remove_avatar_image'] == true) {
                if (Storage::exists('public/discord_bot/avatar_image/' . $discordBot->avatar_image)) {
                    Storage::delete('public/discord_bot/avatar_image/' . $discordBot->avatar_image);
                }

                $data['avatar_image'] = null;
            } else if (!empty($data['avatar_image'])) {
                $fileName = $this->generateFileName();
                $fileExtension = $data['avatar_image']->extension();
                $fileName = $fileName . '.' . $fileExtension;
                $data['avatar_image']->storeAs('discord_bot/avatar_image', $fileName, 'public');

                if (Storage::exists('public/discord_bot/avatar_image/' . $discordBot->avatar_image)) {
                    Storage::delete('public/discord_bot/avatar_image/' . $discordBot->avatar_image);
                }

                $data['avatar_image'] = $fileName;
            }


            $discordBot = $this->_discordBotRepository->update($data, $id);

            DB::commit();
            return $discordBot;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update discord bot.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $discordBot = $this->_discordBotRepository->deleteById($id);

            $shopId = $this->_shopMerchantService->getShopId();
            if (
                $discordBot->shop_id !=
                $shopId
            ) {
                throw new Exception();
            }

            DB::commit();
            return $discordBot;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete discord bot.");

            DB::rollBack();
            return null;
        }
    }

    public function getSelectOption($data)
    {
        try {
            $data['result_count'] = 5;
            $data['offset'] = ($data['page'] - 1) * $data['result_count'];

            $shopId = $this->_shopMerchantService->getShopId();
            $discordBots = $this->_discordBotRepository->getAllByShopIdAndSerchTerm($data, $shopId);

            $totalCount = $this->_discordBotRepository->getTotalCountByShopIdAndSerchTerm($data, $shopId);
            $results = array(
                "results" => $discordBots->toArray(),
                "pagination" => array(
                    "more" => $totalCount < $data['offset'] + $data['result_count'] ? false : true
                )
            );

            return $results;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get discord bot select option list.");

            return null;
        }
    }

    public function sendDiscordNotificationToAllReseller($content, $id, $type)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();

            if ($type == NotificationType::Product()) {
                $resellProducts = $this->_productRepository->getAllByParentProductId($id);
            } else if ($type == NotificationType::ProductCategory()) {
                $resellProducts = $this->_productRepository->getAllByProductCategoryId($id, $shopId);
            } else if ($type == NotificationType::ProductSubCategory()) {
                $resellProducts = $this->_productRepository->getAllByProductSubCategoryId($id, $shopId);
            }

            foreach ($resellProducts as $resellProduct) {
                if ($type == NotificationType::Product()) {
                    $webhookUrl = decrypt($resellProduct->discordBot->webhook_url);

                    if ($resellProduct->discordBot->is_enable_send_product_link == true) {
                        $description = "**Product Name : **" . $resellProduct->name . "\n**Parent Product Name : **" . $resellProduct->parentProduct->name . "\n**Shop Name : **" . $resellProduct->parentProduct->shop->name . "\n**Product Link : **[" . route('merchant.resell_product.show', ['id' => $resellProduct->id]) . "](" . route('merchant.resell_product.show', ['id' => $resellProduct->id]) . ")\n\n" . $content;
                    } else {
                        $description = "**Product Name : **" . $resellProduct->name . "\n**Parent Product Name : **" . $resellProduct->parentProduct->name . "\n**Shop Name : **" . $resellProduct->parentProduct->shop->name . "\n\n" . $content;
                    }

                    $username = $resellProduct->discordBot->username;
                    $avatar_url = $resellProduct->discordBot->avatar_image;
                } else if ($type == NotificationType::ProductCategory() || $type == NotificationType::ProductSubCategory()) {
                    $webhookUrl = decrypt($resellProduct->discord_bot_webhook_url);

                    $name = "**Product Category : **" . $resellProduct->product_category_name;

                    if ($type == NotificationType::ProductSubCategory()) {
                        $name .= " > " . $resellProduct->product_sub_category_name;
                    }

                    $description = $name . "\n**Shop Name : **" . $resellProduct->parent_product_shop_name . "\n\n" . $content;
                    $username = $resellProduct->discord_bot_username;
                    $avatar_url = $resellProduct->discord_bot_avatar_image;
                }
                Http::post(
                    $webhookUrl,
                    [
                        'username' => $username,
                        'avatar_url' => $avatar_url ? url('storage/discord_bot/avatar_image/' . $avatar_url) : null,
                        'embeds' => [
                            [
                                "title" => "**Product Log Notification**",
                                "type" => "rich",
                                "description" => $description,
                                'color' => "1127128",
                            ]
                        ],
                    ]
                );
            }

            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to send product discord notification to all reseller.");
            return null;
        }
    }
}
