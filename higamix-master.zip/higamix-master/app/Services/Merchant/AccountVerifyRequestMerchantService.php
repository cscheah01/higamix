<?php

namespace App\Services\Merchant;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\AccountVerifyRequestRepository;

class AccountVerifyRequestMerchantService extends Service
{
    protected $_accountVerifyRequestRepository;

    public function __construct(
        AccountVerifyRequestRepository $accountVerifyRequestRepository
    ) {
        $this->_accountVerifyRequestRepository = $accountVerifyRequestRepository;
    }

    public function createAccountVerificationRequest()
    {
        DB::beginTransaction();

        try {
            $userId = Auth::id();
            $accountVerifyRequest = $this->_accountVerifyRequestRepository->getByUserId($userId);

            if ($accountVerifyRequest != null) {
                throw new Exception();
            }

            $accountVerifyRequest = $this->_accountVerifyRequestRepository->save($userId);

            DB::commit();
            return $accountVerifyRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to send account verify request.");

            DB::rollBack();
            return null;
        }
    }

    public function getAccountVerificationRequest()
    {
        try {
            $userId = Auth::id();
            $accountVerifyRequest = $this->_accountVerifyRequestRepository->getByUserId($userId);

            return $accountVerifyRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get account verify request details.");

            return null;
        }
    }
}
