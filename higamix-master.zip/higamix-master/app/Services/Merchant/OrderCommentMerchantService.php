<?php

namespace App\Services\Merchant;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Repositories\OrderCommentRepository;
use App\Repositories\OrderRepository;
use App\Services\NotificationService;

class OrderCommentMerchantService extends Service
{
    protected $_orderCommentRepository;
    protected $_notificationService;
    protected $_orderRepository;
    protected $_shopMerchantService;

    public function __construct(
        OrderCommentRepository $orderCommentRepository,
        NotificationService $notificationService,
        OrderRepository $orderRepository,
        ShopMerchantService $shopMerchantService
    ) {
        $this->_orderCommentRepository = $orderCommentRepository;
        $this->_notificationService = $notificationService;
        $this->_orderRepository = $orderRepository;
        $this->_shopMerchantService = $shopMerchantService;
    }

    public function createOrderComment($data, $orderId)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'content' => 'required|string|max:65535',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $shopId = $this->_shopMerchantService->getShopId();

            $order = $this->_orderRepository->getById($orderId);

            if ($order->shop_id != $shopId && $order->user_id != $userId) {
                throw new Exception();
            }

            $data['order_id'] = $orderId;
            $data['user_id'] = $userId;

            $orderComment = $this->_orderCommentRepository->save($data);


            //platform notification
            $data['notification']['order_id'] = $orderId;
            $data['notification']['content'] = Auth::user()->email . ' : ' . $data['content'];
            $data['notification']['user_id'] = ($data['user_id'] == $order->user_id) ? $order->shop->user_id : $order->user_id;

            $this->_notificationService->createNotification($data['notification']);

            DB::commit();
            return $orderComment;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add order comment.");

            DB::rollBack();
            return null;
        }
    }

    public function getAllByOrderId($orderId)
    {
        try {
            $orderComments = $this->_orderCommentRepository->getAllByOrderId($orderId);

            return $orderComments;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get order comment list.");

            return null;
        }
    }
}
