<?php

namespace App\Services\Merchant;

use Image;
use Exception;
use Illuminate\Support\Str;
use App\Enums\NotificationType;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Mews\Purifier\Facades\Purifier;
use App\Repositories\ShopRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class ShopMerchantService extends Service
{
    protected $_shopRepository;

    public function __construct(
        ShopRepository $shopRepository
    ) {
        $this->_shopRepository = $shopRepository;
    }


    public function getShopDetails()
    {
        try {
            $data = $this->_shopRepository->getByUserId(Auth::id());

            $shop = $data->toArray();

            if ($shop['telegram_bot_api_key'] != null) {
                $shop['telegram_bot_api_key'] = decrypt($shop['telegram_bot_api_key']);
            }

            if ($shop['telegram_channel_username'] != null) {
                $shop['telegram_channel_username'] = decrypt($shop['telegram_channel_username']);
            }

            $shop['description'] = Purifier::clean($shop['description']);

            return $shop;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get shop details.");

            return null;
        }
    }

    public function updateShop($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'logo_image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'name' => 'required|string|max:255',
                'remove_image' => 'required|boolean',
                'description' => 'nullable|string|max:16777215',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shop = $this->_shopRepository->getByUserId(Auth::id());

            if ($data['remove_image'] == false && !empty($data['logo_image'])) {
                $image = $data['logo_image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['logo_image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/shop_logo');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                if (Storage::exists('public/shop_logo/' . $shop->logo_image)) {
                    Storage::delete('public/shop_logo/' . $shop->logo_image);
                }

                $data['logo_image'] = $fileName;
            } else if ($data['remove_image'] == true) {
                if (Storage::exists('public/shop_logo/' . $shop->logo_image)) {
                    Storage::delete('public/shop_logo/' . $shop->logo_image);
                }
                $data['logo_image'] = null;
            }

            $data['description'] = Purifier::clean($data['description']);

            $userId = Auth::id();
            $result = $this->_shopRepository->updateByUserId($data, $userId);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update shop details.");

            DB::rollBack();
            return null;
        }
    }

    public function updateAgentSetting($data)
    {
        DB::beginTransaction();

        try {
            $id = $this->getShopId();

            $validator = Validator::make($data, [
                'agent_connect_code' => 'required|String|min:10|max:36|unique:shops,agent_connect_code,' . $id,
                'is_allow_agent_direct_connect' => 'required|boolean',
                'general_description' => 'nullable|string|max:1000',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $shop = $this->_shopRepository->updateByUserId($data, $userId);

            DB::commit();
            return $shop;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update agent setting.");

            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getShopId()
    {
        $shop = $this->_shopRepository->getByUserId(Auth::id());

        return $shop['id'];
    }

    public function getById($id)
    {
        try {
            $shop = $this->_shopRepository->getById($id);

            if ($shop == null) {
                return false;
            }

            return $shop;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get shop details.");

            return null;
        }
    }

    public function getDataTable()
    {
        $user_id = Auth::id();
        $data = DB::table('shops')
            ->select([
                'shops.id',
                'shops.name',
                'shops.general_description',
            ])
            ->where('shops.user_id', '!=', $user_id);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function updateTelegramSetting($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'is_enabled_telegram_notification' => 'required|boolean',
                'telegram_channel_url' => 'string|max:255|nullable',
                'telegram_channel_username' => 'string|max:255|nullable|required_if:is_enabled_telegram_notification,=,1',
                'telegram_bot_api_key' => 'string|max:255|nullable|required_if:is_enabled_telegram_notification,=,1',
                'is_enable_telegram_send_product_link' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $shop = $this->_shopRepository->updateByUserId($data, $userId);

            DB::commit();
            return $shop;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update telegram setting.");
            DB::rollBack();
            return null;
        }
    }

    public function sendTelegramNotification($content, $product, $type)
    {
        try {
            $shop = $this->_shopRepository->getByUserId(Auth::id());
            $telegramBotApiKey = decrypt($shop['telegram_bot_api_key']);
            $telegramChannelUsername = decrypt($shop['telegram_channel_username']);

            if ($shop['is_enable_telegram_send_product_link'] == true && $type == NotificationType::Product()->key) {

                $message = "*Product Log Notification*\n\n*Product Name : *" . $product->name . "\n*Product Link : *[" . route('merchant.product.show', ['id' => $product->id]) . "](" . route('merchant.product.show', ['id' => $product->id]) . ")\n\n$content";
            } else {
                if ($type == NotificationType::Product()) {
                    $message = "*Product Log Notification*\n\n*Product Name : *" . $product->name . "\n\n$content";
                } else if ($type == NotificationType::ProductCategory()) {
                    $message = "*Product Log Notification*\n\n*Product Category : *" . $product->productCategory->name . "\n\n$content";
                } else if ($type == NotificationType::ProductSubCategory()) {
                    $message = "*Product Log Notification*\n\n*Product Category : *" . $product->productCategory->name . " > " . $product->productSubCategory->name . "\n\n$content";
                }
            }

            $url = "api.telegram.org/bot$telegramBotApiKey/sendMessage?chat_id=@$telegramChannelUsername&text=$message&parse_mode=Markdown";
            Http::post($url);

            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to send telegram notification.");

            return null;
        }
    }
}
