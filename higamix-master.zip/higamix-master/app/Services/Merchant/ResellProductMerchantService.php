<?php

namespace App\Services\Merchant;

use Exception;
use App\Enums\ProductType;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\ProductRepository;
use App\Repositories\ShopAgentRepository;
use Illuminate\Support\Facades\Validator;
use App\Repositories\DiscordBotRepository;
use App\Services\Merchant\ShopMerchantService;
use App\Repositories\ProductCategoryRepository;
use App\Repositories\ProductSubCategoryRepository;
use App\Services\Merchant\ProductSerialMerchantService;

class ResellProductMerchantService extends Service
{
    protected $_productRepository;
    protected $_shopMerchantService;
    protected $_productCategoryRepository;
    protected $_productSubCategoryRepository;
    protected $_shopAgentRepository;
    protected $_discordBotRepository;
    protected $_productSerialMerchantService;

    public function __construct(
        ProductRepository $productRepository,
        ShopMerchantService $shopMerchantService,
        ProductCategoryRepository $productCategoryRepository,
        ProductSubCategoryRepository $productSubCategoryRepository,
        ShopAgentRepository $shopAgentRepository,
        DiscordBotRepository $discordBotRepository,
        ProductSerialMerchantService $productSerialMerchantService
    ) {
        $this->_productRepository = $productRepository;
        $this->_shopMerchantService = $shopMerchantService;
        $this->_productCategoryRepository = $productCategoryRepository;
        $this->_productSubCategoryRepository = $productSubCategoryRepository;
        $this->_shopAgentRepository = $shopAgentRepository;
        $this->_discordBotRepository = $discordBotRepository;
        $this->_productSerialMerchantService = $productSerialMerchantService;
    }

    public function getResellableProductDataTable()
    {
        $data = DB::table('products')
            ->leftJoin('shops', 'products.shop_id', '=', 'shops.id')
            ->select([
                'products.id',
                'products.product_type',
                'products.price',
                'products.is_available',
                'products.is_open_resell',
                'products.suggested_min_resell_price',
                'products.resell_cost_price',
                'products.name',
                'products.created_at',
                'shops.id as shop_id',
                'shops.name as shop_name',
                'shops.agent_connect_code as shops_agent_connect_code',
            ])
            ->where('products.is_open_resell', '=', true)
            ->where('products.is_available', '=', true)
            ->where('products.deleted_at', '=', null);


        $result = DataTables::of($data)
            ->addColumn('product_type', '{{App\Enums\ProductType::fromKey($product_type)->description}}')
            ->make();

        return $result;
    }

    public function getResellProductDataTable()
    {
        $shopId = $this->_shopMerchantService->getShopId();

        $data = DB::table('products')
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->leftJoin('shop_agents', 'parent_product.shop_id', '=', 'shop_agents.shop_id')
            ->leftJoin('shops', 'parent_product.shop_id', '=', 'shops.id')
            ->select([
                'products.id',
                'products.parent_product_id',
                'products.name',
                'parent_product.name as parent_product_name',
                'parent_product.min_purchase_qty as parent_product_min_purchase_qty',
                'parent_product.max_purchase_qty as parent_product_max_purchase_qty',
                'parent_product.product_type as product_type_key',
                'products.resell_profit',
                'parent_product.resell_cost_price',
                'parent_product.suggested_min_resell_price',
                'products.created_at',
                'shops.id as shop_id',
                'shops.name as shop_name',
                'shop_agents.is_waiting_approved',
                'shop_agents.is_approved',
                DB::raw('(parent_product.resell_cost_price + products.resell_profit) as price'),
                DB::raw('
                    CASE
                    WHEN
                        products.is_resell
                    THEN
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.parent_product_id AND is_sold = 0)
                    ELSE
                        (SELECT COUNT(*) FROM product_serials WHERE product_id = products.id AND is_sold = 0)
                    END
                    as stock_qty'),
            ])
            ->where('products.is_resell', '=', true)
            ->where('products.deleted_at', '=', null)
            ->where('shop_agents.agent_shop_id', '=', $shopId)
            ->where('products.shop_id', '=', $shopId);


        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getAgentResellProductDataTable()
    {
        $data = DB::table('products')
            ->leftjoin('products as parent_product', 'products.parent_product_id', '=', 'parent_product.id')
            ->select([
                'products.id',
                'products.name',
                'products.created_at',
                'products.shop_id',
                DB::raw('(parent_product.resell_cost_price + products.resell_profit) as price')
            ])
            ->where('products.is_resell', '=', true)
            ->where('products.deleted_at', '=', null);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getResellProductById($id)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $product = $this->_productRepository->getById($id);

            if (
                $product->shop_id !=
                $shopId
            ) {
                return false;
            }

            $product->price = number_format($product->resell_profit + $product->parentProduct->resell_cost_price, 2, '.', '');

            if ($product->parentProduct->product_type == ProductType::SerialKey()->key) {
                $product->stock_qty = $this->_productSerialMerchantService->getTotalAvailableProductSerialByProductId($product->parentProduct->id);
            }

            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get resell product details.");

            return null;
        }
    }


    public function createResellProduct($data, $id)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'product_category_id' => 'nullable',
                'product_sub_category_id' => 'nullable',
                'discord_bot_id' => 'nullable',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }
            $data['agent_shop_id'] = $this->_shopMerchantService->getShopId();

            $productCategory = $this->_productCategoryRepository->getById($data['product_category_id']);

            //check product category id
            if (!empty($data['product_category_id'])) {
                $productCategory = $this->_productCategoryRepository->getById($data['product_category_id']);

                if ($productCategory == null || $productCategory->shop_id != $data['agent_shop_id']) {
                    throw new Exception();
                }
            }

            //check product sub category id
            if (!empty($data['product_sub_category_id'])) {
                $productSubCategory = $this->_productSubCategoryRepository->getById($data['product_sub_category_id']);

                if ($productSubCategory == null || $productSubCategory->product_category_id != $data['product_category_id']) {
                    throw new Exception();
                }
            }

            $product = $this->_productRepository->getById($id);

            if ($product->shop_id == $data['agent_shop_id']) {
                array_push($this->_errorMessage, "You cannot resell your own product.");
                DB::rollBack();
                return null;
            }

            $data['shop_id'] = $product->shop_id;
            $data['parent_product_id'] = $id;
            $data['resell_profit'] = $data['price'] - $product->resell_cost_price;


            if ($this->_productRepository->getByParentProductIdAndShopId($data['parent_product_id'], $data['agent_shop_id']) != null) {
                array_push($this->_errorMessage, "You already resell this product.");
                DB::rollBack();
                return null;
            }

            if (!empty($data['discord_bot_id'])) {
                $discordBot = $this->_discordBotRepository->getById($data['discord_bot_id']);

                if ($discordBot == null || $discordBot->shop_id != $data['agent_shop_id']) {
                    throw new Exception();
                }
            }

            $shopAgent = $this->_shopAgentRepository->getByShopIdAndAgentShopId($data['shop_id'], $data['agent_shop_id']);

            if (
                $shopAgent != null && !$shopAgent->is_approved && !$shopAgent->is_waiting_approved
            ) {
                array_push($this->_errorMessage, "This shop has rejected you as a agent.");
                DB::rollBack();
                return null;
            }

            if ($shopAgent == null) {
                $shopAllowDirectConnect = $this->_shopMerchantService->getById($data['shop_id']);

                $data['shop_agent']['is_approved'] = $shopAllowDirectConnect->is_allow_agent_direct_connect ? true : false;
                $data['shop_agent']['is_waiting_approved'] = $shopAllowDirectConnect->is_allow_agent_direct_connect ? false : true;
                $data['shop_agent']['shop_id'] = $data['shop_id'];
                $data['shop_agent']['agent_shop_id'] = $data['agent_shop_id'];

                $shopAgent = $this->_shopAgentRepository->save($data['shop_agent']);
            }

            $data['is_available'] = $shopAgent->is_waiting_approved ? false : true;
            $data['price'] = null;
            $product = $this->_productRepository->saveResellProduct($data);

            if ($shopAgent->is_waiting_approved == true) {
                $product->sendRequest = true;
            }


            DB::commit();
            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to save resell product.");

            DB::rollBack();
            return null;
        }
    }

    public function updateResellProduct($data, $id)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'product_category_id' => 'nullable',
                'product_sub_category_id' => 'nullable',
                'discord_bot_id' => 'nullable',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $shopId = $this->_shopMerchantService->getShopId();
            $product = $this->_productRepository->getById($id);

            $data['resell_profit'] = $data['price'] - $product->parentProduct->resell_cost_price;

            //check product category id
            if (!empty($data['product_category_id'])) {
                $productCategory = $this->_productCategoryRepository->getById($data['product_category_id']);
                if ($productCategory == null || $productCategory->shop_id != $shopId) {
                    throw new Exception();
                }
            }

            //check product sub category id
            if (!empty($data['product_sub_category_id'])) {
                $productSubCategory = $this->_productSubCategoryRepository->getById($data['product_sub_category_id']);

                if ($productSubCategory == null || $productSubCategory->product_category_id != $data['product_category_id']) {
                    throw new Exception();
                }
            }

            if (!empty($data['discord_bot_id'])) {
                $discordBot = $this->_discordBotRepository->getById($data['discord_bot_id']);
                if ($discordBot == null || $discordBot->shop_id != $shopId) {
                    throw new Exception();
                }
            }
            $data['price'] = null;
            $product = $this->_productRepository->updateResellProduct($data, $id);

            if ($product->shop_id != $shopId) {
                throw new Exception();
            }

            DB::commit();
            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update product.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteResellProductById($id)
    {
        DB::beginTransaction();

        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $product = $this->_productRepository->deleteById($id);

            if ($product->shop_id != $shopId) {
                throw new Exception();
            }

            DB::commit();
            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete resell product.");
            DB::rollBack();
            return null;
        }
    }

    public function getResellerResellProduct($parentProductId)
    {
        try {
            $shopId = $this->_shopMerchantService->getShopId();
            $product = $this->_productRepository->getByParentProductIdAndShopId($parentProductId, $shopId);

            if (
                $product == null || !$product->is_available
            ) {
                return false;
            }

            return $product;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get reseller resell product.");

            return null;
        }
    }
}
