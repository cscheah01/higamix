<?php

namespace App\Services\Merchant;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\WalletTransactionRepository;

class WalletTransactionMerchantService extends Service
{
    protected $_walletTransactionRepository;

    public function __construct(
        WalletTransactionRepository $walletTransactionRepository
    ) {
        $this->_walletTransactionRepository = $walletTransactionRepository;
    }

    public function createWalletTransaction($walletId, $data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'credit' => 'nullable|numeric|between: 0.00,99999999999.99',
                'debit' => 'nullable|numeric|between: 0.00,99999999999.99',
                'balance' => 'nullable|numeric|between: 0.00,99999999999.99',
                'description' => 'nullable|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $data['wallet_id'] = $walletId;

            $walletTransaction = $this->_walletTransactionRepository->save($data);

            DB::commit();
            return $walletTransaction;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add wallet transaction.");
            DB::rollBack();
            return null;
        }
    }
}
