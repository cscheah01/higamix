<?php

// @formatter:off
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App\Models{
/**
 * App\Models\AccountVerifyRequest
 *
 * @property int $id
 * @property int $user_id
 * @property int $is_waiting_approved
 * @property int $is_approved
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest query()
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest whereIsApproved($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest whereIsWaitingApproved($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|AccountVerifyRequest whereUserId($value)
 */
	class AccountVerifyRequest extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\DiscordBot
 *
 * @property int $id
 * @property int $shop_id
 * @property string $username
 * @property string|null $avatar_image
 * @property string $webhook_url
 * @property int $is_enable_send_product_link
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Database\Factories\DiscordBotFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot query()
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereAvatarImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereIsEnableSendProductLink($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereShopId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereUsername($value)
 * @method static \Illuminate\Database\Eloquent\Builder|DiscordBot whereWebhookUrl($value)
 */
	class DiscordBot extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\InternalErrorHistory
 *
 * @property int $id
 * @property string $class_name
 * @property string $function_name
 * @property string $exception_message
 * @property string|null $function_parameter
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory query()
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereClassName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereExceptionMessage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereFunctionName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereFunctionParameter($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InternalErrorHistory whereUpdatedAt($value)
 */
	class InternalErrorHistory extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\InviteCode
 *
 * @property int $id
 * @property int $user_id
 * @property string $code
 * @property int $is_used
 * @property int|null $used_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\User|null $user
 * @method static \Database\Factories\InviteCodeFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode query()
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereIsUsed($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereUsedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|InviteCode whereUserId($value)
 */
	class InviteCode extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\LoginHistory
 *
 * @property int $id
 * @property int $user_id
 * @property string $ip_address
 * @property string $country
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory query()
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory whereCountry($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory whereIpAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|LoginHistory whereUserId($value)
 */
	class LoginHistory extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Notification
 *
 * @property int $id
 * @property int $user_id
 * @property string $content
 * @property int|null $order_id
 * @property int|null $product_id
 * @property int|null $product_category_id
 * @property int|null $product_sub_category_id
 * @property int $is_seen
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Order|null $order
 * @property-read \App\Models\Product|null $product
 * @property-read \App\Models\ProductCategory|null $productCategory
 * @property-read \App\Models\ProductSubCategory|null $productSubCategory
 * @property-read \App\Models\Shop $shop
 * @method static \Illuminate\Database\Eloquent\Builder|Notification newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Notification newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Notification query()
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereIsSeen($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereOrderId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereProductCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereProductSubCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Notification whereUserId($value)
 */
	class Notification extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Order
 *
 * @property int $id
 * @property int $user_id
 * @property int $shop_id
 * @property string $total
 * @property string $platform_commission_percentage
 * @property string $platform_commission_amount
 * @property string $product_cost
 * @property string $seller_profit
 * @property int $is_api_sales
 * @property string $status
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Shop $shop
 * @property-read \App\Models\User $user
 * @method static \Database\Factories\OrderFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|Order newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Order newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Order query()
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereIsApiSales($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order wherePlatformCommissionAmount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order wherePlatformCommissionPercentage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereProductCost($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereSellerProfit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereShopId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereTotal($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Order whereUserId($value)
 */
	class Order extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\OrderComment
 *
 * @property int $id
 * @property int $user_id
 * @property int $order_id
 * @property string $content
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Order $order
 * @property-read \App\Models\User $user
 * @method static \Database\Factories\OrderCommentFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment query()
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment whereOrderId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderComment whereUserId($value)
 */
	class OrderComment extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\OrderProduct
 *
 * @property int $id
 * @property int $order_id
 * @property int $product_id
 * @property string $name
 * @property string $product_type
 * @property int $qty
 * @property string $unit_price
 * @property string $sub_total
 * @property int $is_resell
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Product|null $product
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\ProductSerial[] $productSerials
 * @property-read int|null $product_serials_count
 * @method static \Database\Factories\OrderProductFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct query()
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereIsResell($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereOrderId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereProductType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereQty($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereSubTotal($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereUnitPrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|OrderProduct whereUpdatedAt($value)
 */
	class OrderProduct extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\PasswordReset
 *
 * @property int $id
 * @property int $user_id
 * @property string $email
 * @property string $token
 * @property string|null $used_at
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset query()
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereUsedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PasswordReset whereUserId($value)
 */
	class PasswordReset extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\PlatformCommissionTransaction
 *
 * @property int $id
 * @property int $order_id
 * @property string $percentage
 * @property string $amount
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Database\Factories\PlatformCommissionTransactionFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction query()
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction whereAmount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction whereOrderId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction wherePercentage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PlatformCommissionTransaction whereUpdatedAt($value)
 */
	class PlatformCommissionTransaction extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Product
 *
 * @property int $id
 * @property int $shop_id
 * @property string $name
 * @property string|null $image
 * @property string|null $description
 * @property int|null $product_category_id
 * @property int|null $product_sub_category_id
 * @property string|null $price
 * @property int $is_open_resell
 * @property string|null $resell_cost_price
 * @property string|null $suggested_min_resell_price
 * @property int|null $min_purchase_qty
 * @property int|null $max_purchase_qty
 * @property string|null $product_type
 * @property string|null $service_description
 * @property int $is_available
 * @property int $is_resell
 * @property int|null $parent_product_id
 * @property string|null $resell_profit
 * @property int|null $discord_bot_id
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\DiscordBot|null $discordBot
 * @property-read Product|null $parentProduct
 * @property-read \App\Models\ProductCategory|null $productCategory
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\ProductDiscount[] $productDiscounts
 * @property-read int|null $product_discounts_count
 * @property-read \App\Models\ProductSubCategory|null $productSubCategory
 * @property-read \App\Models\Shop $shop
 * @method static \Database\Factories\ProductFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|Product newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Product newQuery()
 * @method static \Illuminate\Database\Query\Builder|Product onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Product query()
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereDiscordBotId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereIsAvailable($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereIsOpenResell($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereIsResell($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereMaxPurchaseQty($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereMinPurchaseQty($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereParentProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product wherePrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereProductCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereProductSubCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereProductType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereResellCostPrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereResellProfit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereServiceDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereShopId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereSuggestedMinResellPrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|Product withTrashed()
 * @method static \Illuminate\Database\Query\Builder|Product withoutTrashed()
 */
	class Product extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductCategory
 *
 * @property int $id
 * @property int $shop_id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Shop $shop
 * @method static \Database\Factories\ProductCategoryFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereShopId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereUpdatedAt($value)
 */
	class ProductCategory extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductCategoryLog
 *
 * @property int $id
 * @property int $product_category_id
 * @property string $content
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog whereProductCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategoryLog whereUpdatedAt($value)
 */
	class ProductCategoryLog extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductDiscount
 *
 * @property int $id
 * @property int $product_id
 * @property int $min_qty
 * @property string $discounted_price
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Database\Factories\ProductDiscountFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount whereDiscountedPrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount whereMinQty($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductDiscount whereUpdatedAt($value)
 */
	class ProductDiscount extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductLog
 *
 * @property int $id
 * @property int $product_id
 * @property string $content
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Database\Factories\ProductLogFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductLog whereUpdatedAt($value)
 */
	class ProductLog extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductSerial
 *
 * @property int $id
 * @property int $product_id
 * @property string $serial_number
 * @property int $is_sold
 * @property int|null $order_product_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Product $product
 * @method static \Database\Factories\ProductSerialFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereIsSold($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereOrderProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereSerialNumber($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSerial whereUpdatedAt($value)
 */
	class ProductSerial extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductSubCategory
 *
 * @property int $id
 * @property int $product_category_id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\ProductCategory $productCategory
 * @method static \Database\Factories\ProductSubCategoryFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory whereProductCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategory whereUpdatedAt($value)
 */
	class ProductSubCategory extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductSubCategoryLog
 *
 * @property int $id
 * @property int $product_sub_category_id
 * @property string $content
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog whereProductSubCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductSubCategoryLog whereUpdatedAt($value)
 */
	class ProductSubCategoryLog extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Setting
 *
 * @property int $id
 * @property string $meta_key
 * @property string|null $meta_value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|Setting newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Setting newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Setting query()
 * @method static \Illuminate\Database\Eloquent\Builder|Setting whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Setting whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Setting whereMetaKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Setting whereMetaValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Setting whereUpdatedAt($value)
 */
	class Setting extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Shop
 *
 * @property int $id
 * @property int $user_id
 * @property string $name
 * @property string|null $logo_image
 * @property string|null $description
 * @property string|null $general_description
 * @property string $agent_connect_code
 * @property int $is_allow_agent_direct_connect
 * @property string|null $telegram_channel_url
 * @property string|null $telegram_bot_api_key
 * @property string|null $telegram_channel_username
 * @property int $is_enabled_telegram_notification
 * @property int $is_enable_telegram_send_product_link
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\User $user
 * @method static \Database\Factories\ShopFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Shop newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Shop query()
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereAgentConnectCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereGeneralDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereIsAllowAgentDirectConnect($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereIsEnableTelegramSendProductLink($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereIsEnabledTelegramNotification($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereLogoImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereTelegramBotApiKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereTelegramChannelUrl($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereTelegramChannelUsername($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Shop whereUserId($value)
 */
	class Shop extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ShopAgent
 *
 * @property int $id
 * @property int $shop_id
 * @property int $agent_shop_id
 * @property int $is_waiting_approved
 * @property int $is_approved
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Shop $agent
 * @property-read \App\Models\Shop $shop
 * @method static \Database\Factories\ShopAgentFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent query()
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereAgentShopId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereIsApproved($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereIsWaitingApproved($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereShopId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ShopAgent whereUpdatedAt($value)
 */
	class ShopAgent extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\User
 *
 * @property int $id
 * @property string $email
 * @property string $password
 * @property string $google_2fa_secret
 * @property int $is_enabled_two_factor
 * @property int $is_verified
 * @property string $api_public_key
 * @property string $api_secret_key
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\AccountVerifyRequest|null $accountVerifyRequest
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Spatie\Permission\Models\Permission[] $permissions
 * @property-read int|null $permissions_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Spatie\Permission\Models\Role[] $roles
 * @property-read int|null $roles_count
 * @property-read \App\Models\Shop|null $shop
 * @property-read \Illuminate\Database\Eloquent\Collection|\Laravel\Sanctum\PersonalAccessToken[] $tokens
 * @property-read int|null $tokens_count
 * @property-read \App\Models\Wallet|null $wallet
 * @method static \Database\Factories\UserFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User newQuery()
 * @method static \Illuminate\Database\Query\Builder|User onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|User permission($permissions)
 * @method static \Illuminate\Database\Eloquent\Builder|User query()
 * @method static \Illuminate\Database\Eloquent\Builder|User role($roles, $guard = null)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereApiPublicKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereApiSecretKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereGoogle2faSecret($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereIsEnabledTwoFactor($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereIsVerified($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|User withTrashed()
 * @method static \Illuminate\Database\Query\Builder|User withoutTrashed()
 */
	class User extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Wallet
 *
 * @property int $id
 * @property int $user_id
 * @property string $balance
 * @property string $inactive_balance
 * @property string|null $withdraw_address
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Shop|null $shop
 * @property-read \App\Models\User $user
 * @method static \Database\Factories\WalletFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet query()
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereBalance($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereInactiveBalance($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Wallet whereWithdrawAddress($value)
 */
	class Wallet extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\WalletTransaction
 *
 * @property int $id
 * @property int $wallet_id
 * @property int|null $order_id
 * @property string|null $debit
 * @property string|null $credit
 * @property string $balance
 * @property string $description
 * @property string|null $zixi_pay_transaction_id
 * @property string|null $api_response
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction query()
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereApiResponse($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereBalance($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereCredit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereDebit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereOrderId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereWalletId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletTransaction whereZixiPayTransactionId($value)
 */
	class WalletTransaction extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\WalletWithdrawalRequest
 *
 * @property int $id
 * @property int $user_id
 * @property string $amount
 * @property int $is_approved
 * @property int $is_rejected
 * @property string|null $remark
 * @property string $transaction_fee
 * @property string $withdraw_address
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Shop|null $shop
 * @property-read \App\Models\User $user
 * @property-read \App\Models\Wallet|null $wallet
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest query()
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereAmount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereIsApproved($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereIsRejected($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereRemark($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereTransactionFee($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereUserId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WalletWithdrawalRequest whereWithdrawAddress($value)
 */
	class WalletWithdrawalRequest extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\WithdrawalTransactionFee
 *
 * @property int $id
 * @property string $amount_more_than_equal
 * @property string $fee
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee query()
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee whereAmountMoreThanEqual($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee whereFee($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|WithdrawalTransactionFee whereUpdatedAt($value)
 */
	class WithdrawalTransactionFee extends \Eloquent {}
}

