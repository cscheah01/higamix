<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\WalletApiV1Controller;
use App\Http\Controllers\Api\V1\ProductApiV1Controller;
use App\Http\Controllers\Api\V1\SalesHistoryApiV1Controller;
use App\Http\Controllers\Api\V1\PurchaseProductApiV1Controller;


Route::get('balances', [WalletApiV1Controller::class, 'getBalance']);

Route::get('products', [ProductApiV1Controller::class, 'getProductList']);
Route::get('products/{id}', [ProductApiV1Controller::class, 'getProductDetails']);


Route::get('orders', [SalesHistoryApiV1Controller::class, 'getSalesHistoryList']);
Route::get('orders/{id}', [SalesHistoryApiV1Controller::class, 'getSalesHistoryDetails']);
Route::post('orders', [PurchaseProductApiV1Controller::class, 'purchase']);
