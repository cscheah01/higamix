<?php

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SidebarController;
use App\Http\Controllers\TwoFactorController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ForgetPasswordController;
use App\Http\Controllers\Admin\ShopAdminController;
use App\Http\Controllers\Admin\OrderAdminController;
use App\Http\Controllers\Admin\StaffAdminController;
use App\Http\Controllers\Admin\WalletAdminController;
use App\Http\Controllers\Admin\ProductAdminController;
use App\Http\Controllers\Admin\ProfileAdminController;
use App\Http\Controllers\Admin\MerchantAdminController;
use App\Http\Controllers\Admin\DashboardAdminController;
use App\Http\Controllers\Admin\ShopAgentAdminController;
use App\Http\Controllers\Admin\TwoFactorAdminController;
use App\Http\Controllers\Admin\InviteCodeAdminController;
use App\Http\Controllers\Merchant\ShopMerchantController;
use App\Http\Controllers\Merchant\OrderMerchantController;
use App\Http\Controllers\Admin\LoginHistoryAdminController;
use App\Http\Controllers\Admin\OrderCommentAdminController;
use App\Http\Controllers\Merchant\WalletMerchantController;
use App\Http\Controllers\Admin\ResellProductAdminController;
use App\Http\Controllers\Merchant\ProductMerchantController;
use App\Http\Controllers\Merchant\ProfileMerchantController;
use App\Http\Controllers\Merchant\ZixiPayMerchantController;
use App\Http\Controllers\Admin\PlatformSettingAdminController;
use App\Http\Controllers\Merchant\DashboardMerchantController;
use App\Http\Controllers\Merchant\ShopAgentMerchantController;
use App\Http\Controllers\Merchant\TwoFactorMerchantController;
use App\Http\Controllers\Merchant\DiscordBotMerchantController;
// use App\Http\Controllers\Merchant\InviteCodeMerchantController;
use App\Http\Controllers\Merchant\ProductLogMerchantController;
use App\Http\Controllers\Admin\WalletTransactionAdminController;
use App\Http\Controllers\Merchant\AgentSettingMerchantController;
use App\Http\Controllers\Merchant\LoginHistoryMerchantController;
use App\Http\Controllers\Merchant\OrderCommentMerchantController;
use App\Http\Controllers\Merchant\SalesHistoryMerchantController;
use App\Http\Controllers\Merchant\SubscriptionMerchantController;
use App\Http\Controllers\Merchant\ProductSerialMerchantController;
use App\Http\Controllers\Merchant\ResellProductMerchantController;
use App\Http\Controllers\Admin\AccountVerifyRequestAdminController;
use App\Http\Controllers\Merchant\PaymentSettingMerchantController;
use App\Http\Controllers\Merchant\ProductCategoryMerchantController;
use App\Http\Controllers\Merchant\ProductDiscountMerchantController;
use App\Http\Controllers\Merchant\PurchaseHistoryMerchantController;
use App\Http\Controllers\Merchant\TelegramSettingMerchantController;
use App\Http\Controllers\Admin\WalletWithdrawalRequestAdminController;
use App\Http\Controllers\Merchant\AgentSalesHistoryMerchantController;
use App\Http\Controllers\Merchant\ResellableProductMerchantController;
use App\Http\Controllers\Merchant\ProductCategoryLogMerchantController;
use App\Http\Controllers\Merchant\ProductSubCategoryMerchantController;
use App\Http\Controllers\Merchant\AccountVerifyRequestMerchantController;
use App\Http\Controllers\Merchant\ProductSubCategoryLogMerchantController;
use App\Http\Controllers\Admin\PlatformCommissionTransactionAdminController;
use App\Http\Controllers\Admin\WithdrawalTransactionFeeSettingAdminController;


Route::get('/', function () {
    return view('public/home/index');
})->name('home');

Route::name('docs.')->prefix('docs')->group(function () {
    Route::get('api', function () {
        return view('docs/api/index');
    })->name('api');
});



Route::group(['middleware' => 'guest'], function () {
    Route::name('login.')->prefix('login')->group(function () {
        Route::get('/', [AuthController::class, 'loginIndex'])->name('index');
        Route::post('/', [AuthController::class, 'login'])->name('request');
    });

    Route::name('register.')->prefix('register')->group(function () {
        Route::get('/', [AuthController::class, 'registerIndex'])->name('index');
        Route::post('/', [AuthController::class, 'register'])->name('request');
    });

    Route::name('forgot_password.')->prefix('forgot-password')->group(function () {
        Route::get('/', [ForgetPasswordController::class, 'index'])->name('index');
        Route::post('/', [ForgetPasswordController::class, 'forgotPassword'])->middleware(['throttle:resetPasswordRateLimiter'])->name('request');
    });

    Route::name('reset_password.')->prefix('reset-password')->group(function () {
        Route::get('{token}/{email}', [PasswordResetController::class, 'index'])->name('index');
        Route::post('/', [PasswordResetController::class, 'passwordReset'])->name('request');
    });
});


Route::group(['middleware' => 'auth'], function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::post('/sidebar/state', [SidebarController::class, 'saveState'])->name('sidebar.save_state');
});


Route::name('two_factor.')->prefix('two-factor')->middleware(['auth', 'unverified2fa'])->group(function () {
    Route::get('/', [TwoFactorController::class, 'index'])->name('index');
    Route::post('/', [TwoFactorController::class, 'attemp'])->name('attemp');
});


Route::name('merchant.')->prefix('merchant')->middleware(['auth', '2fa', 'role:merchant'])->group(function () {
    Route::get('/', [DashboardMerchantController::class, 'index'])->name('dashboard');

    Route::name('profile.')->prefix('profile')->group(function () {
        Route::name('payment_setting.')->prefix('payment-setting')->group(function () {
            Route::get('/', [PaymentSettingMerchantController::class, 'index'])->name('index');
            Route::get('edit', [PaymentSettingMerchantController::class, 'edit'])->name('edit');
            Route::patch('/', [PaymentSettingMerchantController::class, 'update'])->name('update');
        });

        Route::get('/', [ProfileMerchantController::class, 'index'])->name('index');
        Route::get('edit', [ProfileMerchantController::class, 'edit'])->name('edit');
        Route::patch('profile', [ProfileMerchantController::class, 'update'])->name('update');
        Route::get('change-password', [ProfileMerchantController::class, 'editPassword'])->name('edit_password');
        Route::patch('change-password', [ProfileMerchantController::class, 'updatePassword'])->name('update_password');

        Route::patch('reset-api-secret-key', [ProfileMerchantController::class, 'resetApiSecretKey'])->name('reset_api_secret_key');
        Route::patch('reset-api-public-key', [ProfileMerchantController::class, 'resetApiPublicKey'])->name('reset_api_public_key');
    });


    Route::name('two_factor.')->prefix('two-factor-setting')->group(function () {
        Route::name('setup.')->prefix('setup')->middleware('disabled2fa')->group(function () {
            Route::get('/', [TwoFactorMerchantController::class, 'setupIndex'])->name('index');
            Route::post('/', [TwoFactorMerchantController::class, 'enable'])->name('enable');
        });

        Route::patch('disable', [TwoFactorMerchantController::class, 'disable'])->name('disable');
    });


    Route::name('account_verify_request.')->prefix('account-verify-request')->group(function () {
        Route::post('/', [AccountVerifyRequestMerchantController::class, 'store'])->name('store');
    });


    Route::name('shop.')->prefix('shop')->group(function () {
        Route::name('search_shop.')->prefix('search')->group(function () {
            Route::get('/', [ShopMerchantController::class, 'searchShopIndex'])->name('index');
            Route::get('{id}', [ShopMerchantController::class, 'show'])->name('show');
            Route::post('datatable', [ShopMerchantController::class, 'dataTable'])->name('datatable');
        });

        Route::name('telegram_setting.')->prefix('telegram-setting')->group(function () {
            Route::name('tutorial.')->prefix('tutorial')->group(function () {
                Route::get('/', [TelegramSettingMerchantController::class, 'tutorialIndex'])->name('index');
            });

            Route::get('/', [TelegramSettingMerchantController::class, 'index'])->name('index');
            Route::get('edit', [TelegramSettingMerchantController::class, 'edit'])->name('edit');
            Route::patch('update', [TelegramSettingMerchantController::class, 'update'])->name('update');
        });

        Route::get('/', [ShopMerchantController::class, 'index'])->name('index');
        Route::get('edit', [ShopMerchantController::class, 'edit'])->name('edit');
        Route::patch('/', [ShopMerchantController::class, 'update'])->name('update');
    });


    Route::name('product_category.')->prefix('product-category')->group(function () {
        Route::name('log.')->prefix('log')->group(function () {
            Route::post('datatable/{productCategoryId}', [ProductCategoryLogMerchantController::class, 'datatable'])->name('datatable');
            Route::post('{productCategoryId}', [ProductCategoryLogMerchantController::class, 'store'])->name('store');
        });
        Route::get('/', [ProductCategoryMerchantController::class, 'index'])->name('index');
        Route::post('datatable', [ProductCategoryMerchantController::class, 'dataTable'])->name('datatable');
        Route::get('create', [ProductCategoryMerchantController::class, 'create'])->name('create');
        Route::get('select-search', [ProductCategoryMerchantController::class, 'selectOption'])->name('select_search');
        Route::post('/', [ProductCategoryMerchantController::class, 'store'])->name('store');
        Route::get('{id}', [ProductCategoryMerchantController::class, 'show'])->name('show');
        Route::get('{id}/edit', [ProductCategoryMerchantController::class, 'edit'])->name('edit');
        Route::patch('{id}', [ProductCategoryMerchantController::class, 'update'])->name('update');
        Route::delete('{id}', [ProductCategoryMerchantController::class, 'destroy'])->name('destroy');
    });


    Route::name('product_sub_category.')->prefix('product-sub-category')->group(function () {
        Route::name('log.')->prefix('log')->group(function () {
            Route::post('datatable/{productSubCategoryId}', [ProductSubCategoryLogMerchantController::class, 'datatable'])->name('datatable');
            Route::post('{productSubCategoryId}', [ProductSubCategoryLogMerchantController::class, 'store'])->name('store');
        });
        Route::get('/', [ProductSubCategoryMerchantController::class, 'index'])->name('index');
        Route::post('datatable', [ProductSubCategoryMerchantController::class, 'dataTable'])->name('datatable');
        Route::get('select-search', [ProductSubCategoryMerchantController::class, 'selectOption'])->name('select_search');
        Route::get('create', [ProductSubCategoryMerchantController::class, 'create'])->name('create');
        Route::post('/', [ProductSubCategoryMerchantController::class, 'store'])->name('store');
        Route::delete('{id}', [ProductSubCategoryMerchantController::class, 'destroy'])->name('destroy');
        Route::get('{id}', [ProductSubCategoryMerchantController::class, 'show'])->name('show');
        Route::get('{id}/edit', [ProductSubCategoryMerchantController::class, 'edit'])->name('edit');
        Route::patch('{id}', [ProductSubCategoryMerchantController::class, 'update'])->name('update');
    });


    // Route::name('invite_code.')->prefix('invite-code')->group(function () {
    //     Route::get('/', [InviteCodeMerchantController::class, 'index'])->name('index');
    //     Route::get('create', [InviteCodeMerchantController::class, 'create'])->name('create');
    //     Route::post('/', [InviteCodeMerchantController::class, 'store'])->name('store');
    //     Route::post('datatable', [InviteCodeMerchantController::class, 'dataTable'])->name('datatable');
    //     Route::delete('{id}', [InviteCodeMerchantController::class, 'destroy'])->name('destroy');
    //     Route::get('{id}', [InviteCodeMerchantController::class, 'show'])->name('show');
    // });


    Route::name('shop_agent.')->prefix('shop-agent')->group(function () {
        Route::name('setting.')->prefix('setting')->group(function () {
            Route::get('/', [AgentSettingMerchantController::class, 'index'])->name('index');
            Route::get('edit', [AgentSettingMerchantController::class, 'edit'])->name('edit');
            Route::patch('/', [AgentSettingMerchantController::class, 'update'])->name('update');
        });

        Route::name('approval.')->prefix('approval')->group(function () {
            Route::get('/', [ShopAgentMerchantController::class, 'approvalRequestIndex'])->name('index');
        });

        Route::name('rejected.')->prefix('rejected')->group(function () {
            Route::get('/', [ShopAgentMerchantController::class, 'rejectedRequestIndex'])->name('index');
        });

        Route::get('/', [ShopAgentMerchantController::class, 'index'])->name('index');
        Route::get('{id}', [ShopAgentMerchantController::class, 'show'])->name('show');
        Route::post('datatable', [ShopAgentMerchantController::class, 'datatable'])->name('datatable');
        Route::patch('{id}', [ShopAgentMerchantController::class, 'update'])->name('update');
    });


    Route::name('wallet.')->prefix('wallet')->group(function () {
        Route::name('zixi_pay.')->prefix('usdt')->group(function () {
            Route::get('top-up', [ZixiPayMerchantController::class, 'topUp'])->name('top_up');
        });

        Route::get('/', [WalletMerchantController::class, 'index'])->name('index');
        Route::post('datatable', [WalletMerchantController::class, 'dataTable'])->name('datatable');
        Route::post('/', [WalletMerchantController::class, 'withdraw'])->name('withdraw');
    });


    Route::name('product.')->prefix('product')->group(function () {
        Route::name('log.')->prefix('log')->group(function () {
            Route::post('datatable/{productId}', [ProductLogMerchantController::class, 'datatable'])->name('datatable');
            Route::post('{productId}', [ProductLogMerchantController::class, 'store'])->name('store');
        });

        Route::name('discount.')->prefix('promotion')->group(function () {
            Route::get('{productId}', [ProductDiscountMerchantController::class, 'getAllProductDiscount'])->name('show');
        });

        Route::get('serial-product/select-search', [ProductMerchantController::class, 'selectOption'])->name('serial_product.select_search');

        Route::get('/', [ProductMerchantController::class, 'index'])->name('index');
        Route::post('datatable/{id}', [ProductMerchantController::class, 'dataTable'])->name('datatable');
        Route::get('create', [ProductMerchantController::class, 'create'])->name('create');
        Route::post('/', [ProductMerchantController::class, 'store'])->name('store');
        Route::get('{id}', [ProductMerchantController::class, 'show'])->name('show');
        Route::get('{id}/edit', [ProductMerchantController::class, 'edit'])->name('edit');
        Route::patch('{id}', [ProductMerchantController::class, 'update'])->name('update');
        Route::delete('{id}', [ProductMerchantController::class, 'destroy'])->name('destroy');
    });


    Route::name('product_serial.')->prefix('product-serial')->group(function () {
        Route::get('/', [ProductSerialMerchantController::class, 'index'])->name('index');
        Route::get('create', [ProductSerialMerchantController::class, 'create'])->name('create');
        Route::get('{id}', [ProductSerialMerchantController::class, 'show'])->name('show');
        Route::delete('{id}', [ProductSerialMerchantController::class, 'destroy'])->name('destroy');
        Route::post('datatable', [ProductSerialMerchantController::class, 'dataTable'])->name('datatable');
        Route::post('/', [ProductSerialMerchantController::class, 'store'])->name('store');
        Route::post('export', [ProductSerialMerchantController::class, 'export'])->name('export');
    });


    Route::name('resellable_product.')->prefix('resellable-product')->group(function () {
        Route::get('/', [ResellableProductMerchantController::class, 'index'])->name('index');
        Route::get('{id}', [ResellableProductMerchantController::class, 'show'])->name('show');
        Route::post('datatable', [ResellableProductMerchantController::class, 'datatable'])->name('datatable');
    });


    Route::name('resell_product.')->prefix('resell-product')->group(function () {
        Route::post('shop-agent-datatable', [ResellProductMerchantController::class, 'agentResellProductDatatable'])->name('shop_agent.datatable');

        Route::get('/', [ResellProductMerchantController::class, 'index'])->name('index');
        Route::get('{id}', [ResellProductMerchantController::class, 'show'])->name('show');
        Route::get('get/{id}', [ResellProductMerchantController::class, 'get'])->name('get');
        Route::get('{id}/edit', [ResellProductMerchantController::class, 'edit'])->name('edit');
        Route::patch('{id}', [ResellProductMerchantController::class, 'update'])->name('update');
        Route::post('datatable', [ResellProductMerchantController::class, 'datatable'])->name('datatable');
        Route::delete('{id}', [ResellProductMerchantController::class, 'destroy'])->name('destroy');
        Route::post('{id}', [ResellProductMerchantController::class, 'store'])->name('store');
    });


    Route::name('login_history.')->prefix('login-history')->group(function () {
        Route::get('/', [LoginHistoryMerchantController::class, 'index'])->name('index');
        Route::post('datatable', [LoginHistoryMerchantController::class, 'dataTable'])->name('datatable');
    });


    Route::name('purchase_product.')->prefix('purchase-product')->group(function () {
        Route::get('/', [OrderMerchantController::class, 'index'])->name('index');
        Route::get('{id}/show', [OrderMerchantController::class, 'showProduct'])->name('show');
        Route::post('datatable', [OrderMerchantController::class, 'datatable'])->name('datatable');
        Route::post('{productId}', [OrderMerchantController::class, 'purchase'])->name('purchase');
    });


    Route::name('sales_history.')->prefix('sales-history')->group(function () {
        Route::get('/', [SalesHistoryMerchantController::class, 'index'])->name('index');
        Route::get('{id}', [SalesHistoryMerchantController::class, 'show'])->name('show');
        Route::post('datatable', [SalesHistoryMerchantController::class, 'datatable'])->name('datatable');
    });


    Route::name('agent_sales_history.')->prefix('agent-sales-history')->group(function () {
        Route::get('/', [AgentSalesHistoryMerchantController::class, 'index'])->name('index');
        Route::post('datatable', [AgentSalesHistoryMerchantController::class, 'datatable'])->name('datatable');
    });


    Route::name('profit.')->prefix('profit')->group(function () {
        Route::get('daily/{date}', [SalesHistoryMerchantController::class, 'dailyTotalProfit'])->name('daily');
        Route::get('monthly/{year}/{month}', [SalesHistoryMerchantController::class, 'monthlyTotalProfit'])->name('monthly');
        Route::get('yearly/{year}', [SalesHistoryMerchantController::class, 'yearlyTotalProfit'])->name('yearly');
    });


    Route::name('purchase_history.')->prefix('purchase-history')->group(function () {
        Route::get('/', [PurchaseHistoryMerchantController::class, 'index'])->name('index');
        Route::get('{id}', [PurchaseHistoryMerchantController::class, 'show'])->name('show');
        Route::post('datatable', [PurchaseHistoryMerchantController::class, 'datatable'])->name('datatable');
    });


    Route::name('order.')->prefix('order')->group(function () {
        Route::name('comment.')->prefix('comment')->group(function () {
            Route::post('{orderId}', [OrderCommentMerchantController::class, 'store'])->name('store');
        });
    });


    Route::name('discord_bot.')->prefix('discord-bot')->group(function () {
        Route::name('tutorial.')->prefix('tutorial')->group(function () {
            Route::get('/', [DiscordBotMerchantController::class, 'tutorialIndex'])->name('index');
        });

        Route::get('/', [DiscordBotMerchantController::class, 'index'])->name('index');
        Route::post('datatable', [DiscordBotMerchantController::class, 'dataTable'])->name('datatable');
        Route::get('create', [DiscordBotMerchantController::class, 'create'])->name('create');
        Route::get('select-search', [DiscordBotMerchantController::class, 'selectOption'])->name('select_search');
        Route::post('/', [DiscordBotMerchantController::class, 'store'])->name('store');
        Route::get('{id}', [DiscordBotMerchantController::class, 'show'])->name('show');
        Route::get('{id}/edit', [DiscordBotMerchantController::class, 'edit'])->name('edit');
        Route::patch('{id}', [DiscordBotMerchantController::class, 'update'])->name('update');
        Route::delete('{id}', [DiscordBotMerchantController::class, 'destroy'])->name('destroy');
    });


    Route::name('notification.')->prefix('notification-history')->group(function () {
        Route::get('/', [NotificationController::class, 'index'])->name('index');
        Route::post('datatable', [NotificationController::class, 'dataTable'])->name('datatable');
        Route::patch('/', [NotificationController::class, 'update'])->name('update');
        Route::get('{id}', [NotificationController::class, 'show'])->name('show');
    });


    Route::name('subscription.')->prefix('subscription')->group(function () {
        Route::get('/', [SubscriptionMerchantController::class, 'index'])->name('index');
    });
});


Route::name('admin.')->prefix('admin')->middleware(['auth', '2fa', 'role:admin'])->group(function () {
    Route::get('/', [DashboardAdminController::class, 'index'])->name('dashboard');

    Route::name('profile.')->prefix('profile')->group(function () {
        Route::get('/', [ProfileAdminController::class, 'index'])->name('index');
        Route::get('edit', [ProfileAdminController::class, 'edit'])->name('edit');
        Route::patch('profile', [ProfileAdminController::class, 'update'])->name('update');
        Route::get('change-password', [ProfileAdminController::class, 'editPassword'])->name('edit_password');
        Route::patch('change-password', [ProfileAdminController::class, 'updatePassword'])->name('update_password');
    });


    Route::name('staff.')->prefix('staff')->group(function () {
        Route::get('/', [StaffAdminController::class, 'index'])->name('index');
        Route::get('create', [StaffAdminController::class, 'create'])->name('create');
        Route::post('/', [StaffAdminController::class, 'store'])->name('store');
        Route::get('{id}/edit', [StaffAdminController::class, 'edit'])->name('edit');
        Route::patch('{id}', [StaffAdminController::class, 'update'])->name('update');
        Route::post('datatable', [StaffAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [StaffAdminController::class, 'show'])->name('show');
        Route::delete('{id}', [StaffAdminController::class, 'destroy'])->name('destroy');
    });


    Route::name('merchant.')->prefix('merchant')->group(function () {
        Route::get('/', [MerchantAdminController::class, 'index'])->name('index');
        Route::post('datatable', [MerchantAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [MerchantAdminController::class, 'show'])->name('show');
        Route::get('{id}/edit', [MerchantAdminController::class, 'edit'])->name('edit');
        Route::patch('{id}', [MerchantAdminController::class, 'update'])->name('update');
        Route::patch('account-verify/{id}', [MerchantAdminController::class, 'updateAccountVerify'])->name('account_verify.update');
    });


    Route::name('wallet.')->prefix('wallet')->group(function () {
        Route::get('/', [WalletAdminController::class, 'index'])->name('index');
        Route::post('datatable', [WalletAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [WalletAdminController::class, 'show'])->name('show');
    });


    Route::name('wallet_transaction.')->prefix('wallet-transaction')->group(function () {
        Route::post('datatable', [WalletTransactionAdminController::class, 'dataTable'])->name('datatable');
    });


    Route::name('shop.')->prefix('shop')->group(function () {
        Route::get('/', [ShopAdminController::class, 'index'])->name('index');
        Route::post('datatable', [ShopAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}/edit', [ShopAdminController::class, 'edit'])->name('edit');
        Route::get('{id}', [ShopAdminController::class, 'show'])->name('show');
        Route::patch('{id}', [ShopAdminController::class, 'update'])->name('update');
    });


    Route::name('wallet_withdrawal_request.')->prefix('wallet-withdrawal-request')->group(function () {
        Route::get('/', [WalletWithdrawalRequestAdminController::class, 'index'])->name('index');
        Route::post('datatable', [WalletWithdrawalRequestAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [WalletWithdrawalRequestAdminController::class, 'show'])->name('show');
        Route::patch('{id}', [WalletWithdrawalRequestAdminController::class, 'update'])->name('update');
    });


    Route::name('login_history.')->prefix('login-history')->group(function () {
        Route::get('/', [LoginHistoryAdminController::class, 'index'])->name('index');
        Route::post('datatable', [LoginHistoryAdminController::class, 'dataTable'])->name('datatable');
    });


    Route::name('product.')->prefix('product')->group(function () {
        Route::get('/', [ProductAdminController::class, 'index'])->name('index');
        Route::post('datatable', [ProductAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [ProductAdminController::class, 'show'])->name('show');
    });


    Route::name('invite_code.')->prefix('invite-code')->group(function () {
        Route::get('/', [InviteCodeAdminController::class, 'index'])->name('index');
        Route::post('/', [InviteCodeAdminController::class, 'store'])->name('store');
        Route::get('create', [InviteCodeAdminController::class, 'create'])->name('create');
        Route::post('/', [InviteCodeAdminController::class, 'store'])->name('store');
        Route::post('datatable', [InviteCodeAdminController::class, 'dataTable'])->name('datatable');
        Route::delete('{id}', [InviteCodeAdminController::class, 'destroy'])->name('destroy');
        Route::get('{id}', [InviteCodeAdminController::class, 'show'])->name('show');
    });


    Route::name('two_factor.')->prefix('two-factor-setting')->group(function () {
        Route::name('setup.')->prefix('setup')->middleware('disabled2fa')->group(function () {
            Route::get('/', [TwoFactorAdminController::class, 'setupIndex'])->name('index');
            Route::post('/', [TwoFactorAdminController::class, 'enable'])->name('enable');
        });

        Route::patch('disable', [TwoFactorAdminController::class, 'disable'])->name('disable');
        Route::patch('disable/{userId}', [TwoFactorAdminController::class, 'disableUser'])->name('user.disable');
    });


    Route::name('account_verify_request.')->prefix('account-verify-request')->group(function () {
        Route::name('rejected.')->prefix('rejected')->group(function () {
            Route::get('/', [AccountVerifyRequestAdminController::class, 'rejectedIndex'])->name('index');
            Route::post('datatable', [AccountVerifyRequestAdminController::class, 'rejectedDataTable'])->name('datatable');
        });

        Route::get('/', [AccountVerifyRequestAdminController::class, 'index'])->name('index');
        Route::post('datatable', [AccountVerifyRequestAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [WalletWithdrawalRequestAdminController::class, 'show'])->name('show');
        Route::patch('{id}', [AccountVerifyRequestAdminController::class, 'update'])->name('update');
    });


    Route::name('platform_setting.')->prefix('platform-setting')->group(function () {
        Route::get('/', [PlatformSettingAdminController::class, 'index'])->name('index');
        Route::patch('/', [PlatformSettingAdminController::class, 'update'])->name('update');
    });


    Route::name('withdrawal_transaction_fee_setting.')->prefix('withdrawal-transaction-fee-setting')->group(function () {
        Route::get('/', [WithdrawalTransactionFeeSettingAdminController::class, 'index'])->name('index');
        Route::patch('/', [WithdrawalTransactionFeeSettingAdminController::class, 'update'])->name('update');
    });


    Route::name('shop_agent.')->prefix('shop-agent')->group(function () {
        Route::get('/', [ShopAgentAdminController::class, 'index'])->name('index');
        Route::post('datatable', [ShopAgentAdminController::class, 'dataTable'])->name('datatable');
        Route::get('{id}', [ShopAgentAdminController::class, 'show'])->name('show');
    });


    Route::name('platform_commission_transaction.')->prefix('platform-commission-transaction')->group(function () {
        Route::get('/', [PlatformCommissionTransactionAdminController::class, 'index'])->name('index');
        Route::post('datatable', [PlatformCommissionTransactionAdminController::class, 'dataTable'])->name('datatable');
    });


    Route::name('platform_order.')->prefix('platform-order')->group(function () {
        Route::get('/', [OrderAdminController::class, 'index'])->name('index');
        Route::get('{id}', [OrderAdminController::class, 'show'])->name('show');
        Route::post('datatable', [OrderAdminController::class, 'datatable'])->name('datatable');
        Route::post('{id}', [OrderCommentAdminController::class, 'store'])->name('store');
    });


    Route::name('resell_product.')->prefix('resell-product')->group(function () {
        Route::post('datatable/{id}', [ResellProductAdminController::class, 'shopResellProductDataTable'])->name('datatable');
    });
});
