<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ZixiPayController;


Route::post('zixipay-callback', [ZixiPayController::class, 'callback'])->name('zixi_pay.callback');
