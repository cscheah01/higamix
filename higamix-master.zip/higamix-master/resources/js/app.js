require("./bootstrap");

$.fn.datetimepicker.Constructor.Default = $.extend(
    {},
    $.fn.datetimepicker.Constructor.Default,
    {
        icons: {
            time: "fas fa-clock",
            date: "fas fa-calendar",
            up: "fas fa-arrow-up",
            down: "fas fa-arrow-down",
            previous: "fas fa-arrow-circle-left",
            next: "fas fa-arrow-circle-right",
            today: "far fa-calendar-check-o",
            clear: "fas fa-trash",
            close: "far fa-times",
        },
    }
);

$.validator.addMethod("greaterOrEqual", function (value, element, param) {
    var $otherElement = $(param);
    return parseInt(value, 10) >= parseInt($otherElement.val(), 10);
});

document.addEventListener("resume", (event) => {
    setTimeout(function () {
        $(".spinner-wrapper").addClass("d-none");
    }, 2000);
});

$(function () {
    window.onbeforeunload = function () {
        setTimeout(function () {
            $(".spinner-wrapper").removeClass("d-none");
        }, 2000);
    };

    if ($(window).scrollTop() > 35) {
        $("body").addClass("scrolled");
    } else {
        $("body").removeClass("scrolled");
    }

    $(window).scroll(function () {
        if ($(this).scrollTop() > 35) {
            $("body").addClass("scrolled");
        } else {
            $("body").removeClass("scrolled");
        }
    });

    bsCustomFileInput.init();

    resetForm = function (targetForm) {
        $(targetForm)[0].reset();
        $(targetForm).validate().resetForm();
        toastr.clear();
    };

    $("input").attr("autocomplete", "off");

    _quillEditorModules = {
        toolbar: [
            [
                {
                    font: [],
                },
            ],
            [
                {
                    size: ["small", false, "large", "huge"],
                },
            ],
            ["bold", "italic", "underline", "strike"],
            [
                {
                    color: [],
                },
                {
                    background: [],
                },
            ],
            [
                {
                    align: [],
                },
            ],
            [
                {
                    list: "ordered",
                },
                {
                    list: "bullet",
                },
            ],
            ["link", "image"],
        ],
    };
});
