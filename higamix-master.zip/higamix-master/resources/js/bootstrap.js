window._ = require("lodash");
import { v4 as uuidv4 } from "uuid";
import Quill from "quill";

try {
    window.Popper = require("popper.js").default;
    window.$ = window.jQuery = require("jquery");
    window.bsCustomFileInput = require("bs-custom-file-input");
    window.moment = require("moment");

    require("bootstrap");
    require("admin-lte");
    require("datatables.net-bs4");
    require("datatables.net-buttons");
    require("datatables.net-responsive");
    require("select2");
    require("jquery-validation");
    require("tempusdominus-bootstrap-4");
    window.toastr = require("toastr");
    window.Swal = require("sweetalert2");
    window.uuidv4 = uuidv4;
    window.Quill = Quill;
    window.ScrollMagic = require("scrollmagic");
    window.Chart = require("chart.js/auto").default;
} catch (e) {}

/**
 * We'll load the axios HTTP library which allows us to easily issue requests
 * to our Laravel back-end. This library automatically handles sending the
 * CSRF token as a header based on the value of the "XSRF" token cookie.
 */

window.axios = require("axios");

window.axios.defaults.headers.common["X-Requested-With"] = "XMLHttpRequest";

/**
 * Echo exposes an expressive API for subscribing to channels and listening
 * for events that are broadcast by Laravel. Echo and event broadcasting
 * allows your team to easily build robust real-time web applications.
 */

// import Echo from 'laravel-echo';

// window.Pusher = require('pusher-js');

// window.Echo = new Echo({
//     broadcaster: 'pusher',
//     key: process.env.MIX_PUSHER_APP_KEY,
//     cluster: process.env.MIX_PUSHER_APP_CLUSTER,
//     forceTLS: true
// });
