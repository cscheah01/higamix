@php
use App\Enums\OrderStatus;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'Agent Sales History')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Agent Sales History</h1>
                    <h4 class="m-0 d-block d-sm-none">Agent Sales History</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-agent-shop-name">Agent Shop Name</label>
                            <input type="search" id="filter-agent-shop-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-name">Product Name</label>
                            <input type="search" id="filter-product-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-type">Product Type</label>
                            <select id="filter-product-type" class="form-control">
                                <option disabled selected>Please Select Product Type</option>
                                @foreach ($productTypes as $productType)
                                    <option value="{{ $productType['value'] }}">{{ $productType['description'] }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-order-id">Order ID</label>
                            <input type="search" id="filter-order-id" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-from" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">Date
                                From</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-from"
                                data-target-input="nearest" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-from"
                                    data-target="#datetimepicker-date-from" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-to" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">Date
                                To</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-to"
                                data-target-input="nearest" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-to"
                                    data-target="#datetimepicker-date-to" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form')">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Agent Shop Name</th>
                        <th>Product Name</th>
                        <th>Product Type</th>
                        <th>Qty</th>
                        <th>Date</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(function() {
            $('.date-time-picker').datetimepicker({
                format: 'DD-MM-YYYY hh:mm A',
            });

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.agent_sales_history.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";

                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                            orderId: $("#filter-order-id").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                        data.order_id = filters.orderId;
                    }
                },
                columns: [{
                        data: "order_id",
                        name: "order_id"
                    },
                    {
                        data: "agent_shop_name",
                        name: "shops.name"
                    },
                    {
                        data: "parent_product_name",
                        name: "parent_product.name"
                    },
                    {
                        data: "product_type_label",
                        name: "product_type"
                    },
                    {
                        data: "qty",
                        name: "qty"
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `${createdAt}`;
                        }
                    },
                ],
                order: [
                    [5, "desc"]
                ],
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    agentShopName: $("#filter-agent-shop-name").val(),
                    productName: $('#filter-product-name').val(),
                    productType: $('#filter-product-type').val() ?? ''
                };

                $table.column(1).search(filters.agentShopName);
                $table.column(2).search(filters.productName);
                $table.column(3).search(filters.productType);
                $table.draw();
            });
        });
    </script>
@endsection
