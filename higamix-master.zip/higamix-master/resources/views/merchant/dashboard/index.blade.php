@php
use App\Enums\OrderStatus;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'Dashboard')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Dashboard</h1>
                    <h4 class="m-0 d-block d-sm-none">Dashboard</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-sm-6 col-xl-3 mb-3">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-wallet fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Wallet Balance
                        </div>
                        <div>
                            <b>USDT {{ $walletBalance }}</b>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <hr class="m-0">
                        <a href="{{ route('merchant.wallet.index') }}">More info <i class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3 mb-3 mb-sm-0">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-file-invoice-dollar fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Today Sales
                        </div>
                        <div>
                            <b>USDT {{ $todayTotalSales ?? number_format(0, 2) }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('merchant.sales_history.index') }}">More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3 mb-3 mb-sm-0">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-file-contract fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Pending Agent Request
                        </div>
                        <div>
                            <b>{{ $totalPendingAgentRequest }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('merchant.shop_agent.approval.index') }}">More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3 mb-3 mb-sm-0">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-bell fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Unseen Notification
                        </div>
                        <div>
                            <b>{{ $totalUnseenNotificationCount }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('merchant.notification.index') }}"> More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Sales & Profit</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('merchant.sales_history.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-4 mb-3">
                    <div class="border shadow-sm rounded">
                        <div class="p-3">
                            <div class="form-group">
                                <label for="filter-product-name">Daily Profit</label>
                                <input type="date" id="daily" class="form-control" onchange="getDailyProfit()">
                            </div>
                            <div>
                                <b>USDT <span id="daily-profit-amount">{{ number_format($dailyProfit, 2) }}</span></b>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 mb-3 mb-sm-0">
                    <div class="border shadow-sm rounded">
                        <div class="p-3">
                            <div class="form-group">
                                <label for="filter-shop-name">Monthly Profit</label>
                                <input type="month" id="monthly" class="form-control" onchange="getMonthlyProfit()">
                            </div>
                            <div>
                                <b>USDT <span id="monthly-profit-amount">{{ number_format($monthlyProfit, 2) }}</span></b>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 mb-3 mb-sm-0">
                    <div class="border shadow-sm rounded">
                        <div class="p-3">
                            <div class="form-group">
                                <label for="filter-agent-code">Yearly Profit</label>
                                <div class="input-group">
                                    <span class="input-group-prepend">
                                        <button type="button" class="btn btn-number border" onclick="minusBtn()">
                                            <span class="fa fa-minus"></span>
                                        </button>
                                    </span>
                                    <input type="text" id="yearly" class="form-control text-center" disabled>
                                    <span class="input-group-append">
                                        <button type="button" class="btn btn-number border" onclick="addBtn()">
                                            <span class="fa fa-plus"></span>
                                        </button>
                                    </span>
                                </div>
                            </div>
                            <div>
                                <b>USDT <span id="yearly-profit-amount">{{ number_format($yearlyProfit, 2) }}</span></b>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <hr>

            <h3 class="mt-5">Monthly Sales</h3>
            <canvas id="monthly-sales-chart" width="auto" height="80"></canvas>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Shop Agent Approval Request</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('merchant.shop_agent.approval.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body table-responsive">
            <table id="shop-agent-approval-table" class="table table-bordered dt-responsive rounded"
                style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Shop Name</th>
                        <th>Requested At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Sales History</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('merchant.sales_history.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>

        </div>
        <div class="card-body table-responsive">
            <table id="sales-history-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Order Id</th>
                        <th>Buyer Email</th>
                        <th>Total (USDT)</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            var currentYearEachMonthSales = @json($currentYearEachMonthSales);

            const monthlySalesChartContext = document.getElementById('monthly-sales-chart').getContext('2d');
            const monthlySalesChart = new Chart(monthlySalesChartContext, {
                type: 'line',
                data: {
                    labels: [
                        'January',
                        'Febraury',
                        'March',
                        'April',
                        'May',
                        'June',
                        'July',
                        'August',
                        'September',
                        'October',
                        'November',
                        'December'
                    ],
                    datasets: [{
                        label: 'Sales (USDT)',
                        data: currentYearEachMonthSales,
                        fill: true,
                        borderColor: '#002FA7',
                        tension: 0.1,
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });

            $('#shop-agent-approval-table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.shop_agent.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "is_waiting_approved",
                        name: "is_waiting_approved",
                        visible: false
                    },
                    {
                        data: null,
                        name: "shop_name",
                        orderable: false,
                        render: function(data, type, row) {
                            var url =
                                `{{ route('merchant.shop.search_shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        width: "150px",
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var UpdateUrl =
                                `{{ route('merchant.shop_agent.update', ['id' => ':id']) }}`;
                            UpdateUrl = UpdateUrl.replace(':id', data.id);

                            return `
                            <div class="d-flex">
                                <form method="post" action=" ${UpdateUrl}">
                                    @csrf
                                    @method('PATCH')

                                    <div class="d-flex">
                                        <input type="hidden" name="is_approved" id="is_approved">
                                        <button type="submit" class="btn btn-success mr-1" onclick="approveAgent(event)">
                                            Approve
                                        </button>
                                        <button type="submit" class="btn btn-danger" onclick="rejectAgent(event)">
                                            Reject
                                        </button>
                                    </div>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
                searchCols: [{
                        search: 1,
                    },
                    null,
                    null,
                    null,
                ],
            });

            approveAgent = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to approve this request?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#is_approved').val(1);
                        $(e.target).closest('form').submit();
                    }
                })
            };

            rejectAgent = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to reject this request?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, reject it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#is_approved').val(0);
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $('#sales-history-table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.sales_history.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";

                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                    }
                },
                columns: [{
                        data: "id",
                        name: "id"
                    },
                    {
                        data: "email",
                        name: "users.email"
                    },
                    {
                        className: "dt-body-right",
                        data: "total",
                        name: "total"
                    },
                    {
                        data: null,
                        width: "50px",
                        name: "status",
                        className: "text-center",
                        render: function(data, type, row) {
                            if (data.status ==
                                "{{ OrderStatus::CompletePayment()->key }}") {
                                return `<span class="badge badge-success">${data.status_label}
                                    </span>`
                            } else {
                                return `<span class="badge badge-light">${data.status_label}</span>`
                            }
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.sales_history.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            return `
                            <div class="d-flex">
                                <a class="btn btn-success" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>

                            `;
                        }
                    },
                ],
                order: [
                    [4, "desc"]
                ],
            });


            today = moment().format("YYYY-MM-DD");
            currentMonth = moment().format("YYYY-MM")
            currentYear = moment().format("YYYY");

            $('#daily').attr("value", today);
            $('#monthly').attr("value", currentMonth);
            $('#yearly').attr("value", currentYear);
        });


        function getDailyProfit() {
            $('#daily-profit-amount').html('loading...');

            var date = $('#daily').val();

            var url =
                `{{ route('merchant.profit.daily', ['date' => ':date']) }}`
            url = url.replace(':date', date);

            $.ajax({
                type: 'GET',
                url: url,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    var total = parseFloat(data);
                    $('#daily-profit-amount').html((total).toFixed(2));
                }
            });
        }

        function getMonthlyProfit() {
            $('#monthly-profit-amount').html("loading...");

            var year = $('#monthly').val().substring(0, 4);
            var month = $('#monthly').val().substring(5, 8);

            var url =
                `{{ route('merchant.profit.monthly', ['year' => ':year', 'month' => ':month']) }}`
            url = url.replace(':year', year);
            url = url.replace(':month', month);

            $.ajax({
                type: 'GET',
                url: url,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    var total = parseFloat(data);
                    $('#monthly-profit-amount').html((total).toFixed(2));
                }
            });
        }

        function getYearlyProfit() {
            $('#yearly-profit-amount').html("loading...");

            var date = $('#yearly').val();

            var url =
                `{{ route('merchant.profit.yearly', ['year' => ':year']) }}`
            url = url.replace(':year', date);

            $.ajax({
                type: 'GET',
                url: url,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    var total = parseFloat(data);
                    $('#yearly-profit-amount').html((total).toFixed(2));
                }
            });
        }

        function minusBtn() {
            var date = $('#yearly').val();
            $('#yearly').val(date - 1);
            getYearlyProfit();
        }

        function addBtn() {
            var date = $('#yearly').val();
            date++;
            $('#yearly').val(date);
            getYearlyProfit();
        }
    </script>
@endsection
