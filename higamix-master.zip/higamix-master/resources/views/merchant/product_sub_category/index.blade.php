@extends('merchant/layout/layout')

@section('page_title', 'Product Sub Category')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Sub Category</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Sub Category</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a type="button" class="btn btn-success"
                            href="{{ route('merchant.product_sub_category.create') }}">
                            Create Sub Category
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-sub-category-name">Sub Category Name</label>
                            <input type="search" id="filter-sub-category-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-main-category-name">Main Category Name</label>
                            <input type="search" id="filter-main-category-name" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Sub Category Name</th>
                        <th>Main Category Name</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.product_sub_category.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "product_category_name",
                        name: "product_categories.name"
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                           ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.product_sub_category.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var editUrl =
                                `{{ route('merchant.product_sub_category.edit', ['id' => ':id']) }}`;
                            editUrl = editUrl.replace(':id', data.id);

                            var deleteUrl =
                                `{{ route('merchant.product_sub_category.destroy', ['id' => ':id']) }}`;
                            deleteUrl = deleteUrl.replace(':id', data.id);


                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <a class="btn btn-primary mr-1" href="${editUrl}">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <form method="post" action="${deleteUrl}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteProductSubCategory(event)">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
            });

            deleteProductSubCategory = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    subCategoryName: $("#filter-sub-category-name").val(),
                    mainCategoryName: $("#filter-main-category-name").val(),
                };

                $table.column(0).search(filters.subCategoryName);
                $table.column(1).search(filters.mainCategoryName);
                $table.draw();
            });
        });
    </script>
@endsection
