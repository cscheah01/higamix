@extends('merchant/layout/layout')

@section('page_title', 'Create Product Sub Category')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Create Product Sub Category</h1>
                    <h4 class="m-0 d-block d-sm-none">Create Product Sub Category</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.product_sub_category.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('merchant.product_sub_category.store') }}" method="post">
            @csrf

            <div class="card-body">
                <div class="form-group">
                    <label for="product_category_id">Main Category Name</label>
                    <select class="form-control" id="product_category_id" name="product_category_id" style="width: 100%;"
                        required></select>
                </div>

                <div class="d-flex align-items-center mt-5 mb-3">
                    <h5 class="mr-3">Sub Category</h5>
                    <button type="button" class="btn btn-primary" onclick="addSubCategory()">
                        Add
                    </button>
                </div>
                <div class="card">
                    <div class="card-body sub-category-wrapper">
                        <div class="alert alert-secondary empty-sub-category-alert">
                            This category was no sub category
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Create
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });


            $("#product_category_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Main Category',
                ajax: {
                    url: '{{ route('merchant.product_category.select_search') }}',
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });
        });

        function addSubCategory() {
            var nextNumber = $('.sub-category-row').length;

            $('.sub-category-wrapper').append(
                `
                <div class="row mb-3 sub-category-row">
                    <div class="col">
                        <div class="form-group m-0">
                            <input type="text" class="form-control sub-category-name-input" name="product_sub_category[${nextNumber}][name]" placeholder="Sub Category Name" required>
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="button" class="btn btn-danger btn-remove-sub-category">
                            Remove
                        </button>
                    </div>
                </div>`);

            checkEmptySubCategory();
        }


        $(document).on('click', '.btn-remove-sub-category', function() {
            $(this).closest('.sub-category-row').remove();
            reAssignSubCategoryInputName();
            checkEmptySubCategory();
        });

        function reAssignSubCategoryInputName() {
            var subCategoryNameCount = 1;
            $('.sub-category-name-input').each(function() {
                $(this).attr(`'name', 'product_sub_category['${subCategoryNameCount}'][name]'`);
                subCategoryNameCount++;
            })
        }

        function checkEmptySubCategory() {
            var alert = $('.empty-sub-category-alert');


            if ($('.sub-category-row').length) {
                alert.addClass('d-none')
            } else {
                alert.removeClass('d-none')
            }
        }
    </script>
@endsection
