@extends('merchant/layout/layout')

@section('page_title', 'Edit Product Sub Category')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Edit Product Sub Category</h1>
                    <h4 class="m-0 d-block d-sm-none">Edit Product Sub Category</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark"
                            href="{{ route('merchant.product_sub_category.show', ['id' => $productSubCategory->id]) }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form"
            action="{{ route('merchant.product_sub_category.update', ['id' => $productSubCategory->id]) }}"
            method="post">
            @csrf
            @method('PATCH')

            <div class="card-body">
                <div class="form-group">
                    <label>Main Category Name</label>
                    <input type="text" class="form-control" value="{{ $productSubCategory->productCategory->name }}"
                        disabled>
                </div>
                <div class="form-group">
                    <label for="name">Sub Category Name</label>
                    <input type="text" class="form-control" id="name" name="name"
                        value="{{ $productSubCategory->name }}" placeholder="Sub Category Name" required>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Save Edit
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
        });
    </script>
@endsection
