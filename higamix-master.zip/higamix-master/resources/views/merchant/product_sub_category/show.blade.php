@extends('merchant/layout/layout')

@section('page_title', 'Product Sub Category Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Sub Category Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Sub Category Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('merchant.product_sub_category.index') }}">
                                Back
                            </a>
                            <form method="post"
                                action={{ route('merchant.product_sub_category.destroy', ['id' => $productSubCategory->id]) }}
                                class="mr-1">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="deleteProductSubCategory(event)">
                                    Delete
                                </button>
                            </form>
                            <a class="btn btn-primary"
                                href="{{ route('merchant.product_sub_category.edit', ['id' => $productSubCategory->id]) }}">
                                Edit
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-6 mb-3">
                    <label>Sub Category Name:</label>
                    <div>
                        {{ $productSubCategory->name }}
                    </div>
                </div>
                <div class="col-12 col-md-6 mb-3">
                    <label>Main Category Name:</label>
                    <div>
                        {{ $productSubCategory->productCategory->name }}
                    </div>
                </div>
                <div class="col-12 col-md-6 mb-3">
                    <label>Created At:</label>
                    <div>
                        {{ $productSubCategory->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-auto col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Product Sub Category Log</h4>
                </div>
                <div class="col-auto col-sm-4 col-lg-3 text-right">
                    @if ($productSubCategory->productCategory->shop->user_id == Auth::id())
                        <button type="button" class="btn btn-primary" data-toggle="modal"
                            data-target="#add-product-sub-category-log-modal">
                            Add Product Sub Category Log
                        </button>
                    @endif
                </div>
            </div>
        </div>

        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Created At</th>
                        <th>Log Content</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="add-product-sub-category-log-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Product Sub Category Log</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="form"
                        action="{{ route('merchant.product_sub_category.log.store', ['productSubCategoryId' => $productSubCategory->id]) }}">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-12 input-wrapper">
                                <textarea class="form-control" id="content" name="content" placeholder="Content" rows="7" required></textarea>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="form" class="btn btn-success" onclick="addProductSubCategoryLog(event)">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.product_sub_category.log.datatable', ['productSubCategoryId' => $productSubCategory->id]) }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    },
                },
                columns: [{
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `${createdAt}`;
                        }
                    },
                    {
                        className: "double-line-ellipsis",
                        data: "content",
                        name: "content",
                        orderable: false
                    },
                ],
                order: [
                    [0, "desc"]
                ],
            });

            $('#table thead th').removeClass('double-line-ellipsis');

            addProductSubCategoryLog = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Add product sub category log will notify resell via discord and telegram group. Are you sure?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Confirm'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#form').submit();
                    }
                })
            };

            deleteProductSubCategory = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>
@endsection
