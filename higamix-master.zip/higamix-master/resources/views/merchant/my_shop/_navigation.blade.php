<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills nav-sidebar flex-column">
            <li class="nav-item">
                <a href="{{ route('merchant.shop.index') }}"
                    class="nav-link {{ Request::routeIs('merchant.shop.index') || Request::routeIs('merchant.shop.edit') ? 'active' : '' }}">
                    <p>
                        Shop
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('merchant.shop.telegram_setting.index') }}"
                    class="nav-link {{ Request::routeIs('merchant.shop.telegram_setting.index')|| Request::routeIs('merchant.shop.telegram_setting.edit') ? 'active' : '' }}">
                    <p>
                        Telegram
                    </p>
                </a>
            </li>
        </ul>
    </div>
</div>
