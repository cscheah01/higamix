@extends('merchant/layout/layout')

@section('page_title', 'Shop Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-md-4">
            @include('merchant/my_shop/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Shop Details</h4>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-primary" href="{{ route('merchant.shop.edit') }}">
                                    Edit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="img-wrap mx-auto mb-4 border img-circle shadow">
                                <img id="logo-preview" class="img"
                                    src="{{ $shop['logo_image'] != null ? url('storage/shop_logo/' . $shop['logo_image']) : asset('img/empty-image.png') }}"
                                    onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                            </div>
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12 col-md-3">
                            <label>Shop Name</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <div>
                                {{ $shop['name'] }}
                            </div>
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12 col-md-3">
                            <label>Shop Description</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <div class="ql-container ql-snow" style="min-height:150px;">
                                <div class="ql-editor">{!! $shop['description'] !!}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

        });
    </script>
@endsection
