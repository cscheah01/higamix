@extends('merchant/layout/layout')

@section('page_title', 'Telegram Setting Tutorial')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Telegram Setting Tutorial</h1>
                    <h4 class="m-0 d-block d-sm-none">Telegram Setting Tutorial</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.shop.telegram_setting.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Step 1 : Creating bot</h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12">
                            <p class="mt-2"> i) Add the telegram bot by searching @BotFather in telegram.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-search-bot-father.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2"> ii) Send “/start” to activate the BotFather and it will send a list of
                                commands to control the BotFather.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-start-bot-father.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">iii) Then, choose the option of create a new bot with sending “/newbot” to
                                bot father. After that, follow the father bot’s instruction to name your bot and choose a
                                username for it. For example: </p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-create-bot.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">iv) Finally, you will receive a message from bot father, which notify you
                                that you have successfully created a telegram bot. Record down the token given by bot
                                father. For example: </p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-record-token.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-header">
                    <h4 class="mb-0">Step 2 : Add bot to your channel</h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12">
                            <p class="mt-2"> i) Add the bot u created just now in your channel and make it as admin.
                                For example: </p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-select-administrators.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-add-bot.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-header">
                    <h4 class="mb-0">Step 3 : Setup channel username</h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12">
                            <p class="mt-2"> i) At Manage channel option, change your channel type to public and
                                add the channel username at Link section as image below.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-edit-channel-privacy.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-change-channel-type.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-set-public-channel-username.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-header">
                    <h4 class="mb-0">Step 4 : Setup bot and group at HiGamix</h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12">
                            <p class="mt-2"> i) Enable the send telegram notification section.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-set-enable-telegram-HiGamix.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">

                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">ii) Insert the Group Link by the link at your telegram “channel info ->
                                link section”. </p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-group-link.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-group-link-HiGamix.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">iii) Insert Channel Username by the channel username you created at step
                                2.</p>
                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-channel-username.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-channel-username-HiGamix.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">iv) Insert the Bot API key by the token given by bot father at step 1.
                            </p>
                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-api-bot-key.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-api-bot-key-HiGamix.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">v) Example of a complete telegram setting.</p>
                            <img class="img-fluid d-block"
                                src="{{ asset('img/telegram-tutorial/telegram-tutorial-example-complete-telegram-setting-HiGamix.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">vi) Telegram setting has been setup, the notification is now will send to
                                the channel created at telegram when you added a product log. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script></script>
@endsection
