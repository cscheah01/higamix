@extends('merchant/layout/layout')

@section('page_title', 'Edit Payment Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Account Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Account Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-12 col-md-4">
            @include('merchant/my_shop/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="d-flex">
                                <h4 class="mb-0 mr-2">Telegram Setting</h4>
                                <a class="mt-1" href="{{ route('merchant.shop.telegram_setting.tutorial.index') }}">
                                    View
                                    Tutorial</a>
                            </div>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-dark" href="{{ route('merchant.shop.telegram_setting.index') }}">
                                    Back
                                </a>
                                <button type="submit" form="form" class="btn btn-success">
                                    Save Edit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form id="form" action="{{ route('merchant.shop.telegram_setting.update') }}" method="post">
                        @csrf
                        @method('PATCH')

                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label">Send Telegram Notification</label>
                            <div class="col-sm-8 input-wrapper mt-2">
                                <div class="d-flex">
                                    <div class="custom-control custom-radio ml-2">
                                        <input type="radio" class="custom-control-input"
                                            name="is_enabled_telegram_notification" id="enable_telegram_notification"
                                            value="1" @if ($shop['is_enabled_telegram_notification']) checked @endif required>
                                        <label for="enable_telegram_notification"
                                            class="custom-control-label mr-4">Enable</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input"
                                            name="is_enabled_telegram_notification" id="disable_telegram_notification"
                                            value="0" @if (!$shop['is_enabled_telegram_notification']) checked @endif required>
                                        <label for="disable_telegram_notification"
                                            class="custom-control-label">Disable</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="telegram_channel_url" class="col-sm-4 col-form-label">Channel Link</label>
                            <div class="col-sm-8 input-wrapper">
                                <div class="input-wrapper">
                                    <input type="text" class="form-control" id="telegram_channel_url"
                                        name="telegram_channel_url" value="{{ $shop['telegram_channel_url'] }}"
                                        placeholder="Group Link">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="telegram_channel_username" class="col-sm-4 col-form-label">Channel Username</label>
                            <div class="col-sm-8 input-wrapper">
                                <div class="input-wrapper">
                                    <input type="text" class="form-control" id="telegram_channel_username"
                                        name="telegram_channel_username" value="{{ $shop['telegram_channel_username'] }}"
                                        placeholder="Channel Username">
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="telegram_bot_api_key" class="col-sm-4 col-form-label">Bot API Key</label>
                            <div class="col-sm-8 input-wrapper">
                                <div class="input-wrapper">
                                    <input type="text" class="form-control" name="telegram_bot_api_key"
                                        id="telegram_bot_api_key" value="{{ $shop['telegram_bot_api_key'] }}"
                                        placeholder="Bot API Key">
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label">Enable Send Product Link</label>
                            <div class="col-sm-8 input-wrapper mt-2">
                                <div class="d-flex">
                                    <div class="custom-control custom-radio ml-2">
                                        <input class="custom-control-input" type="radio"
                                            name="is_enable_telegram_send_product_link" id="enable_send_product_link"
                                            value="1" @if ($shop['is_enable_telegram_send_product_link'] == 1) checked @endif>
                                        <label for="enable_send_product_link"
                                            class="custom-control-label mr-4">Enable</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio"
                                            name="is_enable_telegram_send_product_link" id="disable_send_product_link"
                                            value="0" @if ($shop['is_enable_telegram_send_product_link'] == 0) checked @endif>
                                        <label for="disable_send_product_link"
                                            class="custom-control-label">Disable</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    telegram_channel_username: {
                        required: {
                            depends: function() {
                                return $('input[name=is_enabled_telegram_notification]:checked')
                                    .val() == '1'
                            }
                        }
                    },
                    telegram_bot_api_key: {
                        required: {
                            depends: function() {
                                return $('input[name=is_enabled_telegram_notification]:checked')
                                    .val() == '1'
                            }
                        }
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
        });
    </script>
@endsection
