@extends('merchant/layout/layout')

@section('page_title', 'Telegram Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4">
            @include('merchant/my_shop/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="d-flex">
                                <h4 class="mb-0 mr-2">Telegram Setting</h4>
                                <a class="mt-1" href="{{ route('merchant.shop.telegram_setting.tutorial.index') }}">
                                    View
                                    Tutorial</a>
                            </div>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-primary" href="{{ route('merchant.shop.telegram_setting.edit') }}">
                                    Edit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12 col-md-4">
                            <label>Telegram Notification</label>
                        </div>
                        <div class="col-12 col-md-8">
                            @if ($shop['is_enabled_telegram_notification'] == true)
                                <div>
                                    <span class="badge badge-primary mr-2">Enabled</span>
                                </div>
                            @elseif ($shop['is_enabled_telegram_notification'] == false)
                                <div>
                                    <span class="badge badge-secondary mr-2">Disabled</span>
                                </div>
                            @endif
                        </div>

                        <div class="col-12">
                            <hr />
                        </div>

                        <div class="col-12 col-md-4">
                            <label>Channel Link</label>
                        </div>
                        <div class="col-12 col-md-8">
                            @if ($shop['telegram_channel_url'] == null)
                                <span class="badge badge-secondary">None</span>
                            @else
                                <div>
                                    <span class="mr-2" id="telegram-group-url">{{ $shop['telegram_channel_url'] }}</span>
                                    <button class="btn btn-primary" id="btn-copy-telegram-group-url"
                                        onclick="copyTelegramChannelUrl()">Copy</button>
                                </div>
                            @endif
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>

                        <div class="col-12 col-md-4">
                            <label>Channel Username</label>
                        </div>
                        <div class="col-12 col-md-8">
                            @if ($shop['telegram_channel_username'] == null)
                                <span class="badge badge-secondary">None</span>
                            @else
                                {{ $shop['telegram_channel_username'] }}
                            @endif
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>

                        <div class="col-12 col-md-4">
                            <label>Bot API Key</label>
                        </div>
                        <div class="col-12 col-md-8">
                            @if ($shop['telegram_bot_api_key'] == null)
                                <span class="badge badge-secondary">None</span>
                            @else
                                {{ $shop['telegram_bot_api_key'] }}
                            @endif
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>

                        <div class="col-12 col-md-4">
                            <label>Enable Send Product Link</label>
                        </div>
                        <div class="col-12 col-md-8">
                            @if ($shop['is_enable_telegram_send_product_link'])
                                <span class="badge badge-primary">Enabled</span>
                            @elseif (!$shop['is_enable_telegram_send_product_link'])
                                <span class="badge badge-secondary">Disabled</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(function() {
            disableTelegramNotification = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to disable?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, disable it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }

        });

        function copyTelegramChannelUrl() {
            var telegramGroupUrl = $("#telegram-group-url").text();
            navigator.clipboard.writeText(telegramGroupUrl);

            $("#btn-copy-telegram-group-url").removeClass("btn-primary");
            $("#btn-copy-telegram-group-url").addClass("btn-success");
            $("#btn-copy-telegram-group-url").text("Copied!");
        }
    </script>
@endsection
