@extends('merchant/layout/layout')

@section('page_title', 'Subscription Dashboard')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Subscription</h1>
                    <h4 class="m-0 d-block d-sm-none">Subscription</h4>
                    <p>Get a Premium or Business subscription to unlock additional features.</p>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4 pt-md-5 mb-5">
            <div class="card shadow pb-5">
                <div class="card-body">
                    <div class="text-center">
                        <h3 class="font-weight-bold">Free</h3>
                        <p>Suitable for startup teams or individuals</p>

                        <div class="d-inline-flex align-items-center mt-3">
                            <h4 class="font-weight-bold mr-2">0 USDT</h4>
                            <h6>/month</h6>
                        </div>
                    </div>

                    <hr>

                    <div class="px-2 mt-4">
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-chevron-circle-right mr-2"></i>
                                <h6>1 x store front</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-chevron-circle-right mr-2"></i>
                                <h6>4% platform commission</h6>
                            </div>
                        </div>

                        <p class="mt-3">
                            Included:
                        </p>

                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Custom store front subdomain</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Unlimited orders and products</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Coupon</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Online payment gateway</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front rating</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Discord bot integration</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>API integration</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front blacklist</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Resell & agent feature</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-times-circle mr-2 text-danger"></i>
                                <h6>Custom resell cost price for each agent</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-times-circle mr-2 text-danger"></i>
                                <h6>Store front live chat system</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-times-circle mr-2 text-danger"></i>
                                <h6>Store front Shopping cart system</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-times-circle mr-2 text-danger"></i>
                                <h6>2 x store front premium theme</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-times-circle mr-2 text-danger"></i>
                                <h6>Feature request</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-md-4 mb-5">
            <div class="card shadow pb-5 border-primary border-5">
                <div class="card-body">
                    <div class="ribbon-wrapper ribbon-lg">
                        <div class="ribbon bg-danger text">
                            Popular
                        </div>
                    </div>
                    <div class="text-center">
                        <h3 class="font-weight-bold">Premium</h3>
                        <p>Grow your business with expand number of store front and premium feature</p>

                        <div class="d-inline-flex align-items-center mt-3">
                            <h4 class="font-weight-bold mr-2">0 USDT</h4>
                            <h6>/month</h6>
                        </div>
                    </div>

                    <hr>

                    <div class="px-2 mt-4">
                        <a class="btn btn-primary btn-lg btn-block mb-4">Get Started</a>

                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-chevron-circle-right mr-2"></i>
                                <h6><b>5</b> x store front</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-chevron-circle-right mr-2"></i>
                                <h6><b>3%</b> platform commission</h6>
                            </div>
                        </div>

                        <p class="mt-3">
                            Included:
                        </p>

                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Custom store front subdomain</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Unlimited orders and products</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Coupon</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Online payment gateway</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front rating</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Discord bot integration</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>API integration</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front blacklist</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Resell & agent feature</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Custom resell cost price for each agent</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front live chat system</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front Shopping cart system</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>2 x store front premium theme</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Feature request</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-md-4 pt-md-5">
            <div class="card shadow pb-5">
                <div class="card-body">
                    <div class="text-center">
                        <h3 class="font-weight-bold">Business</h3>
                        <p>Enjoy the lowest platform commission and scale your growing business</p>

                        <div class="d-inline-flex align-items-center mt-3">
                            <h4 class="font-weight-bold mr-2">0 USDT</h4>
                            <h6>/month</h6>
                        </div>
                    </div>

                    <hr>

                    <div class="px-2 mt-4">
                        <a class="btn btn-primary btn-lg btn-block mb-4">Get Started</a>

                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-chevron-circle-right mr-2"></i>
                                <h6><b>10</b> x store front</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-chevron-circle-right mr-2"></i>
                                <h6><b>2%</b> platform commission</h6>
                            </div>
                        </div>

                        <p class="mt-3">
                            Included:
                        </p>

                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Custom store front subdomain</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Unlimited orders and products</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Coupon</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Online payment gateway</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front rating</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Discord bot integration</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>API integration</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front blacklist</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Resell & agent feature</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Custom resell cost price for each agent</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front live chat system</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Store front Shopping cart system</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>2 x store front premium theme</h6>
                            </div>
                        </div>
                        <div class="align-items-center">
                            <div class="d-flex">
                                <i class="fas fa-check-circle mr-2 text-success"></i>
                                <h6>Feature request</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{-- free
-1 store front
-4% commission


premium
-5 store front
-3% commission


business
-10 store front
-2% commission --}}

@endsection

@section('script')
    <script>
        $(function() {

        });
    </script>
@endsection
