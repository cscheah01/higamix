<?php
use App\Enums\ProductType;
use App\Enums\StockDelimiterType;
?>

@extends('merchant/layout/layout')

@section('page_title', 'Create Product')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Create Product</h1>
                    <h4 class="m-0 d-block d-sm-none">Create Product</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.product.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('merchant.product.store') }}" method="post" enctype="multipart/form-data">
            @csrf

            <div class="card-body">
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="name">Name</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Name"
                            required>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-5 col-xl-4 d-flex d-md-block justify-content-center">
                        <div class="img-wrap rounded mt-4 border shadow">
                            <img id="product_image_preview" class="img"
                                data-initial-image="{{ asset('img/empty-image.png') }}"
                                src="{{ asset('img/empty-image.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3 col-form-label">
                        <label for="image">Image</label>
                    </div>
                    <div class="col-md-5 col-xl-4">
                        <div class="input-group input-wrapper">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="image" name="image"
                                    accept=".png,.jpeg,.jpg">
                                <label class="custom-file-label" id="product_image_label" for="image">Choose
                                    file</label>
                            </div>
                            <button type="button" class="btn btn-danger ml-2 d-none" id="remove-image-btn"
                                onclick="removeImage()">Remove</button>
                        </div>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="description">Product Description</label>
                    </div>
                    <div class="col-md-9 col-xl-9 input-wrapper">
                        <div id="description-editor" class="h-auto ql-editor-box">
                        </div>
                        <input type="hidden" name="description" id="description">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="price">Price</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <div class="input-group">
                            <div class="input-group-append">
                                <span class="input-group-text">USDT</span>
                            </div>
                            <input type="number" step="0.01" min="0.00" class="form-control" id="price"
                                name="price" placeholder="Price" required>
                        </div>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label>Allow Resell</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <div class="d-flex">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_open_resell" id="allow_resell"
                                    value="1" onchange="changeAllowResell()" required>
                                <label for="allow_resell" class="custom-control-label mr-4">Allow</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_open_resell"
                                    id="disallow_resell" value="0" onchange="changeAllowResell()" required>
                                <label for="disallow_resell" class="custom-control-label">Disallow</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div id="resell-details-wrapper" class="d-none">
                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="resell_cost_price">Resell Cost Price</label>
                        </div>
                        <div class="col-md-5 col-xl-4 input-wrapper">
                            <div class="input-group">
                                <div class="input-group-append">
                                    <span class="input-group-text">USDT</span>
                                </div>
                                <input type="number" step="0.01" min="0.00" class="form-control"
                                    id="resell_cost_price" name="resell_cost_price" placeholder="Resell Cost Price"
                                    required>
                            </div>
                        </div>
                        <div class="col-md-3 col-xl-4">

                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="suggested_min_resell_price">Suggested Min Resell Price</label>
                        </div>
                        <div class="col-md-5 col-xl-4 input-wrapper">
                            <div class="input-group">
                                <div class="input-group-append">
                                    <span class="input-group-text">USDT</span>
                                </div>
                                <input type="number" step="0.01" min="0.00" class="form-control"
                                    id="suggested_min_resell_price" name="suggested_min_resell_price"
                                    placeholder="Suggested Min Resell Price" required>
                            </div>
                        </div>
                        <div class="col-md-3 col-xl-4">

                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_category_id">Product Category</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="product_category_id" name="product_category_id"
                            style="width: 100%;" onchange="resetSubCategory()" required></select>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_sub_category_id">Product Sub Category</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="product_sub_category_id" name="product_sub_category_id"
                            style="width: 100%;"></select>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="min_purchase_qty">Minimum Purchase Quantity</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <input type="number" min="1" class="form-control" id="min_purchase_qty"
                            name="min_purchase_qty" placeholder="Minimum Purchase Quantity" required>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="max_purchase_qty">Maximum Purchase Quantity</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <input type="number" min="0" class="form-control" id="max_purchase_qty"
                            name="max_purchase_qty" placeholder="Maximum Purchase Quantity" required>
                    </div>
                    <div class="col-md-3 col-xl-4 align-items-center d-flex text-muted">
                        Set to 0 if no restriction for maximum purchase
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_available">Status</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <div class="d-flex">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_available"
                                    id="product_available" value="1" required>
                                <label for="product_available" class="custom-control-label mr-4">Available</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_available"
                                    id="product_not_available" value="0" required>
                                <label for="product_not_available" class="custom-control-label">Not Available</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xl-4">

                    </div>
                </div>

                <hr class="my-5">

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_type">Product Type</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="product_type" name="product_type"
                            onchange="changeProductType()" required>
                            <option disabled selected>Please Select Product Type</option>
                            @foreach ($productTypes as $productType)
                                <option value="{{ $productType['value'] }}">{{ $productType['description'] }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div id="serial-wrapper" class="d-none">
                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="serials_list">Serials List</label>
                        </div>
                        <div class="col-md-5 col-xl-4 input-wrapper">
                            <textarea class="form-control" name="serials" id="serials" rows="4"></textarea>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="stock_delimiter_type">Stock Delimiter</label>
                        </div>
                        <div class="col-md-5 col-xl-4 input-wrapper">
                            <select class="form-control" id="stock_delimiter_type" name="stock_delimiter_type"
                                onchange="changeStockDelimiterType()" required>
                                @foreach ($stockDelimiterTypes as $stockDelimiterType)
                                    <option value="{{ $stockDelimiterType['value'] }}"
                                        {{ $loop->index == 0 ? 'selected' : null }}>
                                        {{ $stockDelimiterType['description'] }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3 col-xl-4">
                            <div class="custom-control custom-checkbox">
                                <input class="custom-control-input" type="checkbox" id="remove_duplicate_serials"
                                    name="remove_duplicate_serials" value="1">

                                <label for="remove_duplicate_serials" class="custom-control-label">Remove duplicate
                                    serials
                                    <i class="fa-solid fa-circle-exclamation" data-toggle="tooltip" data-placement="top"
                                        title="This will remove duplicated serials on the above input."></i></label>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="custom-delimiter-wrapper" class="d-none">
                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="custom_delimiter">Custom Stock Delimiter</label>
                        </div>
                        <div class="col-md-5 col-xl-4 input-wrapper">
                            <input type="text" class="form-control" name="custom_delimiter" id="custom_delimiter"
                                required>
                        </div>
                    </div>
                </div>

                <div id="service-wrapper" class="d-none">
                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="service_description">Service Description</label>
                        </div>
                        <div class="col-md-9 col-xl-9 input-wrapper">
                            <div id="service-description-editor" class="h-auto ql-editor-box">
                            </div>
                            <input type="hidden" name="service_description" id="service_description" required>
                        </div>
                    </div>
                </div>

                <hr class="my-5">

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="description">Promotion</label>
                    </div>
                    <div class="col-md-9">
                        <button type="button" class="btn btn-primary mb-3" onclick="addPromotion()">
                            Add
                        </button>
                        <div class="promotion-input-wrapper"></div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Create
                    </button>
                </div>
            </div>
        </form>
    </div>

@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                ignore: ":hidden:not(input[type=hidden])",
                rules: {
                    suggested_min_resell_price: {
                        greaterOrEqual: '#resell_cost_price'
                    },
                    max_purchase_qty: {
                        min: function() {
                            if ($('#max_purchase_qty').val() == 0) {
                                return 0;
                            }
                            return $('#min_purchase_qty').val();
                        }
                    },
                    service_description: {
                        required: function() {

                            if ($('#product_type').val() ==
                                "{{ ProductType::Service()->key }}") {
                                return true;
                            }
                            return false;
                        }
                    }
                },
                messages: {
                    suggested_min_resell_price: {
                        greaterOrEqual: 'This field must be equal or more than resell cost price.'
                    },
                    max_purchase_qty: {
                        min: 'This field must be equal or more than minimum purchase quantity.'
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('[data-toggle="tooltip"]').tooltip();

            $("#product_category_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Category',
                ajax: {
                    url: "{{ route('merchant.product_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    },
                }
            });

            $("#product_sub_category_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Sub Category',
                ajax: {
                    url: "{{ route('merchant.product_sub_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                            product_main_category_id: $('#product_category_id').val(),
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    },
                }
            });

            $("#image").change(function() {
                const file = this.files[0];
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        $("#product_image_preview")
                            .attr("src", event.target.result);
                        $("#remove-image-btn").removeClass("d-none");
                    };
                    reader.readAsDataURL(file);
                } else {
                    var initialImage = $("#product_image_preview").data("initial-image");

                    $("#product_image_preview")
                        .attr("src", initialImage);
                    $("#remove-image-btn").addClass("d-none");
                }
            });
            var descriptionQuill = new Quill('#description-editor', {
                modules: _quillEditorModules,
                placeholder: 'Write product description...',
                theme: 'snow',
            });
            descriptionQuill.root.innerHTML = $("#description").val();
            descriptionQuill.on('text-change', function(delta, oldDelta, source) {
                $("#description").val(descriptionQuill.root.innerHTML);
            });

            var serviceDescriptionQuill = new Quill('#service-description-editor', {
                modules: _quillEditorModules,
                placeholder: 'Write service description...',
                theme: 'snow',
            });
            serviceDescriptionQuill.root.innerHTML = $("#service_description").val();
            serviceDescriptionQuill.on('text-change', function(delta, oldDelta, source) {
                $("#service_description").val(serviceDescriptionQuill.root.innerHTML);
            });
        });

        function changeProductType() {
            var productType = $('#product_type').val();

            $('#serial-wrapper').addClass('d-none');
            $('#service-wrapper').addClass('d-none');
            $('#custom-delimiter-wrapper').addClass('d-none');

            if (productType == "{{ ProductType::SerialKey()->key }}") {
                $('#serial-wrapper').removeClass('d-none');
            } else if (productType == "{{ ProductType::Service()->key }}") {
                $('#service-wrapper').removeClass('d-none');
            }
        }

        function changeStockDelimiterType() {
            var stockDelimiterType = $('#stock_delimiter_type').val();

            $('#custom-delimiter-wrapper').addClass('d-none');

            if (stockDelimiterType == "{{ StockDelimiterType::Custom }}") {
                $('#custom-delimiter-wrapper').removeClass('d-none');
            }
        }

        function resetSubCategory() {
            $("#product_sub_category_id").empty();
        }

        function removeImage() {
            $("#image").val('');
            $("#product_image_label").text("Choose file");

            var initialImage = $("#product_image_preview").data("initial-image");

            $("#product_image_preview")
                .attr("src", initialImage);
            $("#remove-image-btn").addClass("d-none");
        }

        function changeAllowResell() {
            var isAllowResell = $("input[name='is_open_resell']:checked").val();

            $("#resell-details-wrapper").addClass("d-none");

            if (isAllowResell == true) {
                $("#resell-details-wrapper").removeClass("d-none");
            }
        }

        function addPromotion() {
            var nextNumber = $('.promotion-row').length;

            $('.promotion-input-wrapper').append(
                `
                <div class="row mb-3 promotion-row">
                    <div class="col-6 col-md-4">
                        <div class="form-group m-0 input-wrapper">
                            <label for="product_discount[${nextNumber}
            ][min_qty]" >Min Quantity</label>
                            <input type="number" min="1" class="form-control promotion-min-qty-input" name="product_discount[${nextNumber}][min_qty]" id="product_discount[${nextNumber}][min_qty]" placeholder="Min Quantity" required>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="form-group m-0 input-wrapper">
                            <label for="product_discount[${nextNumber}][discounted_price]" >Price / pcs (USDT)</label>
                            <input type="number" step="0.01" min="0.00" class="form-control promotion-discount-price-input" name="product_discount[${nextNumber}][discounted_price]" id="product_discount[${nextNumber}][discounted_price]" placeholder="Discounted Price" required>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 mt-3 mt-md-0 d-flex align-items-end">
                        <button type="button" class="btn btn-danger btn-remove-promotion">
                            Remove
                        </button>
                    </div>
                </div>`);
        }

        $(document).on('click', '.btn-remove-promotion', function() {
            $(this).closest('.promotion-row').remove();
            reAssignPromotionInputName();
        });

        function reAssignPromotionInputName() {
            var promotionMinQuantityCount = 1;
            var promotionDiscountPriceCount = 1;
            $('.promotion-min-qty-input').each(function() {
                $(this).attr(`'name', 'product_discount['${ promotionMinQuantityCount }'][min_qty]'`);
                promotionMinQuantityCount++;
            })
            $('.promotion-discount-price-input').each(function() {
                $(this).attr(`'name', 'product_discount[' ${promotionDiscountPriceCount}'][discounted_price]'`);
                promotionDiscountPriceCount++;
            })
        }
    </script>
@endsection
