@php
use App\Enums\ProductType;
@endphp


@extends('merchant/layout/layout')

@section('page_title', 'Product')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product</h1>
                    <h4 class="m-0 d-block d-sm-none">Product</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-success" href="{{ route('merchant.product.create') }}">
                            Create Product
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-name">Product Name</label>
                            <input type="search" id="filter-product-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-type">Product Type</label>
                            <select id="filter-product-type" class="form-control">
                                <option disabled selected>Please Select Product Type</option>
                                @foreach ($productTypes as $productType)
                                    <option value="{{ $productType['value'] }}">{{ $productType['description'] }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-category">Category</label>
                            <select class="form-control" id="filter-product-category" style="width: 100%;"
                                onchange="resetSubCategory()"></select>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-sub-category">Sub Category</label>
                            <select class="form-control" id="filter-product-sub-category" style="width: 100%;"></select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="clearForm();">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Product Type</th>
                        <th class="d-none"></th>
                        <th class="d-none"></th>
                        <th>Price (USDT)</th>
                        <th>Stock Qty</th>
                        <th>Status</th>
                        <th>Allow Resell</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.product.datatable', ['id' => $shopId]) }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "product_type",
                        name: "product_type",
                        orderable: false
                    },
                    {
                        data: "product_category_id",
                        name: "product_categories.id",
                        visible: false,
                    },
                    {
                        data: "product_sub_category_id",
                        name: "product_sub_categories.id",
                        visible: false,
                    },
                    {
                        className: "dt-body-right",
                        data: "price",
                        name: "price"
                    },
                    {
                        data: "stock_qty",
                        name: "stock_qty",
                        className: "text-center",
                        width: "80px",
                        render: function(data, type, row) {
                            if (row.product_type_key == '{{ ProductType::Service()->key }}') {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                    {
                        data: "is_available",
                        width: "50px",
                        name: "is_available",
                        className: "text-center",
                        render: function(data, type, row) {
                            if (data == true) {
                                return '<span class="badge badge-primary">Available</span>';
                            } else {
                                return '<span class="badge badge-danger">Not Available</span>';
                            }
                        }
                    },
                    {
                        data: "is_open_resell",
                        width: "100px",
                        name: "is_open_resell",
                        className: "text-center",
                        render: function(data, type, row) {
                            if (data == true) {
                                return '<span class="badge badge-primary">Allow</span>';
                            } else {
                                return '<span class="badge badge-danger">Disallow</span>';
                            }
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                        <div class="d-flex">
                             ${ createdAt}
                        </div>`;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.product.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var editUrl =
                                `{{ route('merchant.product.edit', ['id' => ':id']) }}`;
                            editUrl = editUrl.replace(':id', data.id);

                            var deleteUrl =
                                `{{ route('merchant.product.destroy', ['id' => ':id']) }}`;
                            deleteUrl = deleteUrl.replace(':id', data.id);


                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${ viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <a class="btn btn-primary mr-1" href="${ editUrl}">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <form method="post" action="${ deleteUrl}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteProduct(event)">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [8, "desc"]
                ],
            });

            deleteProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#filter-product-category").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Category',
                ajax: {
                    url: "{{ route('merchant.product_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    },
                }
            });

            $("#filter-product-sub-category").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Sub Category',
                ajax: {
                    url: "{{ route('merchant.product_sub_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            product_main_category_id: $('#filter-product-category').val(),
                            page: params.page,

                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    },
                }
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    productName: $("#filter-product-name").val(),
                    productType: $("#filter-product-type").val() ?? '',
                    productCategory: $("#filter-product-category").val() ?? '',
                    productSubCategory: $("#filter-product-sub-category").val() ?? '',
                };

                $table.column(0).search(filters.productName);
                $table.column(1).search(filters.productType);
                $table.column(2).search(filters.productCategory);
                $table.column(3).search(filters.productSubCategory);
                $table.draw();
            });
        });

        function resetSubCategory() {
            $("#product_sub_category_id").empty();
        }

        function clearForm() {
            resetForm('#filter-form');
            $("#filter-product-category").empty();
            $("#product_sub_category_id").empty();
        }
    </script>
@endsection
