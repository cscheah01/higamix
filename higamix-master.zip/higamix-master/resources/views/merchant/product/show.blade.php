@php
use App\Enums\ProductType;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'Product Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            @if ($product->shop->user_id == Auth::id())
                                <a class="btn btn-dark mr-1" href="{{ route('merchant.product.index') }}">
                                    Back
                                </a>
                                <form method="post" action={{ route('merchant.product.destroy', ['id' => $product->id]) }}
                                    class="mr-1">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteProduct(event)">
                                        Delete
                                    </button>
                                </form>
                                <a class="btn btn-primary"
                                    href="{{ route('merchant.product.edit', ['id' => $product->id]) }}">
                                    Edit
                                </a>
                            @else
                                <a class="btn btn-dark mr-1" href="{{ route('merchant.shop.search_shop.index') }}">
                                    Back
                                </a>
                                <button type="button" class="btn btn-primary mr-1" data-toggle="modal"
                                    data-target="#purchase-product-modal" onclick="openPurchaseProductModal()"
                                    @if ($product->is_available == false) disabled @endif>
                                    Purchase
                                </button>
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#resell-product-modal"
                                    @if ($product->is_available == false) disabled @elseif ($product->is_open_resell == false) disabled @endif>
                                    Resell Product
                                </button>
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">General Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="img-wrap rounded mx-auto mb-4 border shadow">
                        <img class="img"
                            src="{{ $product['image'] != null ? url('storage/product_image/' . $product['image']) : asset('img/empty-image.png') }}"
                            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Title:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->name }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->productCategory->name ?? 'Uncategorized' }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Sub Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->productSubCategory->name ?? '-' }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>

                @if ($product->product_type == ProductType::SerialKey()->key)
                    <div class="col-12 col-md-3">
                        <label>Remaining Stock Qty:</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div>
                            {{ $product->stock_qty ?? '-' }}
                        </div>
                    </div>
                    <div class="col-12">
                        <hr />
                    </div>
                @endif

                <div class="col-12 col-md-3">
                    <label>Status:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->is_available == true)
                            <span class="badge badge-primary">Available</span>
                        @else
                            <span class="badge badge-danger">Not Available</span>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Description:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div class="ql-container ql-snow" style="min-height:150px;">
                        <div class="ql-editor">{!! $product->description !!}</div>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Type:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ ProductType::fromKey($product->product_type)->description }}
                    </div>
                </div>
                @if ($product->product_type == ProductType::Service()->key)
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Service Description:</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div class="ql-container ql-snow" style="min-height:150px;">
                            <div class="ql-editor">{!! $product->service_description !!}</div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Price & Purchase Quantity</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Product Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->price }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Minimum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->min_purchase_qty }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Maximum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->max_purchase_qty == 0 ? '-' : $product->max_purchase_qty }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Resell Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Allow Resell:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->is_open_resell == true)
                            <span class="badge badge-primary">Allow</span>
                        @else
                            <span class="badge badge-danger">Disallow</span>
                        @endif
                    </div>
                </div>

                @if ($product->is_open_resell == true)
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Resell Cost Price (USDT):</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div>
                            {{ $product->resell_cost_price }}
                        </div>
                    </div>
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Suggested Min Resell Price (USDT):</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div>
                            {{ $product->suggested_min_resell_price }}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Promotion</h4>
        </div>
        <div class="card-body">
            @if ($productDiscounts->isEmpty())
                <div class="alert alert-secondary">
                    This product was no promotion.
                </div>
            @else
                @foreach ($productDiscounts as $productDiscount)
                    <div class="row mb-4">
                        <div class="col-6 col-sm-auto">
                            <label>Min Quantity: </label>
                            <div>
                                {{ $productDiscount->min_qty }}
                            </div>
                        </div>
                        <div class="col-6 col-sm-auto">
                            <label>Price / pcs (USDT): </label>
                            <div>
                                {{ $productDiscount->discounted_price }}
                            </div>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-auto col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Product Log</h4>
                </div>
                <div class="col-auto col-sm-4 col-lg-3 text-right">
                    @if ($product->shop->user_id == Auth::id())
                        <button type="button" class="btn btn-primary" data-toggle="modal"
                            data-target="#add-product-log-modal">
                            Add Product Log
                        </button>
                    @endif
                </div>
            </div>
        </div>

        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Created At</th>
                        <th>Log Content</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>


    <div class="modal fade" id="add-product-log-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Product Log</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="form"
                        action="{{ route('merchant.product.log.store', ['productId' => $product->id]) }}">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-12 input-wrapper">
                                <textarea class="form-control" id="content" name="content" placeholder="Content" rows="7" required></textarea>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="form" class="btn btn-success" onclick="addProductLog(event)">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="purchase-product-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Purchase Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="purchase-form"
                        action="{{ route('merchant.purchase_product.purchase', ['productId' => $product->id]) }}">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Product name</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span>{{ $product->name }}</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Minimum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="display-min-qty"></span>
                                <input type="hidden" id="min_qty">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Maximum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="max-qty"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Price / pcs</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <div class="input-group align-items-center">
                                    <span id="reseller-price-badge" class="badge badge-primary d-none">Reseller
                                        Price</span>
                                    <del id="strike-original-price" class="d-none"><span class="mr-1">USDT</span><span
                                            id="display-original-unit-price"></span></del>
                                    <span class="ml-1 mr-1">USDT</span><span id="display-unit-price"></span>
                                </div>
                                <input type="hidden" id="price" name="unit_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="quantity">Product Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <input type="number" class="form-control input-price " id="quantity" name="qty"
                                    placeholder="Product Quantity" onchange="checkPromotion()" required>
                            </div>
                        </div>

                        <hr>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Total (USDT)</label>
                            </div>
                            <div class="col-md-8 col-xl-6">
                                <span id="total">

                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="purchase-form" class="btn btn-success"
                        onclick="purchaseProduct(event)">
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="resell-product-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Resell Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="resell-form"
                        action="{{ route('merchant.resell_product.store', ['id' => $product->id]) }}">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="name">Product name</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Product Name" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label>Resell Cost Price (USDT)</label>
                            </div>
                            <div class="col-md-9 col-xl-7">
                                {{ $product->resell_cost_price }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label>Suggested Min Resell Price (USDT)</label>
                            </div>
                            <div class="col-md-9 col-xl-7">
                                {{ $product->suggested_min_resell_price }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="price">Price</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <div class="input-group">
                                    <div class="input-group-append">
                                        <span class="input-group-text">USDT</span>
                                    </div>
                                    <input type="number" value="{{ $product->suggested_min_resell_price }}"
                                        step="0.01" class="form-control input-price" id="resell_price" name="price"
                                        placeholder="Resell Price" onchange="checkSuggestedPrice()" required>
                                    <input type="hidden" id="suggested-price"
                                        value="{{ $product->suggested_min_resell_price }}">
                                </div>
                                <div class="alert alert-warning d-none mt-2" id="suggested-price-alert" role="alert">
                                    The suggested minimum resell price is USDT <span
                                        id="display-alert-suggested-price"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="product_category_id">Product Category</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="product_category_id" name="product_category_id"
                                    style="width: 100%;" onchange="resetSubcategory()" required></select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="product_sub_category_id">Product Sub Category</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="product_sub_category_id" name="product_sub_category_id"
                                    style="width: 100%;"></select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="discord_bot_id">Discord Bot</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="discord_bot_id" name="discord_bot_id"
                                    style="width: 100%;"></select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="resell-form" class="btn btn-success" onclick="resellProduct()">
                        Resell
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.product.log.datatable', ['productId' => $product->id]) }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    },
                },
                columns: [{
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `${createdAt}`;
                        }
                    },
                    {
                        className: "double-line-ellipsis",
                        data: "content",
                        name: "content",
                        orderable: false
                    },
                ],
                order: [
                    [0, "desc"]
                ],
            });

            $('#table thead th').removeClass('double-line-ellipsis');

            addProductLog = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Add product log will notify resell via discord and telegram group. Are you sure?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Confirm'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#form').submit();
                    }
                })
            };

            deleteProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };


            $('#purchase-form').validate({
                rules: {
                    quantity: {
                        greaterOrEqual: '#min_qty'
                    },
                },
                messages: {
                    quantity: {
                        greaterOrEqual: 'This field must be equal or more than minimum purchase quantity.'
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#resell-form').validate({
                rules: {
                    price: {
                        min: function() {
                            if ({{ $product->is_open_resell }} == true) {
                                return {{ $product->resell_cost_price }};
                            }
                            return 0;
                        }
                    },
                },
                messages: {
                    price: {
                        min: 'This field must be equal or more than resell cost price.',
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            resellProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to resell this product?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#product_category_id").select2({
                dropdownParent: $('#resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Category',
                ajax: {
                    url: "{{ route('merchant.product_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#product_sub_category_id").select2({
                dropdownParent: $('#resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Sub Category',
                ajax: {
                    url: "{{ route('merchant.product_sub_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            product_main_category_id: $('#product_category_id').val(),
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#discord_bot_id").select2({
                dropdownParent: $('#resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Discord Bot',
                ajax: {
                    url: "{{ route('merchant.discord_bot.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.username,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            purchaseProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to purchase this product?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#purchase-form').submit();
                    }
                })
            };
        })
        var isReseller = null;

        function openPurchaseProductModal() {
            isReseller = false;
            $('#price').attr('value', {{ $product->price }});
            $('#price').data('original-price', {{ $product->price }}.toFixed(2));
            $('#quantity').attr('value', {{ $product->min_purchase_qty }});
            $('#quantity').attr('min', 1);
            $('#display-min-qty').html({{ $product->min_purchase_qty }});
            $('#min_qty').attr('value', {{ $product->min_purchase_qty }});
            $('#max-qty').html('{{ $product->max_purchase_qty == 0 ? '-' : $product->max_purchase_qty }}');
            $('#reseller-price-badge').addClass('d-none');
            checkPromotion();

            var checkShopAgentUrl =
                `{{ route('merchant.resell_product.get', ['id' => ':id']) }}`
            checkShopAgentUrl = checkShopAgentUrl.replace(':id', {{ $product->id }});

            $.ajax({
                type: 'GET',
                url: checkShopAgentUrl,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    if (data) {
                        isReseller = true;
                        var resellCostPrice = {{ $product->resell_cost_price ?? 0 }};
                        $('#price').attr('value', resellCostPrice.toFixed(2));
                        $('#price').data('original-price', resellCostPrice.toFixed(2));
                        $('#reseller-price-badge').removeClass('d-none');
                        checkPromotion();
                    }
                }
            });
        }

        function checkPromotion() {
            var originalPrice = $('#price').data('original-price');
            var promoPrice = 0;
            var purchaseQuantity = $('#quantity').val();

            var productDiscounts = @json($productDiscounts);

            productDiscounts.forEach((discount) => {
                if (purchaseQuantity >= discount.min_qty) {
                    promoPrice = discount.discounted_price;
                }
            })
            var total = originalPrice * purchaseQuantity;
            var promoTotal = promoPrice * purchaseQuantity;

            $('#display-unit-price').html(originalPrice);
            $('#price').val(originalPrice);
            $('#total').html(total.toFixed(2));
            $('#strike-original-price').addClass('d-none');
            if (isReseller) {
                $('#reseller-price-badge').removeClass('d-none');
            }

            if (promoTotal != 0) {
                if (total > promoTotal) {
                    $('#strike-original-price').removeClass('d-none');
                    $('#reseller-price-badge').addClass('d-none');
                    $('#display-original-unit-price').html(originalPrice);
                    $('#total').html(promoTotal.toFixed(2));
                    $('#display-unit-price').html(promoPrice);
                    $('#price').val(promoPrice);
                }
            }
        }

        function resetSubcategory() {
            $("#product_sub_category_id").empty();
        }

        function checkSuggestedPrice() {
            var price = $('#resell_price').val();
            var suggestedPrice = $('#suggested-price').val();
            $('#display-alert-suggested-price').html(suggestedPrice);

            if (parseFloat(price).toFixed(2) >= suggestedPrice) {
                $('#suggested-price-alert').addClass('d-none');
            } else {
                $('#suggested-price-alert').removeClass('d-none');
            }
        }
    </script>
@endsection
