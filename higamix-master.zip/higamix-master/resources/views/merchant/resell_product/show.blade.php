@php
use App\Enums\ProductType;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'Product Resell Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Resell Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Resell Details</h4>
                </div>
                <div class="col-sm-5 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('merchant.resell_product.index') }}">
                                Back
                            </a>
                            <a class="btn btn-primary mr-1"
                                href="{{ route('merchant.resellable_product.show', ['id' => $product->parent_product_id]) }}">
                                View Parent Product
                            </a>
                            <button type="button" class="btn btn-primary mr-1" data-toggle="modal"
                                data-target="#purchase-product-modal" onclick="openPurchaseProductModal()">
                                Purchase
                            </button>
                            <form method="post"
                                action={{ route('merchant.resell_product.destroy', ['id' => $product->id]) }}
                                class="mr-1">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="deleteProduct(event)">
                                    Delete
                                </button>
                            </form>
                            <a class="btn btn-primary"
                                href="{{ route('merchant.resell_product.edit', ['id' => $product->id]) }}">
                                Edit
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">Resell Setting</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Product Name:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->name }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Resell Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->price }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Resell Profit (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->resell_profit }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->productCategory->name ?? 'Uncategorized' }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Sub Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->productSubCategory->name ?? '-' }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Discord Bot Username:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->discordBot->username ?? '-' }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">General Details</h4>
        </div>
        <div class="card-body">
            <div class="row">

                @if ($product->parentProduct->product_type == ProductType::SerialKey()->key)
                    <div class="col-12 col-md-3">
                        <label>Remaining Stock Qty:</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div>
                            {{ $product->stock_qty ?? '-' }}
                        </div>
                    </div>
                    <div class="col-12">
                        <hr />
                    </div>
                @endif

                <div class="col-12 col-md-3">
                    <label>Product Description:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div class="ql-container ql-snow" style="min-height:150px;">
                        <div class="ql-editor">{!! $product->parentProduct->description !!}</div>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Type:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ ProductType::fromKey($product->parentProduct->product_type)->description }}
                    </div>
                </div>

                @if ($product->parentProduct->product_type == ProductType::Service()->key)
                    <div class="col-12">
                        <hr />
                    </div>

                    <div class="col-12 col-md-3">
                        <label>Service Description:</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div class="ql-container ql-snow" style="min-height:150px;">
                            <div class="ql-editor">{!! $product->parentProduct->service_description !!}</div>
                        </div>
                    </div>
                @endif

                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Resell Cost Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parentProduct->resell_cost_price }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Suggested Min Resell Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parentProduct->suggested_min_resell_price }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Price & Purchase Quantity</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Product Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parentProduct->price }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Minimum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parentProduct->min_purchase_qty }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Maximum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parentProduct->max_purchase_qty == 0 ? '-' : $product->parentProduct->max_purchase_qty }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Promotion</h4>
        </div>
        <div class="card-body">
            @if ($productDiscounts->isEmpty())
                <div class="alert alert-secondary">
                    This product was no promotion.
                </div>
            @else
                @foreach ($productDiscounts as $productDiscount)
                    <div class="row mb-4">
                        <div class="col-6 col-sm-auto">
                            <label>Min Quantity: </label>
                            <div>
                                {{ $productDiscount->min_qty }}
                            </div>
                        </div>
                        <div class="col-6 col-sm-auto">
                            <label>Price / pcs (USDT): </label>
                            <div>
                                {{ $productDiscount->discounted_price }}
                            </div>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>

    <div class="modal fade" id="purchase-product-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Purchase Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="purchase-form"
                        action="{{ route('merchant.purchase_product.purchase', ['productId' => $product->parentProduct->id]) }}">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Product name</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span>{{ $product->parentProduct->name }}</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Minimum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="display-min-qty"></span>
                                <input type="hidden" id="min_qty">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Maximum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="max-qty"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Price / pcs</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <div class="input-group align-items-center">
                                    <span id="reseller-price-badge" class="badge badge-primary">Reseller Price</span>
                                    <del id="strike-original-price" class="d-none"><span class="mr-1">USDT</span><span
                                            id="display-original-unit-price"></span></del>

                                    <span class="ml-1 mr-1">USDT</span><span id="display-unit-price"></span>
                                </div>
                                <input type="hidden" id=price name="unit_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="quantity">Product Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <input type="number" class="form-control input-price" min="1" id="quantity"
                                    name="qty" placeholder="Product Quantity" onkeyup="checkPromotion()"
                                    onchange="checkPromotion()" required>
                            </div>
                        </div>

                        <hr class="mt-5">

                        <div class="form-group row font-weight-bold">
                            <div class="col-12 col-md-6 text-right">
                                <label>Total (USDT)</label>
                            </div>
                            <div class="col-12 col-md-6 text-right">
                                <span id="total">

                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="purchase-form" class="btn btn-success"
                        onclick="purchaseProduct(event)">
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            deleteProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $('#purchase-form').validate({
                rules: {
                    quantity: {
                        greaterOrEqual: '#min_qty'
                    },
                },
                messages: {
                    quantity: {
                        greaterOrEqual: 'This field must be equal or more than minimum purchase quantity.'
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            purchaseProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to purchase this product?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#purchase-form').submit();
                    }
                })
            };
        });

        function openPurchaseProductModal() {
            $('#price').attr('value', {{ $product->parentProduct->resell_cost_price }});
            $('#price').data('original-price', {{ $product->parentProduct->resell_cost_price }}.toFixed(2));
            $('#quantity').attr('value', {{ $product->parentProduct->min_purchase_qty }});
            $('#quantity').attr('min', 1);
            $('#display-min-qty').html({{ $product->parentProduct->min_purchase_qty }});
            $('#min_qty').attr('value', {{ $product->parentProduct->min_purchase_qty }});
            $('#max-qty').html(
                '{{ $product->parentProduct->max_purchase_qty == 0 ? '-' : $product->parentProduct->max_purchase_qty }}'
            );
            checkPromotion();
        }

        function checkPromotion() {
            var originalPrice = $('#price').data('original-price');
            var promoPrice = 0;
            var purchaseQuantity = $('#quantity').val();

            var productDiscounts = @json($productDiscounts);

            productDiscounts.forEach((discount) => {
                if (purchaseQuantity >= discount.min_qty) {
                    promoPrice = discount.discounted_price;
                }
            })
            var total = originalPrice * purchaseQuantity;
            var promoTotal = promoPrice * purchaseQuantity;

            $('#display-unit-price').html(originalPrice);
            $('#price').val(originalPrice);
            $('#total').html(total.toFixed(2));
            $('#strike-original-price').addClass('d-none');
            $('#reseller-price-badge').removeClass('d-none');

            if (promoTotal != 0) {
                if (total > promoTotal) {
                    $('#strike-original-price').removeClass('d-none');
                    $('#reseller-price-badge').addClass('d-none');
                    $('#display-original-unit-price').html(originalPrice);
                    $('#total').html(promoTotal.toFixed(2));
                    $('#display-unit-price').html(promoPrice);
                    $('#price').val(promoPrice);
                }
            }
        }
    </script>
@endsection
