@php
use App\Enums\ProductType;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'My Resell Product')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">My Resell Product</h1>
                    <h4 class="m-0 d-block d-sm-none">My Resell Product</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-name">Product Name</label>
                            <input type="search" id="filter-name" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Shop Name</th>
                        <th>Parent Product Name</th>
                        <th>Product Name</th>
                        <th>Resell Cost Price (USDT)</th>
                        <th>Price (USDT)</th>
                        <th>Stock Qty</th>
                        <th>Approval Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="purchase-product-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Purchase Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="purchase-form">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Product name</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="name"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Minimum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="display-min-qty"></span>
                                <input type="hidden" id="min_qty">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Maximum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="max-qty"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Price / pcs</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <div class="input-group align-items-center">
                                    <span id="reseller-price-badge" class="badge badge-primary">Reseller Price</span>
                                    <del id="strike-original-price" class="d-none"><span class="mr-1">USDT</span><span
                                            id="display-original-unit-price"></span></del>

                                    <span class="ml-1 mr-1">USDT</span><span id="display-unit-price"></span>
                                </div>
                                <input type="hidden" id=price name="unit_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="quantity">Product Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <input type="number" class="form-control input-price" min="1" id="quantity"
                                    name="qty" placeholder="Product Quantity" onkeyup="checkPromotion()"
                                    onchange="checkPromotion()" required>
                            </div>
                        </div>

                        <hr class="mt-5">

                        <div class="form-group row font-weight-bold">
                            <div class="col-12 col-md-6 text-right">
                                <label>Total (USDT)</label>
                            </div>
                            <div class="col-12 col-md-6 text-right">
                                <span id="total">

                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="purchase-form" class="btn btn-success" onclick="purchaseProduct(event)">
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#purchase-form').validate({
                rules: {
                    quantity: {
                        greaterOrEqual: '#min_qty'
                    },
                },
                messages: {
                    quantity: {
                        greaterOrEqual: 'This field must be equal or more than minimum purchase quantity.'
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#table').DataTable({
                aasorting: [],
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.resell_product.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: null,
                        name: "shop_name",
                        orderable: false,
                        render: function(data, type, row) {
                            var url =
                                `{{ route('merchant.shop.search_shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        data: "parent_product_name",
                        name: "parent_product.name",
                        orderable: false,
                    },
                    {
                        data: "name",
                        name: "name",
                        orderable: false,
                    },
                    {
                        className: "dt-body-right",
                        data: "resell_cost_price",
                        name: "resell_cost_price",
                        orderable: false,
                    },
                    {
                        className: "dt-body-right",
                        data: "price",
                        name: "price",
                        orderable: false,
                    },
                    {
                        data: "stock_qty",
                        name: "stock_qty",
                        className: "text-center",
                        width: "80px",
                        render: function(data, type, row) {
                            if (row.product_type_key == '{{ ProductType::Service()->key }}') {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                    {
                        data: null,
                        orderable: false,
                        width: "130px",
                        searchable: false,
                        name: "is_waiting_approved",
                        className: "text-center",
                        render: function(data, type, row) {
                            if (data.is_waiting_approved == true && data.is_approved == false) {
                                var status =
                                    '<span class="badge badge-warning">Pending Approval</span>';
                            } else if (data.is_waiting_approved == false && data.is_approved ==
                                true) {
                                var status = '<span class="badge badge-success">Approved</span>';
                            }
                            return `
                            <div>
                               ${status}
                            </div>
                            `
                        }
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.resell_product.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var editUrl =
                                `{{ route('merchant.resell_product.edit', ['id' => ':id']) }}`;
                            editUrl = editUrl.replace(':id', data.id);

                            var deleteUrl =
                                `{{ route('merchant.resell_product.destroy', ['id' => ':id']) }}`;
                            deleteUrl = deleteUrl.replace(':id', data.id);

                            var purchaseUrl =
                                `{{ route('merchant.purchase_product.purchase', ['productId' => ':productId']) }}`;
                            purchaseUrl = purchaseUrl.replace(':productId', data.parent_product_id);

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <a class="btn btn-primary mr-1" href="${editUrl}">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <button type="button" class="btn btn-primary mr-1" onclick="openPurchaseProductModal('${purchaseUrl}','${
                                data.parent_product_name}','${data.resell_cost_price}','${data.parent_product_id}','${data.parent_product_min_purchase_qty}','${data.parent_product_max_purchase_qty}')">
                                    Purchase
                                </button>

                                <form method="post" action="${deleteUrl}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteProduct(event)">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },

                ],
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    name: $("#filter-name").val(),
                };
                if (filters.name == "") {
                    $table.column(2).search('^$', true, false);
                } else {
                    $table.column(2).search(filters.name);
                }

                $table.draw();
            });

            deleteProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            purchaseProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Confirm to purchase?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#purchase-form').submit();
                    }
                })
            };
        });

        function resetFilterInput() {
            $("#filter-input").val(null);
        }

        var currentProductDiscounts = null;

        function openPurchaseProductModal(purchaseUrl, productName, price, productId, minPurchaseQuantity,
            maxPurchaseQuantity) {
            $('#purchase-form .form-control').each(function() {
                $(this).removeClass("is-invalid");
            })
            $('#purchase-form').validate().resetForm();

            var getPromotionUrl = `{{ route('merchant.product.discount.show', ['productId' => ':productId']) }}`
            getPromotionUrl = getPromotionUrl.replace(':productId', productId);

            $.ajax({
                type: 'GET',
                url: getPromotionUrl,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    currentProductDiscounts = data;
                    $('#purchase-product-modal').modal('show');
                    $('#price').attr('value', price);
                    $('#price').data('original-price', price);
                    $('#name').html(productName);
                    $('#purchase-form').attr('action', purchaseUrl);
                    $('#quantity').val(minPurchaseQuantity);
                    $('#display-min-qty').html(minPurchaseQuantity);
                    $('#min_qty').attr('value', minPurchaseQuantity);
                    $('#max-qty').html(maxPurchaseQuantity == 0 ? '-' : maxPurchaseQuantity);
                    checkPromotion();
                }
            });
        }

        function checkPromotion() {
            var originalPrice = $('#price').data('original-price');
            var promoPrice = 0;
            var purchaseQuantity = $('#quantity').val();

            currentProductDiscounts.forEach((discount) => {
                if (purchaseQuantity >= discount.min_qty) {
                    promoPrice = discount.discounted_price;
                }
            })
            var total = originalPrice * purchaseQuantity;
            var promoTotal = promoPrice * purchaseQuantity;

            $('#display-unit-price').html(originalPrice);
            $('#price').val(originalPrice);
            $('#total').html(total.toFixed(2));
            $('#strike-original-price').addClass('d-none');
            $('#reseller-price-badge').removeClass('d-none');

            if (promoTotal != 0) {
                if (total > promoTotal) {
                    $('#strike-original-price').removeClass('d-none');
                    $('#reseller-price-badge').addClass('d-none');
                    $('#display-original-unit-price').html(originalPrice);
                    $('#total').html(promoTotal.toFixed(2));
                    $('#display-unit-price').html(promoPrice);
                    $('#price').val(promoPrice);
                }
            }
        }
    </script>
@endsection
