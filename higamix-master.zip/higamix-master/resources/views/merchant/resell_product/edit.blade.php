@extends('merchant/layout/layout')

@section('page_title', 'Edit Resell Product Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Edit Resell Product Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Edit Resell Product Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.resell_product.show', ['id' => $product->id]) }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('merchant.resell_product.update', ['id' => $product->id]) }}" method="post">
            @csrf

            @method('PATCH')

            <div class="card-body">
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="name">Product Name</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Product Name"
                            value="{{ $product->name }}" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label>Resell Cost Price (USDT)</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <div class="input-group">
                            <span class="ml-1">{{ $product->parentProduct->resell_cost_price }}</span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label>Suggested Min Resell Price (USDT)</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <div class="input-group">
                            <span class="ml-1">{{ $product->parentProduct->suggested_min_resell_price }}</span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="price">Price</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <div class="input-group">
                            <div class="input-group-append">
                                <span class="input-group-text">USDT</span>
                            </div>
                            <input type="number" value="{{ $product->price }}" step="0.01"
                                class="form-control input-price" id="price" name="price" placeholder="Resell Price"
                                onchange="checkSuggestedPrice()" required>
                        </div>

                        <div class="alert alert-warning d-none mt-2" id="suggested-price-alert" role="alert">
                            The suggested minimum resell price is USDT <span id="display-alert-suggested-price"></span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_category_id">Product Category</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="product_category_id" name="product_category_id"
                            style="width: 100%;" onchange="resetSubcategory()" required>
                            @if ($product->product_category_id != null)
                                <option value="{{ $product->product_category_id }}">
                                    {{ $product->productCategory->name }}</option>
                            @endif
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_sub_category_id">Product Sub Category</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="product_sub_category_id" name="product_sub_category_id"
                            style="width: 100%;">
                            <option
                                value="@if ($product->product_sub_category_id != null) {{ $product->product_sub_category_id }} @endif">
                                @if ($product->product_sub_category_id != null)
                                    {{ $product->productSubCategory->name }}
                                @endif
                            </option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="discord_bot_id">Discord Bot</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="discord_bot_id" name="discord_bot_id" style="width: 100%;">
                            <option value="@if ($product->discord_bot_id != null) {{ $product->discord_bot_id }} @endif">
                                @if ($product->discord_bot_id != null)
                                    {{ $product->discordBot->username }}
                                @endif
                            </option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Save Edit
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    price: {
                        min: {{ $product->parentProduct->resell_cost_price }},
                    },
                },
                messages: {
                    price: {
                        min: 'This field must be equal or more than resell cost price.',
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $("#product_category_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Category',
                ajax: {
                    url: "{{ route('merchant.product_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#product_sub_category_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Sub Category',
                ajax: {
                    url: "{{ route('merchant.product_sub_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            product_main_category_id: $('#product_category_id').val(),
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#discord_bot_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Discord Bot',
                ajax: {
                    url: "{{ route('merchant.discord_bot.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.username,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $('#price').change(function() {
                this.value = parseFloat(this.value).toFixed(2);
            });
        });

        function resetSubcategory() {
            $("#product_sub_category_id").empty();
        }

        function checkSuggestedPrice() {
            var price = $('#price').val();
            var suggestedPrice = {{ $product->parentProduct->suggested_min_resell_price }};
            $('#display-alert-suggested-price').html(suggestedPrice.toFixed(2));

            if (parseFloat(price).toFixed(2) >= suggestedPrice) {
                $('#suggested-price-alert').addClass('d-none');
            } else {
                $('#suggested-price-alert').removeClass('d-none');
            }
        }
    </script>
@endsection
