@php
use App\Enums\ProductType;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'Product Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.purchase_product.index') }}">
                            Back
                        </a>
                        <button type="button" class="btn btn-primary" data-toggle="modal"
                            data-target="#purchase-product-modal"
                            @if ($product['shop_id'] == $shopId) disabled @elseif(!empty($parentProduct) && $parentProduct->shop_id == $shopId) disabled @endif
                            onclick="openPurchaseProductModal()">
                            Purchase
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">General Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="img-wrap rounded mx-auto mb-4 border shadow">
                        <img id="logo-preview" class="img"
                            src="{{ $product['image'] != null ? url('storage/product_image/' . $product['image']) : asset('img/empty-image.png') }}">
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Title:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->name }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->parent_product_id != null)
                            {{ $parentProduct->productCategory->name ?? 'Uncategorized' }}
                        @else
                            {{ $product->productCategory->name ?? 'Uncategorized' }}
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Sub Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->parent_product_id != null)
                            {{ $parentProduct->productSubCategory->name ?? '-' }}
                        @else
                            {{ $product->productSubCategory->name ?? '-' }}
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Status:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->is_available == 1)
                            <span class="badge badge-primary">Available</span>
                        @elseif($product->is_available == 0)
                            <span class="badge badge-danger">Not Available</span>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Description:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div class="ql-container ql-snow" style="min-height:150px;">
                        <div class="ql-editor">{!! $product->description ?? $parentProduct->description !!}</div>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Type:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parent_product_id != null ? ProductType::fromKey($parentProduct->product_type)->description : ProductType::fromKey($product->product_type)->description }}
                    </div>
                </div>

                @if (($product->parent_product_id != null
                    ? ProductType::fromKey($parentProduct->product_type)->description
                    : ProductType::fromKey($product->product_type)->description) == ProductType::Service()->key)
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Service Description:</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div class="ql-container ql-snow" style="min-height:150px;">
                            <div class="ql-editor">{!! $product->service_description ?? $parentProduct->service_description !!}</div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Price & Purchase Quantity</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Product Price:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        USDT
                        {{ $product->price ?? $parentProduct->resell_cost_price + $product->resell_profit }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Minimum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->min_purchase_qty ?? $parentProduct->min_purchase_qty }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Maximum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if (($product->parent_product_id != null ? $parentProduct->max_purchase_qty : $product->max_purchase_qty) == 0)
                            -
                        @else
                            {{ $parentProduct->max_purchase_qty ?? $product->max_purchase_qty }}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Promotion</h4>
        </div>
        <div class="card-body">
            @if ($productDiscounts->isEmpty())
                <div class="alert alert-secondary">
                    This product was no promotion.
                </div>
            @else
                @foreach ($productDiscounts as $productDiscount)
                    <div class="row mb-4">
                        <div class="col-6 col-sm-auto">
                            <label>Min Quantity: </label>
                            <div>
                                {{ $productDiscount->min_qty }}
                            </div>
                        </div>
                        <div class="col-6 col-sm-auto">
                            <label>Price / pcs (USDT): </label>
                            <div>
                                {{ $productDiscount->discounted_price }}
                            </div>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>

    <div class="modal fade" id="purchase-product-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Purchase Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="purchase-form"
                        action="{{ route('merchant.purchase_product.purchase', ['productId' => $product->id]) }}">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Product name</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span>{{ $product->name }}</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Minimum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="display-min-qty"></span>
                                <input type="hidden" id="min_qty">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Maximum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="max-qty"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Price / pcs</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <div class="input-group align-items-center">
                                    <span id="reseller-price-badge" class="badge badge-primary d-none">Reseller
                                        Price</span>
                                    <del id="strike-original-price" class="d-none"><span class="mr-1">USDT</span><span
                                            id="display-original-unit-price"></span></del>
                                    <span class="ml-1 mr-1">USDT</span><span id="display-unit-price"></span>
                                </div>
                                <input type="hidden" id="price" name="unit_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="quantity">Product Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <input type="number" class="form-control input-price" id="quantity" min="1"
                                    name="qty" placeholder="Product Quantity" onkeyup="checkPromotion()"
                                    onchange="checkPromotion()" required>
                            </div>
                        </div>

                        <hr>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Total (USDT)</label>
                            </div>
                            <div class="col-md-8 col-xl-6">
                                <span id="total">

                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="purchase-form" class="btn btn-success"
                        onclick="purchaseProduct(event)">
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(function() {
            $('#purchase-form').validate({
                rules: {
                    quantity: {
                        greaterOrEqual: '#min_qty'
                    },
                },
                messages: {
                    quantity: {
                        greaterOrEqual: 'This field must be equal or more than minimum purchase quantity.'
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            purchaseProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to purchase this product?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#purchase-form').submit();
                    }
                })
            };
        });
        var isReseller = null;

        function openPurchaseProductModal() {
            isReseller = false
            $('#price').attr('value', {{ $product->price }});
            $('#price').data('original-price', {{ $product->price }}.toFixed(2));
            $('#quantity').attr('value', {{ $product->min_purchase_qty }});
            $('#quantity').attr('min', 1);
            $('#display-min-qty').html({{ $product->min_purchase_qty }});
            $('#min_qty').attr('value', {{ $product->min_purchase_qty }});
            $('#max-qty').html('{{ $product->max_purchase_qty == 0 ? '-' : $product->max_purchase_qty }}');
            $('#reseller-price-badge').addClass('d-none');
            checkPromotion();

            var checkShopAgentUrl =
                `{{ route('merchant.resell_product.get', ['id' => ':id']) }}`
            checkShopAgentUrl = checkShopAgentUrl.replace(':id', {{ $product->id }});

            $.ajax({
                type: 'GET',
                url: checkShopAgentUrl,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {

                    if (data) {
                        isReseller = true;
                        var resellCostPrice = {{ $product->resell_cost_price ?? 0 }};
                        $('#price').attr('value', resellCostPrice.toFixed(2));
                        $('#price').data('original-price', resellCostPrice.toFixed(2));
                        $('#reseller-price-badge').removeClass('d-none');
                        checkPromotion();
                    }
                }
            });
        }

        function checkPromotion() {
            var originalPrice = $('#price').data('original-price');
            var promoPrice = 0;
            var purchaseQuantity = $('#quantity').val();

            var productDiscounts = @json($productDiscounts);

            productDiscounts.forEach((discount) => {
                if (purchaseQuantity >= discount.min_qty) {
                    promoPrice = discount.discounted_price;
                }
            })
            var total = originalPrice * purchaseQuantity;
            var promoTotal = promoPrice * purchaseQuantity;

            $('#display-unit-price').html(originalPrice);
            $('#price').val(originalPrice);
            $('#total').html(total.toFixed(2));
            $('#strike-original-price').addClass('d-none');
            if (isReseller) {
                $('#reseller-price-badge').removeClass('d-none');
            }

            if (promoTotal != 0) {
                if (total > promoTotal) {
                    $('#strike-original-price').removeClass('d-none');
                    $('#reseller-price-badge').addClass('d-none');
                    $('#display-original-unit-price').html(originalPrice);
                    $('#total').html(promoTotal.toFixed(2));
                    $('#display-unit-price').html(promoPrice);
                    $('#price').val(promoPrice);
                }
            }
        }
    </script>
@endsection
