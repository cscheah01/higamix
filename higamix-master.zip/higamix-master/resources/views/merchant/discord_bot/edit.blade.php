@extends('merchant/layout/layout')

@section('page_title', 'Edit Discord Bot')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Edit Discord Bot</h1>
                    <h4 class="m-0 d-block d-sm-none">Edit Discord Bot</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.discord_bot.show', ['id' => $discordBot->id]) }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form id="form" action="{{ route('merchant.discord_bot.update', ['id' => $discordBot->id]) }}"
                method="post" enctype="multipart/form-data">
                @csrf
                @method('PATCH')

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label for="username">Username</label>
                    </div>
                    <div class="col-sm-8 input-wrapper">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username"
                            value="{{ $discordBot->username }}" required>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-8 d-flex d-md-block justify-content-center">
                        <div class="img-wrap border img-circle shadow">
                            <img id="avatar_image_preview" class="img"
                                data-initial-image="{{ $discordBot->avatar_image != null ? url('storage/discord_bot/avatar_image/' . $discordBot->avatar_image) : asset('img/empty-image.png') }}"
                                src="{{ $discordBot->avatar_image != null ? url('storage/discord_bot/avatar_image/' . $discordBot->avatar_image) : asset('img/empty-image.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4 col-form-label">
                        <label for="avatar_image">Avatar Image</label>
                    </div>
                    <div class="col-sm-8">
                        <div class="input-group input-wrapper">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="avatar_image" name="avatar_image"
                                    accept=".png,.jpeg,.jpg">
                                <input type="hidden" name="remove_avatar_image" id="remove_avatar_image" value="0">
                                <label class="custom-file-label" id="avatar_image_label" for="avatar_image">
                                    @if ($discordBot->avatar_image != null)
                                        {{ $discordBot->avatar_image }}
                                    @else
                                        Choose file
                                    @endif
                                </label>
                            </div>
                            <button type="button"
                                class="btn btn-danger ml-2 {{ $discordBot->avatar_image == null ? 'd-none' : '' }}"
                                id="remove-image-btn" onclick="removeImage()">Remove</button>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label for="webhook_url">Webhook Url</label>
                    </div>
                    <div class="col-sm-8 input-wrapper">
                        <input type="text" class="form-control" id="webhook_url" name="webhook_url"
                            value="{{ $discordBot->webhook_url }}" placeholder="Webhook Url" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Enable Send Product Link</label>
                    <div class="col-sm-8 input-wrapper align-self-center">
                        <div class="d-flex">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_enable_send_product_link"
                                    id="enable_send_product_link" value="1"
                                    @if ($discordBot->is_enable_send_product_link) checked @endif>
                                <label for="enable_send_product_link" class="custom-control-label mr-4">Enable</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_enable_send_product_link"
                                    id="disable_send_product_link" value="0"
                                    @if (!$discordBot->is_enable_send_product_link) checked @endif>
                                <label for="disable_send_product_link" class="custom-control-label">Disable</label>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-sm-right">
                <button type="submit" form="form" class="btn btn-success">
                    Save Edit
                </button>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });
            $("#avatar_image").change(function() {
                const file = this.files[0];
                if (file) {
                    $('#remove_avatar_image').val(0);
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        $("#avatar_image_preview")
                            .attr("src", event.target.result);
                        $("#remove-image-btn").removeClass("d-none");
                    };
                    reader.readAsDataURL(file);
                } else {
                    var initialImage = $("#avatar_image_preview").data("initial-image");

                    $("#avatar_image_preview")
                        .attr("src", initialImage);
                    $("#remove-image-btn").addClass("d-none");
                }
            });
        });

        function removeImage() {
            $('#remove_avatar_image').val(0);
            if (!$("#avatar_image").val()) {
                $("#avatar_image_preview").data("initial-image", "{{ asset('img/empty-image.png') }}")
                $('#remove_avatar_image').val(1);
                $("#avatar_image_label").text("Choose file");
                $("#remove-image-btn").addClass("d-none");
            }
            if ($("#avatar_image_preview").data("initial-image") != "{{ asset('img/empty-image.png') }}") {
                $("#avatar_image_label").text("{{ $discordBot->avatar_image }}");
            }
            $("#avatar_image").val('');
            var initialImage = $("#avatar_image_preview").data("initial-image");
            $("#avatar_image_preview")
                .attr("src", initialImage);
        }
    </script>
@endsection
