@extends('merchant/layout/layout')

@section('page_title', 'Discord Bot')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <div class="d-flex">
                        <h1 class="m-0 d-none d-sm-block mr-2">Discord Bot</h1>
                        <h4 class="m-0 d-block d-sm-none mr-2">Discord Bot</h4>
                        <a class="align-self-center" href="{{ route('merchant.discord_bot.tutorial.index') }}">
                            View
                            Tutorial</a>
                    </div>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-success" href="{{ route('merchant.discord_bot.create') }}">
                            Create Discord Bot
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-username">Username</label>
                            <input type="search" id="filter-username" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.discord_bot.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: null,
                        name: "username",
                        render: function(data, type, row) {
                            var imageSrc = data.avatar_image != null ?
                                `{{ url('storage/discord_bot/avatar_image/${data.avatar_image}') }}` :
                                "{{ asset('img/empty-image.png') }}"

                            return `<div class="d-flex"><div class="img-sm-wrap mb-1 mr-2 border img-circle shadow"><img id="logo-preview" class="img-sm" src="${imageSrc}"
                            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'"></div><div class="align-self-center">${
                                data.username }</div></div>`;
                        }
                    },
                    {
                        width: "150px",
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.discord_bot.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var editUrl =
                                `{{ route('merchant.discord_bot.edit', ['id' => ':id']) }}`;
                            editUrl = editUrl.replace(':id', data.id);

                            var deleteUrl =
                                `{{ route('merchant.discord_bot.destroy', ['id' => ':id']) }}`;
                            deleteUrl = deleteUrl.replace(':id', data.id);


                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href=" ${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <a class="btn btn-primary mr-1" href=" ${editUrl}">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <form method="post" action=" ${deleteUrl}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteProduct(event)">
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [1, "desc"]
                ],
            });


            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    username: $("#filter-username").val(),
                };

                $table.column(0).search(filters.username);
                $table.draw();
            })

            deleteProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>
@endsection
