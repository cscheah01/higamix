@extends('merchant/layout/layout')

@section('page_title', 'Discord Bot Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Discord Bot Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Discord Bot Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('merchant.discord_bot.index') }}">
                                Back
                            </a>
                            <form method="post"
                                action={{ route('merchant.discord_bot.destroy', ['id' => $discordBot->id]) }}
                                class="mr-1">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="deleteProduct(event)">
                                    Delete
                                </button>
                            </form>
                            <a class="btn btn-primary"
                                href="{{ route('merchant.discord_bot.edit', ['id' => $discordBot->id]) }}">
                                Edit
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-4">
                    <label>Username</label>
                </div>
                <div class="col-12 col-md-8">
                    <div class="d-flex">
                        <div class="img-sm-wrap mr-2 border img-circle shadow">
                            <img id="logo-preview" class="img-sm"
                                src="{{ $discordBot->avatar_image != null ? url('storage/discord_bot/avatar_image/' . $discordBot->avatar_image) : asset('img/empty-image.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="align-self-center">
                            {{ $discordBot->username }}
                        </div>
                    </div>

                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-4">
                    <label>Webhook URL</label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        <span class="mr-2" id="webhook-url">{{ $discordBot['webhook_url'] }}</span>
                        <button class="btn btn-primary" id="btn-copy-webhook-url" onclick="copyWebhookUrl()">Copy</button>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-4">
                    <label>Enable Send Product Link</label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        @if ($discordBot->is_enable_send_product_link)
                            <span class="badge badge-primary">Enabled</span>
                        @elseif (!$discordBot->is_enable_send_product_link)
                            <span class="badge badge-secondary">Disabled</span>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-4">
                    <label>Created At</label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        {{ $discordBot->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            deleteProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

        });

        function copyWebhookUrl() {
            var webhookUrl = $("#webhook-url").text();
            navigator.clipboard.writeText(webhookUrl);

            $("#btn-copy-webhook-url").removeClass("btn-primary");
            $("#btn-copy-webhook-url").addClass("btn-success");
            $("#btn-copy-webhook-url").text("Copied!");
        }
    </script>
@endsection
