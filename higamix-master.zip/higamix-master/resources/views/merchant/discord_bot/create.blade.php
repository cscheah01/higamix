<?php

use App\Enums\ProductType;
?>
@extends('merchant/layout/layout')

@section('page_title', 'Create Discord Bot')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <div class="d-flex">
                        <h1 class="m-0 d-none d-sm-block mr-2">Create Discord Bot</h1>
                        <h4 class="m-0 d-block d-sm-none mr-2">Create Discord Bot</h4>
                        <a class="align-self-center" href="{{ route('merchant.discord_bot.tutorial.index') }}">
                            View
                            Tutorial</a>
                    </div>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.discord_bot.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('merchant.discord_bot.store') }}" method="post"
            enctype="multipart/form-data">
            @csrf

            <div class="card-body">
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label for="username">Username</label>
                    </div>
                    <div class="col-sm-8 input-wrapper">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username"
                            required>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-8 d-flex d-md-block justify-content-center">
                        <div class="img-wrap border img-circle shadow">
                            <img id="avatar_image_preview" class="img"
                                data-initial-image="{{ asset('img/empty-image.png') }}"
                                src="{{ asset('img/empty-image.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4 col-form-label">
                        <label for="avatar_image">Avatar Image</label>
                    </div>
                    <div class="col-sm-8">
                        <div class="input-group input-wrapper">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="avatar_image" name="avatar_image"
                                    accept=".png,.jpeg,.jpg">
                                <label class="custom-file-label" id="avatar_image_label" for="avatar_image">Choose
                                    file</label>
                            </div>
                            <button type="button" class="btn btn-danger ml-2 d-none" id="remove-image-btn"
                                onclick="removeImage()">Remove</button>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-4">
                        <label for="webhook_url">Webhook Url</label>
                    </div>
                    <div class="col-sm-8 input-wrapper">
                        <input type="text" class="form-control" id="webhook_url" name="webhook_url"
                            placeholder="Webhook Url" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Enable Send Product Link</label>
                    <div class="col-sm-8 input-wrapper align-self-center">
                        <div class="d-flex">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_enable_send_product_link"
                                    id="enable_send_product_link" value="1">
                                <label for="enable_send_product_link" class="custom-control-label mr-4">Enable</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_enable_send_product_link"
                                    id="disable_send_product_link" value="0">
                                <label for="disable_send_product_link" class="custom-control-label">Disable</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Create
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    webhook_url: {
                        maxlength: 2048,
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $("#avatar_image").change(function() {
                const file = this.files[0];
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        $("#avatar_image_preview")
                            .attr("src", event.target.result);
                        $("#remove-image-btn").removeClass("d-none");
                    };
                    reader.readAsDataURL(file);
                } else {
                    var initialImage = $("#avatar_image_preview").data("initial-image");

                    $("#avatar_image_preview")
                        .attr("src", initialImage);
                    $("#remove-image-btn").addClass("d-none");
                }
            });
        });

        function removeImage() {
            $("#avatar_image").val('');
            $("#avatar_image_label").text("Choose file");

            var initialImage = $("#avatar_image_preview").data("initial-image");

            $("#avatar_image_preview")
                .attr("src", initialImage);
            $("#remove-image-btn").addClass("d-none");
        }
    </script>
@endsection
