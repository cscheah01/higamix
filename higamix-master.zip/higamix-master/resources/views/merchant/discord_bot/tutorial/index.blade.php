@extends('merchant/layout/layout')

@section('page_title', 'Discord Bot Setting Tutorial')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Discord Bot Setting Tutorial</h1>
                    <h4 class="m-0 d-block d-sm-none">Discord Bot Setting Tutorial</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.discord_bot.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Step 1 : Create discord bot </h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12">
                            <p class="mt-2"> i) At discord channel, select channel setting.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/discord-tutorial/discord-tutorial-example-channel-setting.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2"> ii) At integrations tab, select view webhooks.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/discord-tutorial/discord-tutorial-example-view-webhook.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12">
                            <p class="mt-2">iii) You can add a new webhook here. Copy the webhook url after successful
                                adding a webhook. </p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/discord-tutorial/discord-tutorial-example-add-new-webhook.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-5">
                <div class="card-header">
                    <h4 class="mb-0">Step 2 : Add to HiGamix</h4>
                </div>
                <div class="card-body">
                    <div class="row">

                        <div class="col-12">
                            <p class="mt-2"> i) When creating the discord bot, paste the webhook url at
                                webhook url field that we copied from step 1. Press create button.</p>

                            <img class="img-fluid d-block"
                                src="{{ asset('img/discord-tutorial/discord-tutorial-example-create-discord-bot.png') }}"
                                onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script></script>
@endsection
