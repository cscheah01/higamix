@extends('merchant/layout/layout')

@section('page_title', 'Search Shop')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Search Shop</h1>
                    <h4 class="m-0 d-block d-sm-none">Search Shop</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-shop-name">Shop Name</label>
                            <input type="search" id="filter-shop-name" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Shop Name</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#table').DataTable({
                aasorting: [],
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.shop.search_shop.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                deferLoading: {{ auth()->user()->is_verified ? 'null' : 0 }},
                columns: [{
                        data: "name",
                        name: "name"
                    },
                    {
                        className: "double-line-ellipsis",
                        data: "general_description",
                        name: "general_description",
                        orderable: false,
                        render: function(data, type, row) {
                            return data ?? "-";
                        }
                    },
                    {
                        data: null,
                        width: "30px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.shop.search_shop.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            return `
                                <a class="btn btn-success" href="${viewUrl}">
                                <i class="fas fa-eye"></i>
                            </a>`;
                        }
                    },
                ],
            });

            $('#table thead th').removeClass('double-line-ellipsis');

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    shopName: $("#filter-shop-name").val(),
                };
                if (filters.name == "") {
                    $table.column(0).search('^$', true, false);
                } else {
                    $table.column(0).search(filters.shopName);
                }

                $table.draw();
            });
        });
    </script>
@endsection
