@extends('merchant/layout/layout')

@section('page_title', 'Shop Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.shop.search_shop.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="img-wrap mx-auto mb-4 border img-circle shadow">
                        <img id="logo-preview" class="img"
                            src="{{ $shop->logo_image != null ? url('storage/shop_logo/' . $shop->logo_image) : asset('img/empty-image.png') }}"
                            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Name</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $shop->name }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Telegram Channel Link</label>
                </div>
                <div class="col-12 col-md-10">
                    @if ($shop->telegram_channel_url != null)
                        <a href="{{ $shop->telegram_channel_url }}" target="_blank">
                            {{ $shop->telegram_channel_url }}
                        </a>
                    @else
                        <div>
                            -
                        </div>
                    @endif
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop General Description</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $shop->general_description ?? '-' }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Description</label>
                </div>
                <div class="col-12 col-md-10">
                    <div class="ql-container ql-snow" style="min-height:150px;">
                        <div class="ql-editor">{!! $shop->description !!}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label for="filter-product-name">Product Name</label>
                            <input type="search" id="filter-product-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label for="filter-product-type">Product Type</label>
                            <select id="filter-product-type" class="form-control">
                                <option disabled selected>Please Select Product Type</option>
                                @foreach ($productTypes as $productType)
                                    <option value="{{ $productType['value'] }}">{{ $productType['description'] }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 align-self-center">
                        <div class="float-right">
                            <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                                Reset
                            </button>
                            <button type="submit" class="btn btn-primary" form="filter-form">
                                Search
                            </button>
                        </div>
                    </div>
                </div>
            </form>

            <hr class="mb-3">

            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Product Type</th>
                        <th class="d-none"></th>
                        <th class="d-none"></th>
                        <th>Price (USDT)</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="purchase-product-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Purchase Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="purchase-form">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Product name</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="name"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Minimum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="display-min-qty"></span>
                                <input type="hidden" id="min_qty">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Maximum Purchase Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <span id="max-qty"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Price / pcs</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <div class="input-group align-items-center">
                                    <span id="reseller-price-badge" class="badge badge-primary d-none">Reseller Price</span>
                                    <del id="strike-original-price" class="d-none"><span class="mr-1">USDT</span><span
                                            id="display-original-unit-price"></span></del>
                                    <span class="ml-1 mr-1">USDT</span><span id="display-unit-price"></span>
                                </div>
                                <input type="hidden" id="price" name="unit_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="quantity">Product Quantity</label>
                            </div>
                            <div class="col-md-8 col-xl-6 input-wrapper">
                                <input type="number" class="form-control input-price" min="1" id="quantity"
                                    name="qty" placeholder="Product Quantity" onkeyup="checkPromotion()"
                                    onchange="checkPromotion()" required>
                            </div>
                        </div>

                        <hr class="mt-5">

                        <div class="form-group row font-weight-bold">
                            <div class="col-md-6 text-right">
                                <label>Total (USDT)</label>
                            </div>
                            <div class="col-md-8 col-xl-6">
                                <span id="total">

                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="purchase-form" class="btn btn-success"
                        onclick="purchaseProduct(event)">
                        Purchase
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="create-resell-product-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Resell Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="create-resell-form">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="name">Product Name</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Product Name" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label>Resell Cost Price (USDT)</label>
                            </div>
                            <div class="col-md-9 col-xl-7">
                                <span id="display-resell-cost-price"></span>
                                <input type="hidden" id="resell-cost-price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label>Suggested Min Resell Price (USDT)</label>
                            </div>
                            <div class="col-md-9 col-xl-7">
                                <span id="display-suggested-min-resell-price"></span>
                                <input type="hidden" id="suggested_min_resell_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="resellprice">Price</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <div class="input-group">
                                    <div class="input-group-append">
                                        <span class="input-group-text">USDT</span>
                                    </div>
                                    <input type="number" step="0.01" class="form-control input-price"
                                        id="resellprice" name="price" placeholder="Resell Price"
                                        onchange="checkSuggestedPrice()" required>
                                </div>
                                <div class="alert alert-warning d-none mt-2" id="suggested-price-alert" role="alert">
                                    The suggested minimum resell price is USDT <span
                                        id="display-alert-suggested-price"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="product_category_id">Product Category</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="product_category_id" name="product_category_id"
                                    style="width: 100%;" onchange="resetSubcategory()" required></select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="product_sub_category_id">Product Sub Category</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="product_sub_category_id" name="product_sub_category_id"
                                    style="width: 100%;"></select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="discord_bot_id">Discord Bot</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="discord_bot_id" name="discord_bot_id"
                                    style="width: 100%;"></select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="create-resell-form" class="btn btn-success">
                        Resell
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#create-resell-form').validate({
                rules: {
                    price: {
                        greaterOrEqual: '#resell-cost-price',
                    },
                },
                messages: {
                    price: {
                        greaterOrEqual: "This field must be equal or more than resell cost price.",
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#purchase-form').validate({
                rules: {
                    quantity: {
                        greaterOrEqual: '#min_qty',
                    },
                },
                messages: {
                    quantity: {
                        greaterOrEqual: 'This field must be equal or more than minimum purchase quantity.'
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.product.datatable', ['id' => $shop->id]) }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "product_type",
                        name: "product_type"
                    },
                    {
                        data: "product_category_id",
                        name: "product_categories.id",
                        visible: false,
                    },
                    {
                        data: "product_sub_category_id",
                        name: "product_sub_categories.id",
                        visible: false,
                    },
                    {
                        className: "dt-body-right",
                        data: "price",
                        name: "price"
                    },
                    {
                        data: "is_available",
                        name: "is_available",
                        className: "text-center",
                        width: "100px",
                        render: function(data, type, row) {
                            if (data == true) {
                                return '<span class="badge badge-primary">Available</span>';
                            } else {
                                return '<span class="badge badge-danger">Not Available</span>';
                            }
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "260px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.product.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var purchaseUrl =
                                `{{ route('merchant.purchase_product.purchase', ['productId' => ':productId']) }}`;
                            purchaseUrl = purchaseUrl.replace(':productId', data.id);

                            var resellUrl =
                                `{{ route('merchant.resell_product.store', ['id' => ':id']) }}`;
                            resellUrl = resellUrl.replace(':id', data.id);

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <button type="button" class="btn btn-primary mr-1" onclick="openPurchaseProductModal('${purchaseUrl}','${data.name}','${data.price}','${data.id}','${data.min_purchase_qty}','${data.max_purchase_qty}','${data.resell_cost_price}')" ${data.is_available == false ? 'disabled' : ''}>
                                    Purchase
                                </button>

                                <button type="button" class="btn btn-primary" onclick="openCreateResellProductModal('${resellUrl}','${data.suggested_min_resell_price}','${data.resell_cost_price}')" ${data.is_available == false ? 'disabled' : ''} ${data.is_open_resell == false ? 'disabled' : ''}>
                                    Resell Product
                                </button>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [6, "desc"]
                ],
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    productName: $("#filter-product-name").val(),
                    productType: $("#filter-product-type").val() ?? '',
                };

                $table.column(0).search(filters.productName);
                $table.column(1).search(filters.productType);
                $table.draw();
            });

            purchaseProduct = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to purchase this product?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#purchase-form').submit();
                    }
                })
            };

            $('#product_category_id').select2({
                dropdownParent: $('#create-resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Category',
                ajax: {
                    url: "{{ route('merchant.product_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#product_sub_category_id").select2({
                dropdownParent: $('#create-resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Sub Category',
                ajax: {
                    url: "{{ route('merchant.product_sub_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            product_main_category_id: $('#product_category_id')
                                .val(),
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#discord_bot_id").select2({
                dropdownParent: $('#create-resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Discord Bot',
                ajax: {
                    url: "{{ route('merchant.discord_bot.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.username,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });
        });

        var currentProductDiscounts = null;
        var isReseller = null;

        function openPurchaseProductModal(purchaseUrl, productName, price, productId, minPurchaseQuantity,
            maxPurchaseQuantity, resellCostPrice) {
            var getPromotionUrl =
                `{{ route('merchant.product.discount.show', ['productId' => ':productId']) }}`
            getPromotionUrl = getPromotionUrl.replace(':productId', productId);

            $.ajax({
                type: 'GET',
                url: getPromotionUrl,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    currentProductDiscounts = data;
                    isReseller = false;
                    $('#purchase-product-modal').modal('show');
                    $('#price').attr('value', price);
                    $('#price').data('original-price', price);
                    $('#name').html(productName);
                    $('#purchase-form').attr('action', purchaseUrl);
                    $('#quantity').attr('value', minPurchaseQuantity);
                    $('#quantity').attr('min', 1);
                    $('#display-min-qty').html(minPurchaseQuantity);
                    $('#min_qty').attr('value', minPurchaseQuantity);
                    $('#max-qty').html(maxPurchaseQuantity == 0 ? '-' : maxPurchaseQuantity);
                    $('#reseller-price-badge').addClass('d-none');
                    checkPromotion();
                }
            });

            var checkShopAgentUrl =
                `{{ route('merchant.resell_product.get', ['id' => ':id']) }}`
            checkShopAgentUrl = checkShopAgentUrl.replace(':id', productId);

            $.ajax({
                type: 'GET',
                url: checkShopAgentUrl,
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(data) {
                    if (data) {
                        isReseller = true;
                        $('#price').attr('value', resellCostPrice);
                        $('#price').data('original-price', resellCostPrice);
                        $('#reseller-price-badge').removeClass('d-none');
                        checkPromotion();
                    }
                }
            });
        }

        function checkPromotion() {
            var originalPrice = $('#price').data('original-price');
            var promoPrice = 0;
            var purchaseQuantity = $('#quantity').val();

            currentProductDiscounts.forEach((discount) => {
                if (purchaseQuantity >= discount.min_qty) {
                    promoPrice = discount.discounted_price;
                }
            })
            var total = originalPrice * purchaseQuantity;
            var promoTotal = promoPrice * purchaseQuantity;

            $('#display-unit-price').html(originalPrice);
            $('#price').val(originalPrice);
            $('#total').html(total.toFixed(2));
            $('#strike-original-price').addClass('d-none');
            if (isReseller) {
                $('#reseller-price-badge').removeClass('d-none');
            }

            if (promoTotal != 0) {
                if (total > promoTotal) {
                    $('#strike-original-price').removeClass('d-none');
                    $('#reseller-price-badge').addClass('d-none');
                    $('#display-original-unit-price').html(originalPrice);
                    $('#total').html(promoTotal.toFixed(2));
                    $('#display-unit-price').html(promoPrice);
                    $('#price').val(promoPrice);
                }
            }
        }

        function openCreateResellProductModal(resellUrl, suggestedMinResellPrice, resellCostPrice) {
            $('#create-resell-product-modal').modal('show');
            $('#resellprice').attr('value', suggestedMinResellPrice);
            $('#display-suggested-min-resell-price').html(suggestedMinResellPrice);
            $('#display-resell-cost-price').html(resellCostPrice);
            $('#suggested_min_resell_price').attr('value', suggestedMinResellPrice);
            $('#resell-cost-price').attr('value', resellCostPrice);
            $('#create-resell-form').attr('action', resellUrl);
            $('#display-alert-suggested-price').html(suggestedMinResellPrice);
        }

        function checkSuggestedPrice() {
            var price = $('#resellprice').val();
            var suggestedPrice = $('#suggested_min_resell_price').val();

            if (parseFloat(price).toFixed(2) >= suggestedPrice) {
                $('#suggested-price-alert').addClass('d-none');
            } else {
                $('#suggested-price-alert').removeClass('d-none');
            }
        }

        function resetSubcategory() {
            $("#product_sub_category_id").empty();
        }
    </script>
@endsection
