@extends('merchant/layout/layout')

@section('page_title', 'Notifications')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Notifications</h1>
                    <h4 class="m-0 d-block d-sm-none">Notifications</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="float-right">
                <button type="submit" class="btn btn-primary mb-2 mb-md-0" form="form">
                    Mark all as seen
                </button>
            </div>
            <form id="form" action="{{ route('merchant.notification.update') }}" method="post">
                @csrf
                @method('PATCH')
                <input type="hidden" class="form-control" name="is_seen" value='1'>
            </form>
            <div class="table-responsive">
                <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Content</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.notification.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        orderable: false,
                        data: null,
                        name: "content",
                        render: function(data, type, row) {

                            if (data.product_id != null)
                                return `
                            New Product Log
                            <p>${data.content}</p>
                             `;

                            else if (data.order_id != null)
                                return `
                            New Order Comment
                            <p>${data.content}</p>
                            `;

                            else if (data.product_category_id != null)
                                return `
                            New Product Category Log
                            <p>${data.content}</p>
                            `;

                            else if (data.product_sub_category_id != null)
                                return `
                            New Product Sub Category Log
                            <p>${data.content}</p>
                            `;
                        }
                    },
                    {
                        data: null,
                        name: "is_seen",
                        width: "50px",
                        className: "text-center",
                        render: function(data, type, row) {
                            if (data.is_seen == false)
                                return `
                           <span class="badge badge-secondary">Unseen
                                    </span>
                             `;
                            else

                                return `
                             <span class="badge badge-primary">Seen
                                    </span>
                            `;
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            if (data.product_id != null) {
                                var viewUrl =
                                    `{{ route('merchant.product.show', ['id' => ':id']) }}`;
                                viewUrl = viewUrl.replace(':id', data.product_id);
                            } else if (data.order_id != null) {

                                if (data.order_user_id != {{ $userId }}) {
                                    var viewUrl =
                                        `{{ route('merchant.sales_history.show', ['id' => ':id']) }}`;
                                    viewUrl = viewUrl.replace(':id', data.order_id);
                                } else if (data.order_user_id == {{ $userId }}) {
                                    var viewUrl =
                                        `{{ route('merchant.purchase_history.show', ['id' => ':id']) }}`;
                                    viewUrl = viewUrl.replace(':id', data.order_id);
                                }
                            } else {
                                var viewUrl =
                                    `{{ route('merchant.notification.show', ['id' => ':id']) }}`;
                                viewUrl = viewUrl.replace(':id', data.id);
                            }

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success ml-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                            </div>`;
                        }
                    },

                ],
                order: [
                    [2, "desc"]
                ],
            });
        });
    </script>
@endsection
