@extends('merchant/layout/layout')

@section('page_title', 'Notification')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Notification</h1>
                    <h4 class="m-0 d-block d-sm-none">Notification</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('merchant.notification.index') }}">
                                Back
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                @if ($notification->product_id != null)
                    <div class="col-12 col-md-4">
                        <label>Product name</label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div>
                            {{ $notification->product->name }}
                        </div>
                    </div>
                @elseif($notification->order_id != null)
                    <div class="col-12 col-md-4">
                        <label>Shop Name</label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div>
                            {{ $notification->order->name }}
                        </div>
                    </div>
                @elseif($notification->product_category_id != null)
                    <div class="col-12 col-md-4">
                        <label>Shop Name</label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div>
                            {{ $notification->productCategory->shop->name }}
                            ({{ $notification->productCategory->name }})
                        </div>
                    </div>
                @elseif($notification->product_sub_category_id != null)
                    <div class="col-12 col-md-4">
                        <label>Shop name</label>
                    </div>
                    <div class="col-12 col-md-8">
                        <div>
                            {{ $notification->productSubCategory->productCategory->shop->name }}
                            ({{ $notification->productSubCategory->productCategory->name }} >
                            {{ $notification->productSubCategory->name }})
                        </div>
                    </div>
                @endif
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-4">
                    <label>Content</label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        {{ $notification->content }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script></script>
@endsection
