@extends('merchant/layout/layout')

@section('page_title', 'Edit Payment Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Account Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Account Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-12 col-md-4">
            @include('merchant/account_setting/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Edit Payment Setting</h4>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-dark" href="{{ route('merchant.profile.payment_setting.index') }}">
                                    Back
                                </a>
                                <button type="submit" form="form" class="btn btn-success" onclick="submitForm(event)">
                                    Save Edit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form id="form" action="{{ route('merchant.profile.payment_setting.update') }}" method="post">
                        @csrf
                        @method('PATCH')

                        <div class="form-group row">
                            <label for="withdraw_address" class="col-sm-5 col-form-label">Withdrawal Wallet Address -
                                Tether</label>
                            <div class="col-sm-7 input-wrapper">
                                <div class="input-wrapper">
                                    <input type="text" class="form-control" id="withdraw_address" name="withdraw_address"
                                        value="{{ $wallet['withdraw_address'] }}" placeholder="Withdrawal Wallet Address">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
            submitForm = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Please make sure it is a valid Tether wallet address.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Confirm'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#form').submit();
                    }
                })
            };

        });
    </script>
@endsection
