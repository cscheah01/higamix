@extends('merchant/layout/layout')

@section('page_title', 'Payment Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Account Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Account Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4">
            @include('merchant/account_setting/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Payment Setting</h4>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-primary" href="{{ route('merchant.profile.payment_setting.edit') }}">
                                    Edit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-5">
                            <label>Withdrawal Wallet Address - Tether</label>
                        </div>
                        <div class="col-12 col-md-7">
                            @if ($wallet['withdraw_address'] == null)
                                <span class="badge badge-secondary">None</span>
                            @else
                                {{ $wallet['withdraw_address'] }}
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(function() {});
    </script>
@endsection
