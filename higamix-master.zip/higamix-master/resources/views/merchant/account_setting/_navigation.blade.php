<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills nav-sidebar flex-column">
            <li class="nav-item">
                <a href="{{ route('merchant.profile.index') }}"
                    class="nav-link {{ Request::routeIs('merchant.profile.index') || Request::routeIs('merchant.profile.edit') ? 'active' : '' }}">
                    <p>
                        Account
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('merchant.profile.edit_password') }}"
                    class="nav-link {{ Request::routeIs('merchant.profile.edit_password') ? 'active' : '' }}">
                    <p>
                        Change Password
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('merchant.profile.payment_setting.index') }}"
                    class="nav-link {{ Request::routeIs('merchant.profile.payment_setting.index') || Request::routeIs('merchant.profile.payment_setting.edit') ? 'active' : '' }}">
                    <p>
                        Payment
                    </p>
                </a>
            </li>
        </ul>
    </div>
</div>
