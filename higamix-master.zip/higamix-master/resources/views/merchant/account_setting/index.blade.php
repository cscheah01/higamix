@extends('merchant/layout/layout')

@section('page_title', 'Account Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Account Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Account Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4">
            @include('merchant/account_setting/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card mt-md-0 mt-4">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Account Details</h4>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-primary" href="{{ route('merchant.profile.edit') }}">
                                    Edit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <label>Email</label>
                        </div>
                        <div class="col-12 col-md-8">
                            <div>
                                {{ $profile['email'] }}
                            </div>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <label>Two-factor Authentication</label>
                        </div>
                        <div class="col-12 col-md-8">
                            <div>
                                @if ($profile['is_enabled_two_factor'])
                                    <div class='d-flex'>
                                        <div>
                                            <span class="badge badge-primary mr-2">Enabled</span>
                                        </div>
                                        <div>
                                            <form action="{{ route('merchant.two_factor.disable') }}" method="post">
                                                @csrf
                                                @method('PATCH')

                                                <input type="hidden" name="is_enabled_two_factor" value="0">
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="disableTwoFactor(event)">
                                                    Disable
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                @elseif (!$profile['is_enabled_two_factor'])
                                    <span class="badge badge-secondary mr-2">Disabled</span>
                                    <a class="btn btn-primary" href="{{ route('merchant.two_factor.setup.index') }}">
                                        Enable
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <label>Account Verify</label>
                        </div>
                        <div class="col-12 col-md-8">
                            <div>
                                @if ($profile['is_verified'])
                                    <span class="badge badge-success">Verified</span>
                                @elseif (!$profile['is_verified'])
                                    <div class="d-flex">
                                        <div>
                                            @if ($accountVerifyRequest == null || $accountVerifyRequest->is_waiting_approved)
                                                <span class="badge badge-warning mr-2">Non-Verified</span>
                                            @else
                                                <span class="badge badge-danger mr-2">Rejected</span>
                                            @endif
                                        </div>

                                        <form method="post" id="form"
                                            action="{{ route('merchant.account_verify_request.store') }}">
                                            @csrf

                                            @if ($accountVerifyRequest == null)
                                                <button type="submit" form="form" class="btn btn-primary">
                                                    Request Verify
                                                </button>
                                            @elseif($accountVerifyRequest->is_waiting_approved)
                                                <button type="submit" form="form" class="btn btn-warning" disabled>
                                                    Pending
                                                </button>
                                            @endif
                                        </form>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mt-5">
                <div class="card-header">
                    <h4 class="mb-0">API Credentials</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-4">
                            <label>Public Key</label>
                        </div>
                        <div class="col-12 col-md-8">
                            <div class="d-flex justify-content-between">
                                {{ $profile['api_public_key'] }}
                                <form action="{{ route('merchant.profile.reset_api_public_key') }}" method="post">
                                    @method('PATCH')
                                    @csrf
                                    <button type="submit" class="btn btn-primary" onclick="resetApiPublicKey(event)">
                                        Reset
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <hr class="my-2">

                    <div class="row">
                        <div class="col-12 col-md-4">
                            <label>Secret Key</label>
                        </div>
                        <div class="col-12 col-md-8">
                            <div class="d-flex justify-content-between">
                                <div class="blurry-text noselect position-relative" id="api-secret-key">
                                    <button class="btn btn-dark position-absolute" id="unhide-api-secret-btn"
                                        onclick="unhideApiSecretKey(event)">
                                        Unhide
                                    </button>
                                    {{ $profile['api_secret_key'] }}
                                </div>

                                <form action="{{ route('merchant.profile.reset_api_secret_key') }}" method="post">
                                    @method('PATCH')
                                    @csrf
                                    <button type="submit" class="btn btn-primary" onclick="resetApiSecretKey(event)">
                                        Reset
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(function() {
            disableTwoFactor = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to disable?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, disable it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }

            resetApiSecretKey = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to reset?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, reset it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }

            resetApiPublicKey = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to reset?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, reset it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }

            unhideApiSecretKey = function() {
                $('#api-secret-key').removeClass('blurry-text noselect');
                $("#unhide-api-secret-btn").remove();
            }
        });
    </script>
@endsection
