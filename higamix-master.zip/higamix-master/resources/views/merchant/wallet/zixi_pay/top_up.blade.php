@extends('merchant/layout/layout')

@section('page_title', 'Top Up Wallet - USDT')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Top Up Wallet - USDT</h1>
                    <h4 class="m-0 d-block d-sm-none">Top Up Wallet - USDT</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.wallet.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body text-center">
            <div class="alert alert-warning font-weight-bold">
                Minimum Top Up Amount: {{ $minTopUpAmount ?? '0.00' }} USDT
            </div>

            <h5 class="font-weight-bold mt-5 mb-3">Tether-TRC20</h5>


            <img class="shadow rounded-lg p-3 mw-100" src="{{ $wallet['qr'] }}">

            <h5 class="font-weight-bold mt-5 mb-3">Wallet Address:</h5>

            <div class="bg-light rounded-lg p-3">
                <h5 id="wallet-address">{{ $wallet['wallet_address'] }}</h5>
                <button class="btn btn-primary mt-2" id="btn-copy-wallet-address"
                    onclick="copyWalletAddress()">Copy</button>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            copyWalletAddress = function() {
                var walletAddress = $("#wallet-address").text();
                navigator.clipboard.writeText(walletAddress);

                $("#btn-copy-wallet-address").removeClass("btn-primary");
                $("#btn-copy-wallet-address").addClass("btn-success");
                $("#btn-copy-wallet-address").text("Copied!");
            }
        });
    </script>
@endsection
