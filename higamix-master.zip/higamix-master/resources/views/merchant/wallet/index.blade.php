@extends('merchant/layout/layout')

@section('page_title', 'Wallet')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Wallet</h1>
                    <h4 class="m-0 d-block d-sm-none">Wallet</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-md-6">
            <div class="card h-100">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-1 pt-2">Balance Amount</h4>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto">
                            <i class="fa-solid fa-wallet fa-5x"></i>
                        </div>
                        <div class="col col-md-6">
                            <div class="row">
                                <div class="col-auto">
                                    <label>USDT</label>
                                    <h5>{{ $wallet['balance'] }}</h5>
                                </div>
                                <div class="col-auto text-muted">
                                    <label class="d-flex">Inactive Balance <i
                                            class="fa-solid fa-circle-exclamation mt-1 ml-2" data-toggle="tooltip"
                                            data-placement="top"
                                            title="You need to top up and hit the minimum top up amount to let your balance here become active."></i></label>
                                    <h5>{{ $wallet['inactive_balance'] }}</h5>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mt-3">
                            <div class="float-right">
                                <button type="button" class="btn btn-warning mr-2"
                                    @if ($wallet['withdraw_address'] != null) data-toggle="modal"
                            data-target="#request-withdraw-modal" @endif
                                    @if ($wallet['withdraw_address'] == null) onclick="requestWithdrawal(event)" @endif>Request
                                    Withdraw</button>
                                <a href="{{ route('merchant.wallet.zixi_pay.top_up') }}" class="btn btn-primary">Top
                                    Up</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 mt-md-0 mt-5">
            <div class="card h-100">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Withdrawal Wallet Address</h4>
                        </div>
                        <div class="col-12 col-sm-auto">
                            <div class="float-sm-right">
                                <a class="btn btn-primary" href="{{ route('merchant.profile.payment_setting.edit') }}">
                                    Edit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <label>Address:</label>
                    @if ($wallet['withdraw_address'] == null)
                        <span class="badge badge-secondary">None</span>
                    @else
                        <h5>
                            {{ $wallet['withdraw_address'] }}
                        </h5>
                    @endif

                </div>
            </div>
        </div>
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body table-responsive">
                    <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Debit Amount (USDT)</th>
                                <th>Credit Amount (USDT)</th>
                                <th>Balance (USDT)</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="request-withdraw-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Withdraw Amount</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="form" method="post" action="{{ route('merchant.wallet.withdraw') }}">
                    <div class="modal-body">
                        @csrf
                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label>Remaining Balance : </label>
                            </div>
                            <div class="col-12 col-md-8">
                                USDT {{ $wallet['balance'] }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label>Minimum Withdraw Amount : </label>
                            </div>
                            <div class="col-12 col-md-8">
                                USDT {{ $minimumWithdrawAmount }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label>Withdrawal Fee : </label>
                            </div>
                            <div class="col-12 col-md-8">
                                @if (!empty($withdrawalTransactionFees))
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">
                                                        Amount more than or equal to (USDT)
                                                    </th>
                                                    <th class="text-center">
                                                        Fee (USDT)
                                                    </th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($withdrawalTransactionFees as $withdrawalTransactionFee)
                                                    <tr>
                                                        <td class="text-right">
                                                            {{ $withdrawalTransactionFee['amount_more_than_equal'] }}
                                                        </td>
                                                        <td class="text-right">{{ $withdrawalTransactionFee['fee'] }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @else
                                    -
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label for="amount">Amount : </label>
                            </div>
                            <div class="col-12 col-md-8 input-wrapper">
                                <div class="input-group">
                                    <div class="input-group-append">
                                        <span class="input-group-text">USDT</span>
                                    </div>
                                    <input type="number" step="0.01" class="form-control" id="amount" name="amount"
                                        placeholder="Amount" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" form="form" class="btn btn-primary"
                            onclick="submitRequestWithdrawal(event)">Withdraw</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.wallet.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        className: "dt-body-right",
                        data: "debit",
                        name: "debit",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        },
                    },
                    {
                        className: "dt-body-right",
                        data: "credit",
                        name: "credit",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                    {
                        className: "dt-body-right",
                        data: "balance",
                        name: "balance",
                        orderable: false,
                    },
                    {
                        data: null,
                        name: "description",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data.order_id) {

                                var urlPurchaseHistory =
                                    `{{ route('merchant.purchase_history.show', ['id' => ':id']) }}`;
                                urlPurchaseHistory = urlPurchaseHistory.replace(':id', data
                                    .order_id);

                                var urlSalesHistory =
                                    `{{ route('merchant.sales_history.show', ['id' => ':id']) }}`;
                                urlSalesHistory = urlSalesHistory.replace(':id', data.order_id);

                                if (data.debit != null) {
                                    return `
                                        Sales order #
                                        <a href="${urlSalesHistory}">
                                        ${data.order_id}
                                        </a>`;
                                } else {
                                    return `
                                        Purchase for order #
                                        <a href="${urlPurchaseHistory}">
                                        ${data.order_id}
                                        </a>`;
                                }
                            }

                            return `${data.description}`;
                        }
                    },
                ],
                order: [
                    [0, "desc"]
                ],
            });

            $('#form').validate({
                rules: {
                    amount: {
                        min: {{ $minimumWithdrawAmount }},
                        max: {{ $wallet['balance'] }},
                    },

                },
                messages: {
                    amount: {
                        min: 'This field must be equal or more than minimum withdraw amount.',
                        max: 'This field must be equal or less than your wallet balance',
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            submitRequestWithdrawal = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to withdraw?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            requestWithdrawal = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'You have not set your withdrawal wallet address.',
                    icon: 'warning',
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                })
            };
        });
    </script>
@endsection
