<aside class="main-sidebar sidebar-light-main elevation-4 position-fixed">
    <div class="brand-link">
        <img src="{{ asset('img/logo-higamix.png') }}" class="brand-image img-circle elevation-3 bg-white p-1"
            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
        <a href="{{ route('merchant.dashboard') }}">
            <div class="brand-text"><img class="sidebar-horizontal-logo" src="{{ asset('img/logo-text-higamix.png') }}"
                    onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'"></div>
        </a>
    </div>

    <div class="sidebar" style="margin-top: 57px; height: calc(100vh - 57px);">
        <nav class="mt-2 pb-4">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-item">
                    <a href="{{ route('merchant.dashboard') }}"
                        class="nav-link {{ Request::routeIs('merchant.dashboard') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-home"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <li
                    class="nav-item {{ Request::routeIs('merchant.product_category.*') || Request::routeIs('merchant.product_sub_category.*') || Request::routeIs('merchant.product.*') || Request::routeIs('merchant.product_serial.*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-box-archive"></i>
                        <p>
                            Product
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('merchant.product.index') }}"
                                class="nav-link {{ Request::routeIs('merchant.product.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Product
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('merchant.product_serial.index') }}"
                                class="nav-link {{ Request::routeIs('merchant.product_serial.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Product Stock
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('merchant.product_category.index') }}"
                                class="nav-link {{ Request::routeIs('merchant.product_category.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Product Category
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('merchant.product_sub_category.index') }}"
                                class="nav-link {{ Request::routeIs('merchant.product_sub_category.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Product Sub Category
                                </p>
                            </a>
                        </li>

                    </ul>
                </li>

                <li
                    class="nav-item {{ Request::routeIs('merchant.resellable_product.*') || Request::routeIs('merchant.resell_product.*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-box-archive"></i>
                        <p>
                            Resell Product
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('merchant.resellable_product.index') }}"
                                class="nav-link {{ Request::routeIs('merchant.resellable_product.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Search Resell Product
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('merchant.resell_product.index') }}"
                                class="nav-link {{ Request::routeIs('merchant.resell_product.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    My Resell Product
                                </p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li
                    class="nav-item {{ Request::routeIs('merchant.shop_agent.approval.*') || Request::routeIs('merchant.shop_agent.*') || Request::routeIs('merchant.shop_agent.setting.*') || Request::routeIs('merchant.shop_agent.rejected.*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link">
                        <i class="fas fa-user-friends nav-icon"></i>
                        <p>
                            Agent
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('merchant.shop_agent.setting.index') }}"
                                class="nav-link  {{ Request::routeIs('merchant.shop_agent.setting.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Agent Setting
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('merchant.shop_agent.index') }}"
                                class="nav-link  {{ Request::routeIs('merchant.shop_agent.index') || Request::routeIs('merchant.shop_agent.show') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    My Agent
                                </p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('merchant.shop_agent.approval.index') }}"
                                class="nav-link  {{ Request::routeIs('merchant.shop_agent.approval.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Approval Request
                                </p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('merchant.shop_agent.rejected.index') }}"
                                class="nav-link  {{ Request::routeIs('merchant.shop_agent.rejected.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Rejected List
                                </p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.purchase_product.index') }}"
                        class="nav-link {{ Request::routeIs('merchant.purchase_product.*') ? 'active' : '' }}">
                        <i class="fas fa-cart-plus nav-icon"></i>
                        <p>
                            Purchase Product
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.sales_history.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.sales_history.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-file-invoice-dollar"></i>
                        <p>
                            Sales History
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.agent_sales_history.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.agent_sales_history.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-file-invoice-dollar"></i>
                        <p>
                            Agent Sales History
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.purchase_history.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.purchase_history.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-file-invoice"></i>
                        <p>
                            Purchase History
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.shop.search_shop.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.shop.search_shop.*') || Request::routeIs('merchant.product.search_shop.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-search"></i>
                        <p>
                            Search Shop
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.wallet.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.wallet.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-wallet"></i>
                        <p>
                            Wallet
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('merchant.discord_bot.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.discord_bot.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-robot"></i>
                        <p>
                            Discord Bot
                        </p>
                    </a>
                </li>

                {{-- <li class="nav-item">
                    <a href="{{ route('merchant.invite_code.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.invite_code.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-link"></i>
                        <p>
                            Invite Code
                        </p>
                    </a>
                </li> --}}

                <li class="nav-item">
                    <a href="{{ route('merchant.login_history.index') }}"
                        class="nav-link  {{ Request::routeIs('merchant.login_history.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-history"></i>
                        <p>
                            Login History
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
