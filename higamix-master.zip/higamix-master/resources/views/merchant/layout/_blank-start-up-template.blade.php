@extends('merchant/layout/layout')

@section('page_title', 'Page Name')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Title</h1>
                    <h4 class="m-0 d-block d-sm-none">Title</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a type="button" class="btn btn-success btn-custom-green" href="#">
                            Button
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="form-group">
                        <label>input</label>
                        <input type="search" class="form-control">
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default">
                    Reset
                </button>
                <button type="button" class="btn btn-primary">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped table-hover cursor-pointer data-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Title</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            Contain
                        </td>
                        <td>
                            Contain
                        </td>
                        <td>
                            Contain
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

        });
    </script>
@endsection
