<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button" onclick="SidebarToggle()">
                <i class="fas fa-bars"></i>
            </a>

            <script>
                function SidebarToggle() {
                    $.ajax({
                        type: "POST",
                        url: "{{ route('sidebar.save_state') }}",
                        data: {
                            _token: "{{ csrf_token() }}"
                        }
                    })
                }
            </script>
        </li>
    </ul>

    <ul class="navbar-nav">
        <li class="nav-item dropdown">
            <a data-toggle="dropdown" href="#" class="nav-link">
                <i class="fas fa-comment"></i>

                @if ($totalUnseenNotificationCount > 0)
                    <span
                        class="badge badge-danger">{{ $totalUnseenNotificationCount > 100 ? '100+' : $totalUnseenNotificationCount }}</span>
                @endif
            </a>

            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="min-width:300px">

                @foreach ($unseenNotifications as $unseenNotification)
                    @php
                        $notificationLink = '#';

                        if ($unseenNotification->product_id != null) {
                            $notificationLink = route('merchant.product.show', ['id' => $unseenNotification->product_id]);
                        } elseif ($unseenNotification->order_id != null) {
                            if ($unseenNotification->order->user_id == Auth::id()) {
                                $notificationLink = route('merchant.purchase_history.show', ['id' => $unseenNotification->order_id]);
                            } elseif ($unseenNotification->order->user_id != Auth::id()) {
                                $notificationLink = route('merchant.sales_history.show', ['id' => $unseenNotification->order_id]);
                            }
                        } else {
                            $notificationLink = route('merchant.notification.show', ['id' => $unseenNotification->id]);
                        }
                    @endphp


                    <a class="dropdown-item" href="{{ $notificationLink }}">
                        <div class="media">
                            <div class="media-body">
                                <h3 class="dropdown-item-title">
                                    @if ($unseenNotification->product_id != null)
                                        New Product Log
                                    @elseif($unseenNotification->order_id != null)
                                        New Order Comment
                                    @elseif($unseenNotification->product_category_id != null)
                                        New Product Category Log
                                    @elseif($unseenNotification->product_sub_category_id != null)
                                        New Product Sub Category Log
                                    @endif
                                </h3>

                                <p class="text-sm mt-3">{{ $unseenNotification->content }}</p>

                                <div class="text-sm text-muted">
                                    <i class="far fa-clock"></i>
                                    {{ $unseenNotification->created_at->format('d-m-Y h:i a') }}
                                </div>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-divider"></div>
                @endforeach

                @if ($totalUnseenNotificationCount <= 0)
                    <a class="dropdown-item dropdown-footer disabled">
                        You have no unseen notification
                    </a>
                @endif

                <a href="{{ route('merchant.notification.index') }}" class="dropdown-item dropdown-footer">
                    See All Notifications
                </a>
            </div>


        <li class="nav-item dropdown">
            <a data-toggle="dropdown" href="#" class="nav-link">
                <i class="fas fa-user"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href="{{ route('merchant.subscription.index') }}">
                    Subscription
                </a>
                <a class="dropdown-item" href="{{ route('merchant.profile.index') }}">
                    Account Setting
                </a>
                <a class="dropdown-item" href="{{ route('merchant.shop.index') }}">
                    Shop Setting
                </a>
                <a class="dropdown-item" href="{{ route('logout') }}"
                    onclick="event.preventDefault(); $('#logout-form').submit();">
                    {{ __('Logout') }}
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST">
                    @csrf
                </form>
            </div>
        </li>
    </ul>
</nav>
