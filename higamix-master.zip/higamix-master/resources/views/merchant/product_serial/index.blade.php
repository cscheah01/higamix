@extends('merchant/layout/layout')

@section('page_title', 'Product Stock')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Stock</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Stock</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <button type="button" class="btn btn-warning mr-1" onclick="openExportModal()">
                            Export
                        </button>
                        <a type="button" class="btn btn-success" href="{{ route('merchant.product_serial.create') }}">
                            Add Stock
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-product-name">Product Name</label>
                            <input type="search" id="filter-product-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-order-id">Order ID</label>
                            <input type="search" id="filter-order-id" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6">
                        <div class="form-group">
                            <label for="filter-key">Key</label>
                            <input type="search" id="filter-key" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-is-sold">Status</label>
                            <select class="form-control" id="filter-is-sold">
                                <option value="">All</option>
                                <option value="0">Available</option>
                                <option value="1">Sold</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form')">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Key</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>


    <div class="modal fade" id="expoort-product-serial-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Export Product Stock</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" target="_blank" action="{{ route('merchant.product_serial.export') }}"
                        id="export-product-serial-form">
                        @csrf

                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label for="product_id">Product</label>
                            </div>
                            <div class="col-12 col-md-8 input-wrapper">
                                <select class="form-control" id="product_id" name="product_id" style="width: 100%;"
                                    required></select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label for="is_sold_all">Status</label>
                            </div>
                            <div class="col-12 col-md-8 input-wrapper">
                                <div class="d-flex">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="is_sold_all" name="is_sold"
                                            value="null" onchange="onChangeExportProductSerialStatus()" required>
                                        <label for="is_sold_all" class="custom-control-label mr-4">All</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="unsold" name="is_sold"
                                            value="0" onchange="onChangeExportProductSerialStatus()" required>
                                        <label for="unsold" class="custom-control-label mr-4">Unsold</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="sold" name="is_sold"
                                            value="1" onchange="onChangeExportProductSerialStatus()" required>
                                        <label for="sold" class="custom-control-label">Sold</label>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="form-group row">
                            <div class="col-12 col-md-4">
                                <label for="is_export_all">Export Range</label>
                            </div>
                            <div class="col-12 col-md-8 input-wrapper">
                                <div class="d-flex">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="is_export_all"
                                            name="is_export_all" value="1" onchange="onChangeExportRange()"
                                            required>
                                        <label for="is_export_all" class="custom-control-label mr-4">All Stock</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="is_not_export_all"
                                            name="is_export_all" value="0" onchange="onChangeExportRange()"
                                            required>
                                        <label for="is_not_export_all" class="custom-control-label">Custom
                                            Quantity</label>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="form-group row d-none" id="export-quantity-wrapper">
                            <div class="col-12 col-md-4">
                                <label for="quantity">Export Quantity</label>
                            </div>
                            <div class="col-12 col-md-8 input-wrapper">
                                <input type="number" min="1" class="form-control" id="quantity" name="qty"
                                    required />
                            </div>
                        </div>

                        <div class="form-group row d-none" id="delete-after-export-wrapper">
                            <div class="col-12 col-md-4">
                                <label for="no_delete_after_export">Delete After Export</label>
                            </div>
                            <div class="col-12 col-md-8 input-wrapper">
                                <div class="d-flex">
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="no_delete_after_export"
                                            name="delete_after_export" value="0" required>
                                        <label for="no_delete_after_export" class="custom-control-label mr-4">No</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input" type="radio" id="delete_after_export"
                                            name="delete_after_export" value="1" required>
                                        <label for="delete_after_export" class="custom-control-label">Yes</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="export-product-serial-form" class="btn btn-primary"
                        onclick="onSubmitExport()">
                        Export
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#export-product-serial-form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.product_serial.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";

                        var filters = {
                            orderId: $("#filter-order-id").val(),
                        };

                        data.order_id = filters.orderId;
                    }
                },
                columns: [{
                        data: "product_name",
                        name: "products.name"
                    },
                    {
                        data: "serial_number",
                        name: "serial_number"
                    },
                    {
                        data: "is_sold",
                        width: "100px",
                        name: "is_sold",
                        className: "text-center",
                        render: function(data, type, row) {
                            if (data == true) {
                                return `<span class="badge badge-danger">Sold</span>
                                <div>
                                    ${row.order_product_is_resell ? "Agent Sales " : ""}
                                    Order ID: #${row.order_product_order_id}
                                </div>
                                `;
                            } else {
                                return '<span class="badge badge-primary">Available</span>';
                            }
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                          ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.product_serial.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var deleteUrl =
                                `{{ route('merchant.product_serial.destroy', ['id' => ':id']) }}`;
                            deleteUrl = deleteUrl.replace(':id', data.id);


                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <form method="post" action="${deleteUrl}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteProductSerial(event)" ${data.is_sold == true ? 'disabled' : ''}>
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [3, "desc"]
                ],
            });

            deleteProductSerial = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    productName: $("#filter-product-name").val(),
                    isSold: $("#filter-is-sold").val(),
                    key: $("#filter-key").val(),
                };

                $table.column(0).search(filters.productName);
                $table.column(1).search(`\\b${filters.key}\\b`, true, false);
                $table.column(2).search(filters.isSold);
                $table.draw();
            });

            $("#product_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Product',
                ajax: {
                    url: "{{ route('merchant.product.serial_product.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });
        });

        function onChangeExportRange() {
            let isExportAll = $("input[name='is_export_all']:checked").val();

            if (isExportAll == true) {
                $("#export-quantity-wrapper").addClass("d-none");
            } else {
                $("#export-quantity-wrapper").removeClass("d-none");
            }
        }

        function onChangeExportProductSerialStatus() {
            let isSold = $("input[name='is_sold']:checked").val();

            if (isSold == false) {
                $("#delete-after-export-wrapper").removeClass("d-none");
            } else {
                $("#delete-after-export-wrapper").addClass("d-none");
            }
        }

        function openExportModal() {
            resetForm("#export-product-serial-form");

            $("#export-quantity-wrapper").addClass("d-none");
            $("#delete-after-export-wrapper").addClass("d-none");
            $('#expoort-product-serial-modal').modal('show');
        }

        function onSubmitExport() {
            $('#expoort-product-serial-modal').modal('hide');
        }
    </script>
@endsection
