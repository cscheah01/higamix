@extends('merchant/layout/layout')

@section('page_title', 'Product Stock - Serial Key Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Stock - Serial Key Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Stock - Serial Key Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('merchant.product_serial.index') }}">
                                Back
                            </a>
                            <form method="post"
                                action={{ route('merchant.product_serial.destroy', ['id' => $productSerial->id]) }}>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="deleteProductSerial(event)"
                                    {{ $productSerial->is_sold == true ? 'disabled' : '' }}>
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">General Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Product Name:</label>
                </div>
                <div class="col-12 col-md-9">
                    {{ $productSerial->product->name }}
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    {{ $productSerial->product->price }}
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Serial Key:</label>
                </div>
                <div class="col-12 col-md-9">
                    <span class="mr-2" id="serial_number">{{ $productSerial->serial_number }}</span>
                    <button class="btn btn-primary" id="btn-copy-serial-number" onclick="copySerialNumber()">Copy</button>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Status:</label>
                </div>
                <div class="col-12 col-md-9 vertical-align-center">
                    @if ($productSerial->is_sold)
                        <span class="badge badge-danger">sold</span>

                        {{ $productSerial->order_product->is_resell ? 'Agent Sales ' : '' }}Order ID:
                        #{{ $productSerial->order_product->order_id }}
                    @else
                        <span class="badge badge-primary">Available</span>
                    @endif
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Created At:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $productSerial->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            deleteProductSerial = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });

        function copySerialNumber() {
            var serialNumber = $("#serial_number").text();
            navigator.clipboard.writeText(serialNumber);

            $("#btn-copy-serial-number").removeClass("btn-primary");
            $("#btn-copy-serial-number").addClass("btn-success");
            $("#btn-copy-serial-number").text("Copied!");
        }
    </script>
@endsection
