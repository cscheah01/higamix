@php
use App\Enums\StockDelimiterType;
@endphp

@extends('merchant/layout/layout')

@section('page_title', 'Add Serial Product Stock')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Add Serial Product Stock</h1>
                    <h4 class="m-0 d-block d-sm-none">Add Serial Product Stock</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('merchant.product_serial.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('merchant.product_serial.store') }}" method="post">
            @csrf

            <div class="card-body">
                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="product_id">Product Name</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="product_id" name="product_id" style="width: 100%;"
                            required></select>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="serials_list">Serials List</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <textarea class="form-control" name="serials" id="serials" rows="4" required></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label for="stock_delimiter_type">Stock Delimiter</label>
                    </div>
                    <div class="col-md-5 col-xl-4 input-wrapper">
                        <select class="form-control" id="stock_delimiter_type" name="stock_delimiter_type"
                            onchange="changeStockDelimiterType()" required>
                            @foreach ($stockDelimiterTypes as $stockDelimiterType)
                                <option value="{{ $stockDelimiterType['value'] }}"
                                    {{ $loop->index == 0 ? 'selected' : null }}>
                                    {{ $stockDelimiterType['description'] }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3 col-xl-4">
                        <div class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox" id="remove_duplicate_serials"
                                name="remove_duplicate_serials" value="1">

                            <label for="remove_duplicate_serials" class="custom-control-label">Remove duplicate serials
                                <i class="fa-solid fa-circle-exclamation" data-toggle="tooltip" data-placement="top"
                                    title="This will remove duplicated serials on the above input."></i></label>
                        </div>
                    </div>
                </div>
                <div id="custom-delimiter-wrapper" class="d-none">
                    <div class="form-group row">
                        <div class="col-md-3">
                            <label for="custom_delimiter">Custom Stock Delimiter</label>
                        </div>
                        <div class="col-md-5 col-xl-4 input-wrapper">
                            <input type="text" class="form-control" name="custom_delimiter" id="custom_delimiter"
                                required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Add
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });
            $('[data-toggle="tooltip"]').tooltip();

            $("#product_id").select2({
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Product',
                ajax: {
                    url: "{{ route('merchant.product.serial_product.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });
        });

        function changeStockDelimiterType() {
            var stockDelimiterType = $('#stock_delimiter_type').val();

            $('#custom-delimiter-wrapper').addClass('d-none');

            if (stockDelimiterType == "{{ StockDelimiterType::Custom }}") {
                $('#custom-delimiter-wrapper').removeClass('d-none');
            }
        }
    </script>
@endsection
