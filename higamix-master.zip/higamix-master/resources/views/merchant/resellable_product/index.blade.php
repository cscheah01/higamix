@extends('merchant/layout/layout')

@section('page_title', 'Search Resell Product')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Search Resell Product</h1>
                    <h4 class="m-0 d-block d-sm-none">Search Resell Product</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <label for="filter-selection">Search By</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <select class="form-control" id="filter-selection" onchange="resetFilterInput()">
                                <option value="agent_connect_code" data-target-column="0">Agent Connect Code</option>
                                <option value="product_name" data-target-column="2">Product Name</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <input type="search" id="filter-input" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form')">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Shop Name</th>
                        <th>Product Name</th>
                        <th>Product Type</th>
                        <th>Resell Cost Price (USDT)</th>
                        <th>Suggested Min Resell Price (USDT)</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="create-resell-product-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Resell Product</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="create-resell-form">
                        @csrf

                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="name">Product Name</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Product Name" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label>Resell Cost Price (USDT)</label>
                            </div>
                            <div class="col-md-9 col-xl-7">
                                <span id="display-resell-cost-price"></span>
                                <input type="hidden" id="resell-cost-price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label>Suggested Min Resell Price (USDT)</label>
                            </div>
                            <div class="col-md-9 col-xl-7">
                                <span id="display-suggested-min-resell-price"></span>
                                <input type="hidden" id="suggested_min_resell_price">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="price">Price</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <div class="input-group">
                                    <div class="input-group-append">
                                        <span class="input-group-text">USDT</span>
                                    </div>
                                    <input type="number" step="0.01" class="form-control input-price" id="price"
                                        name="price" placeholder="Resell Price" onchange="checkSuggestedPrice()" required>
                                </div>
                                <div class="alert alert-warning d-none mt-2" id="suggested-price-alert">
                                    The suggested minimum resell price is USDT <span
                                        id="display-alert-suggested-price"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="product_category_id">Product Category</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="product_category_id" name="product_category_id"
                                    style="width: 100%;" onchange="resetSubcategory()" required></select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="product_sub_category_id">Product Sub Category</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="product_sub_category_id" name="product_sub_category_id"
                                    style="width: 100%;"></select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-5">
                                <label for="discord_bot_id">Discord Bot</label>
                            </div>
                            <div class="col-md-9 col-xl-7 input-wrapper">
                                <select class="form-control" id="discord_bot_id" name="discord_bot_id"
                                    style="width: 100%;"></select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" form="create-resell-form" class="btn btn-success">
                        Resell
                    </button>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(function() {
            $('#create-resell-form').validate({
                rules: {
                    price: {
                        greaterOrEqual: '#resell-cost-price',
                    },
                },
                messages: {
                    price: {
                        greaterOrEqual: "This field must be equal or more than resell cost price.",
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });


            $('#table').DataTable({
                aasorting: [],
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.resellable_product.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    },
                },
                deferLoading: {{ auth()->user()->is_verified ? 'null' : 0 }},
                columns: [{
                        data: "shops_agent_connect_code",
                        name: "shops.agent_connect_code",
                        visible: false,
                    },
                    {
                        data: null,
                        name: "shop_name",
                        orderable: false,
                        render: function(data, type, row) {
                            var url =
                                `{{ route('merchant.shop.search_shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        data: "name",
                        name: "name",
                        orderable: false,
                    },
                    {
                        data: "product_type",
                        name: "product_type",
                        orderable: false,
                    },
                    {
                        className: "dt-body-right",
                        data: "resell_cost_price",
                        name: "resell_cost_price",
                        orderable: false,
                    },
                    {
                        className: "dt-body-right",
                        data: "suggested_min_resell_price",
                        name: "suggested_min_resell_price",
                        orderable: false,
                    },
                    {
                        data: null,
                        width: "180px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('merchant.resellable_product.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var resellUrl =
                                `{{ route('merchant.resell_product.store', ['id' => ':id']) }}`;
                            resellUrl = resellUrl.replace(':id', data.id);

                            var shopId = {{ $shopId }};

                            return `
                            <div class="d-flex">
                                <a class="btn btn-success mr-2" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <button type="button" class="btn btn-primary" ${data.shop_id ==  shopId || data.parent_product_shop_id == shopId  ? 'disabled' : '' } onclick="openCreateResellProductModal('${resellUrl}','${data.suggested_min_resell_price}','${data.resell_cost_price}')">
                                    Resell Product
                                </button>
                            </div>

                            `;
                        }
                    },
                ],
            });

            $('#product_category_id').select2({
                dropdownParent: $('#create-resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Category',
                ajax: {
                    url: "{{ route('merchant.product_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#product_sub_category_id").select2({
                dropdownParent: $('#create-resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Sub Category',
                ajax: {
                    url: "{{ route('merchant.product_sub_category.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            product_main_category_id: $('#product_category_id').val(),
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#discord_bot_id").select2({
                dropdownParent: $('#create-resell-product-modal'),
                theme: "bootstrap4",
                allowClear: true,
                placeholder: 'Search & Select Discord Bot',
                ajax: {
                    url: "{{ route('merchant.discord_bot.select_search') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        var query = {
                            search_term: params.term,
                            page: params.page,
                        }
                        return query;
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data.results, function(item) {
                                return {
                                    text: item.username,
                                    id: item.id
                                }
                            }),
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    }
                }
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var target = $('#filter-selection').val();

                var targetColumn = $("#filter-selection option:selected").data("target-column");

                var filters = {
                    input: $("#filter-input").val(),
                };
                if (filters.input == "") {
                    $table.column('0').search('^$', true, false);
                } else if (targetColumn == 0) {
                    $table.column('0').search(`\\b${filters.input}\\b`, true, false);
                    $table.column('2').search("");
                } else if (targetColumn == 2) {
                    $table.column('2').search(filters.input);
                    $table.column('0').search("");
                }
                $table.draw();
            })

            $('#price').change(function() {
                this.value = parseFloat(this.value).toFixed(2);
            });
        });

        function resetSubcategory() {
            $("#product_sub_category_id").empty();
        }

        function resetFilterInput() {
            $("#filter-input").val(null);
        }

        function openCreateResellProductModal(resellUrl, suggestedMinResellPrice, resellCostPrice) {
            $('#create-resell-product-modal').modal('show');
            $('#price').attr('value', suggestedMinResellPrice);
            $('#display-suggested-min-resell-price').html(suggestedMinResellPrice);
            $('#display-resell-cost-price').html(resellCostPrice);
            $('#suggested_min_resell_price').attr('value', suggestedMinResellPrice);
            $('#resell-cost-price').attr('value', resellCostPrice);
            $('#create-resell-form').attr('action', resellUrl);
            $('#display-alert-suggested-price').html(suggestedMinResellPrice);
        }

        function checkSuggestedPrice() {
            var price = $('#price').val();
            var suggestedPrice = $('#suggested_min_resell_price').val();

            if (parseFloat(price).toFixed(2) >= suggestedPrice) {
                $('#suggested-price-alert').addClass('d-none');
            } else {
                $('#suggested-price-alert').removeClass('d-none');
            }
        }
    </script>
@endsection
