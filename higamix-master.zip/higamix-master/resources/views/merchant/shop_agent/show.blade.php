@extends('merchant/layout/layout')

@section('page_title', 'Agent Resell Product Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Agent Resell Product Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Agent Resell Product Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('merchant.shop_agent.index') }}">
                                Back
                            </a>
                            <form method="post" action={{ route('merchant.shop_agent.update', ['id' => $shopAgent->id]) }}>
                                @csrf
                                @method('PATCH')

                                <input type="hidden" name="is_approved" value="0">

                                <div class="d-flex">
                                    <button type="submit" class="btn btn-danger" onclick="removeAgent(event)">
                                        Remove
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-6 mb-3">
                    <label>Shop Name:</label>
                    <div>
                        <a href="{{ route('merchant.shop.search_shop.show', ['id' => $shopAgent->agent->id]) }}">
                            {{ $shopAgent->agent->name }}</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 mb-3">
                    <label>Created At:</label>
                    <div>
                        {{ $shopAgent->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Resell Product</h5>
            </div>
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Product Name</th>
                        <th>Product Price (USDT)</th>
                        <th>Created At</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.resell_product.shop_agent.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "shop_id",
                        name: "shop_id",
                        visible: false
                    },
                    {
                        data: "name",
                        name: "name"
                    },
                    {
                        className: "dt-body-right",
                        data: "price",
                        name: "price"
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                          ${createdAt}
                        `;
                        }
                    },
                ],
                order: [
                    [3, "desc"]
                ],
                searchCols: [{
                        search: {{ $shopAgent->agent_shop_id }},
                    },
                    null,
                    null,
                    null,
                ],

            });

            removeAgent = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to remove?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, remove it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>
@endsection
