@extends('merchant/layout/layout')

@section('page_title', 'Edit Agent Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Edit Agent Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Edit Agent Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-primary" href="{{ route('merchant.shop_agent.setting.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form id="form" action="{{ route('merchant.shop_agent.setting.update') }}" method="post">
                @csrf
                @method('PATCH')
                <div class="form-group row">
                    <label for="agent_connect_code" class="col-sm-4 col-form-label">Connect Code</label>
                    <div class="col-sm-8 input-wrapper">
                        <div class="input-wrapper">
                            <input type="text" class="form-control" id="agent_connect_code" name="agent_connect_code"
                                value="{{ $shop['agent_connect_code'] }}" placeholder="Connect Code" required>
                        </div>

                        <button type="button" class="btn btn-primary mt-2" onclick="generateCode()">
                            Generate
                        </button>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Approval</label>
                    <div class="col-sm-8 input-wrapper align-self-center">
                        <div class="d-flex">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_allow_agent_direct_connect"
                                    id="allow_agent_direct_connect" value="1"
                                    @if ($shop['is_allow_agent_direct_connect'] == 1) checked @endif>
                                <label for="allow_agent_direct_connect" class="custom-control-label mr-4">No Need
                                    Approval</label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" name="is_allow_agent_direct_connect"
                                    id="disallow_agent_direct_connect" value="0"
                                    @if ($shop['is_allow_agent_direct_connect'] == 0) checked @endif>
                                <label for="disallow_agent_direct_connect" class="custom-control-label">Need
                                    Approval</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class='col-sm-4'>
                        <label for="general_description" class="col-form-label">Shop General Description</label>
                        <i class="fa-solid fa-circle-exclamation" data-toggle="tooltip" data-placement="top"
                            title="This field is use to describe what type of product that your shop is selling."></i></label>
                    </div>


                    <div class="col-sm-8 input-wrapper">
                        <textarea class="form-control" name="general_description" id="general_description" rows="4">{{ $shop['general_description'] }}</textarea>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-sm-right">
                <button type="submit" form="form" class="btn btn-success">
                    Save Edit
                </button>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();

            $('#form').validate({
                rules: {
                    agent_connect_code: {
                        required: true,
                        minlength: 8,
                        maxlength: 36
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });
        });

        function generateCode() {
            $('#agent_connect_code').val(uuidv4());
        }
    </script>
@endsection
