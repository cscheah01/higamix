@extends('merchant/layout/layout')

@section('page_title', 'Agent Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Agent Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Agent Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-primary" href="{{ route('merchant.shop_agent.setting.edit') }}">
                            Edit
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-4">
                    <label>Connect Code</label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        <span class="mr-2" id="connect-code">{{ $shop['agent_connect_code'] }}</span>
                        <button class="btn btn-primary" id="btn-copy-connect-code" onclick="copyConnectCode()">Copy</button>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-4">
                    <label>Approval</label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        @if ($shop['is_allow_agent_direct_connect'] == 1)
                            <span class="badge badge-primary">No Need Approval</span>
                        @elseif ($shop['is_allow_agent_direct_connect'] == 0)
                            <span class="badge badge-warning">Need Approval</span>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-4">
                    <label>Shop General Description</label>
                    <i class="fa-solid fa-circle-exclamation" data-toggle="tooltip" data-placement="top"
                        title="This field is use to describe what type of product that your shop is selling."></i></label>
                </div>
                <div class="col-12 col-md-8">
                    <div>
                        {{ $shop['general_description'] ?? '-' }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })

        function copyConnectCode() {
            var ConnectCode = $("#connect-code").text();
            navigator.clipboard.writeText(ConnectCode);

            $("#btn-copy-connect-code").removeClass("btn-primary");
            $("#btn-copy-connect-code").addClass("btn-success");
            $("#btn-copy-connect-code").text("Copied!");
        }
    </script>
@endsection
