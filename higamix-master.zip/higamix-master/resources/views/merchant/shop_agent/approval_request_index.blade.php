@extends('merchant/layout/layout')

@section('page_title', 'Shop Agent Approval List')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Agent Approval List</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Agent Approval List</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-shop-name">Shop Name</label>
                            <input type="search" id="filter-shop-name" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Shop Name</th>
                        <th>Requested At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('merchant.shop_agent.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "is_waiting_approved",
                        name: "is_waiting_approved",
                        visible: false
                    },
                    {
                        data: null,
                        name: "shops.name",
                        orderable: false,
                        render: function(data, type, row) {
                            var url =
                                `{{ route('merchant.shop.search_shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        width: "150px",
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var UpdateUrl =
                                `{{ route('merchant.shop_agent.update', ['id' => ':id']) }}`;
                            UpdateUrl = UpdateUrl.replace(':id', data.id);

                            return `
                            <div class="d-flex">
                                <form method="post" action=" ${UpdateUrl}">
                                    @csrf
                                    @method('PATCH')

                                    <div class="d-flex">
                                        <input type="hidden" name="is_approved" id="is_approved">
                                        <button type="submit" class="btn btn-success mr-1" onclick="approveAgent(event)">
                                            Approve
                                        </button>
                                        <button type="submit" class="btn btn-danger" onclick="rejectAgent(event)">
                                            Reject
                                        </button>
                                    </div>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
                searchCols: [{
                        search: 1,
                    },
                    null,
                    null,
                    null,
                ],
            });


            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    shopName: $("#filter-shop-name").val(),
                };

                $table.column(1).search(filters.shopName);
                $table.draw();
            })

            approveAgent = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to approve this request?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#is_approved').val(1);
                        $(e.target).closest('form').submit();
                    }
                })
            };

            rejectAgent = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to reject this request?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, reject it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#is_approved').val(0);
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>
@endsection
