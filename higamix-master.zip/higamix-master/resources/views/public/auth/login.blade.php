@extends('public/layout/layout')

@section('page_title', 'Login')
@section('page_id', 'login')
@section('og:title', 'HiGamix | Login')

@section('content')
    <div class="row justify-content-center align-items-center py-5" id="auth-content-wrapper">
        <div class="col-6 d-none d-md-block px-4">
            <img src="{{ asset('img/higamix-authentication.png') }}" alt="HiGamix e-commerce digital product selling platform"
                class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-md-6 px-md-5">
            <div class="border shadow rounded p-4 bg-white">

                <h1>Login</h1>
                <span>Don't have an account? <a class="font-weight-bold" href="{{ route('register.index') }}">Create an
                        account</a></span>

                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-3">
                        <span>{{ Session::get('error') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @elseif (session('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-3">
                        <span>{{ Session::get('success') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="mt-3">
                    <form id="form" method="POST" action="{{ route('login.request') }}">
                        @csrf

                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Email" required autofocus name="email"
                                value="{{ old('email') }}">

                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-envelope"></span>
                                </div>
                            </div>
                        </div>

                        <div class="input-group mb-3">
                            <input type="password" class="form-control" placeholder="Password" required name="password">

                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-8">
                                <a class="font-weight-bold" href="{{ route('forgot_password.index') }}">I forgot my
                                    password</a>
                            </div>
                            <div class="col-4">
                                <button type="submit" class="btn btn-primary btn-block">Login</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
@endsection
