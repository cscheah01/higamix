@extends('public/layout/layout')

@section('page_title', 'Register')
@section('page_id', 'register')
@section('og:title', 'HiGamix | Register')


@section('content')
    <div class="row justify-content-center align-items-center py-5" id="auth-content-wrapper">
        <div class="col-6 d-none d-md-block px-4">
            <img src="{{ asset('img/higamix-authentication.png') }}" alt="HiGamix e-commerce digital product selling platform"
                class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-md-6 px-md-5">
            <div class="border shadow rounded p-4 bg-white">

                <h1>Register</h1>
                <span>Already have an account? <a class="font-weight-bold" href="{{ route('login.index') }}">Login
                        account</a></span>


                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-3">
                        <span>{{ Session::get('error') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="mt-3">
                    <form id="form" method="POST" action="{{ route('register.request') }}">
                        @csrf


                        <div class="form-group">
                            <label for="user-email">Email</label>
                            <input type="email" class="form-control" id="user-email" name="user[email]"
                                value="{{ old('user.email') }}" placeholder="email" required>
                        </div>

                        <div class="form-group">
                            <label for="user-password">Password</label>
                            <input type="password" class="form-control" id="user-password" name="user[password]"
                                placeholder="Password" required>
                        </div>
                        <div class="form-group">
                            <label for="user-password_confirmation">Confirm Password</label>
                            <input type="password" class="form-control" id="user-password_confirmation"
                                name="user[password_confirmation]" placeholder="Confirm Password" required>
                        </div>

                        <div class="form-group">
                            <label for="shop-name">Shop Name</label>
                            <input type="text" class="form-control" id="shop-name" name="shop[name]"
                                value="{{ old('shop.name') }}" placeholder="Shop Name" required>
                        </div>

                        <div class="form-group">
                            <label for="invite_code">Invite Code</label>
                            <input type="text" class="form-control" id="invite_code" name="invite_code"
                                value="{{ old('invite_code') }}" placeholder="Invite Code" required>
                        </div>



                        <div class="row">
                            <div class="col">

                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary btn-block px-5">Register</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    'user[password]': {
                        required: true,
                        minlength: 8
                    },
                    'user[password_confirmation]': {
                        required: true,
                        equalTo: "#user-password"
                    }
                },
                messages: {
                    'user[password_confirmation]': {
                        equalTo: "Password not match."
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
@endsection
