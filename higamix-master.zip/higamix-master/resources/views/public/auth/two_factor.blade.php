@extends('public/layout/layout')

@section('page_title', 'Two Factor Authentication')
@section('page_id', 'two-factor-authentication')


@section('content')
    <div class="row justify-content-center align-items-center py-5" id="auth-content-wrapper">
        <div class="col-6 d-none d-md-block px-4">
            <img src="{{ asset('img/higamix-authentication.png') }}"
                alt="HiGamix e-commerce digital product selling platform" class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-md-6 px-md-5">
            <div class="border shadow rounded p-4 bg-white">

                <span>
                    <a class="font-weight-bold" href="{{ route('logout') }}"
                        onclick="event.preventDefault(); $('#logout-form').submit();">
                        <i class="fas fa-long-arrow-alt-left"></i> Change Account
                    </a>
                </span>
                <form id="logout-form" action="{{ route('logout') }}" method="POST">
                    @csrf
                </form>


                <h1 class="mt-3">Two Factor</h1>


                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-3">
                        <span>{{ Session::get('error') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="mt-3">
                    <form id="form" method="POST" action="{{ route('two_factor.attemp') }}">
                        @csrf

                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="code" placeholder="2FA Code" required
                                autofocus>
                        </div>


                        <div class="row">
                            <div class="col-8"></div>
                            <div class="col-4">
                                <button type="submit" class="btn btn-primary btn-block">Login</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
@endsection
