@extends('public/layout/layout')

@section('page_title', 'Forgot Password')
@section('page_id', 'forgot-password')
@section('og:title', 'HiGamix | Forgot Password')

@section('content')
    <div class="row justify-content-center align-items-center py-5" id="auth-content-wrapper">
        <div class="col-6 d-none d-md-block px-4">
            <img src="{{ asset('img/higamix-authentication.png') }}" alt="HiGamix e-commerce digital product selling platform"
                class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-md-6 px-md-5">
            <div class="border shadow rounded p-4 bg-white">

                <div class="row">
                    <div class="col-12">
                        <h1>Reset Your Password</h1>
                        <span>We will send you an email to reset your password</span>
                    </div>
                </div>

                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-3">
                        <span>{{ Session::get('error') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @elseif (session('success'))
                    <div class="alert alert-success alert-dismissible fade show mt-3">
                        <span>{{ Session::get('success') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="mt-3">
                    <form id="form" method="POST" action="{{ route('forgot_password.request') }}">
                        @csrf

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="email"
                                required>
                        </div>

                        <div class="row">
                            <div class="col">
                                <a class="font-weight-bold" href="{{ route('login.index') }}">
                                    <i class="fas fa-arrow-left mr-2"></i>login</a>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary btn-block px-5">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
@endsection
