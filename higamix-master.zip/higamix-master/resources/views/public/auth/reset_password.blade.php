@extends('public/layout/layout')

@section('page_title', 'Reset Password')
@section('page_id', 'reset-password')


@section('content')
    <div class="row justify-content-center align-items-center py-5" id="auth-content-wrapper">
        <div class="col-6 d-none d-md-block px-4">
            <img src="{{ asset('img/higamix-authentication.png') }}"
                alt="HiGamix e-commerce digital product selling platform" class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-md-6 px-md-5">
            <div class="border shadow rounded p-4 bg-white">

                <div class="row">
                    <div class="col-12">
                        <h1>Reset Password</h1>
                    </div>
                </div>

                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show mt-3">
                        <span>{{ Session::get('error') }}</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="mt-3">
                    <form id="form" method="POST" action="{{ route('reset_password.request') }}">
                        @csrf

                        <input type="hidden" name="token" value="{{ Request::route('token') }}">
                        <input type="hidden" name="email" value="{{ Request::route('email') }}">

                        <div class="form-group">
                            <label for="user-password">Password</label>
                            <input type="password" class="form-control" id="user-password" name="password"
                                placeholder="Password" required>
                        </div>
                        <div class="form-group">
                            <label for="user-password_confirmation">Confirm Password</label>
                            <input type="password" class="form-control" id="user-password-confirmation"
                                name="password_confirmation" placeholder="Confirm Password" required>
                        </div>

                        <div class="row">
                            <div class="col">
                                <a class="font-weight-bold" href="{{ route('login.index') }}">
                                    <i class="fas fa-arrow-left mr-2"></i>login</a>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary btn-block px-5">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    'password': {
                        required: true,
                        minlength: 8
                    },
                    'password_confirmation': {
                        required: true,
                        equalTo: "#user-password"
                    }
                },
                messages: {
                    'password_confirmation': {
                        equalTo: "Password not match."
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
@endsection
