@extends('public/layout/layout')

@section('page_title', 'page name')


@section('content')

@endsection


@section('script')
    <script>
        $(function() {

        });
    </script>
@endsection
