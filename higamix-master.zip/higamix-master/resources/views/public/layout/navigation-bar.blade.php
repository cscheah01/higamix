<nav class="navbar navbar-light navbar-expand position-fixed w-100 px-md-5" id="top-nav-bar">
    <a class="navbar-brand" href="{{ route('home') }}">
        <img src="{{ asset('img/logo-horizontal-higamix.png') }}" height="30" alt="HiGamix horizontal logo"
            class="d-inline-block align-top">
    </a>

    <ul class="navbar-nav ml-auto d-none d-sm-flex">
        @auth
            @role('admin')
                <li class="nav-item pr-2">
                    <a class="btn btn-primary rounded-pill" href="{{ route('admin.dashboard') }}"><i
                            class="fas fa-home mr-2"></i>Staff Portal</a>
                </li>
                @elserole('merchant')
                <li class="nav-item pr-2">
                    <a class="btn btn-primary rounded-pill" href="{{ route('merchant.dashboard') }}"><i
                            class="fas fa-home mr-2"></i>Merchant Portal</a>
                </li>
            @endrole

            <li class="nav-item">
                <a class="btn btn-outline-primary rounded-pill"
                    onclick="event.preventDefault(); $('#logout-form').submit();">Logout</a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST">
                    @csrf
                </form>
            </li>
        @endauth

        @guest
            <li class="nav-item pr-2">
                <a class="btn btn-outline-primary rounded-pill" href="{{ route('login.index') }}">Login</a>
            </li>
            <li class="nav-item">
                <a class="btn btn-primary rounded-pill" href="{{ route('register.index') }}">Register</a>
            </li>
        @endguest
    </ul>

    <ul class="navbar-nav ml-auto d-sm-none">
        <li class="nav-item">
            <button class="btn btn-primary rounded-circle" onclick="toggleMobileNavigation()"><i
                    class="fas fa-bars"></i></button>
        </li>
    </ul>
</nav>

<div class="bg-white h-100 w-100 position-fixed p-3 d-none animate__animated animate__fadeInRight"
    id="mobile-navigation">
    <div>
        <img src="{{ asset('img/logo-horizontal-higamix.png') }}" alt="HiGamix horizontal logo" height="30">
        <button class="btn btn-primary rounded-circle float-right" onclick="toggleMobileNavigation()"><i
                class="fas fa-times"></i></button>
    </div>

    <div class="mt-4 h-100 overflow-auto d-flex align-items-center">
        <ul class="navbar-nav text-center w-100">
            @auth
                @role('admin')
                    <li class="nav-item mb-3">
                        <a class="btn btn-primary rounded-pill" href="{{ route('admin.dashboard') }}"><i
                                class="fas fa-home mr-2"></i>Staff Portal</a>
                    </li>
                    @elserole('merchant')
                    <li class="nav-item mb-3">
                        <a class="btn btn-primary rounded-pill" href="{{ route('merchant.dashboard') }}"><i
                                class="fas fa-home mr-2"></i>Merchant Portal</a>
                    </li>
                @endrole

                <li class="nav-item">
                    <a class="btn btn-outline-primary rounded-pill"
                        onclick="event.preventDefault(); $('#logout-form').submit();">Logout</a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST">
                        @csrf
                    </form>
                </li>
            @endauth

            @guest
                <li class="nav-item mb-3">
                    <a class="btn btn-outline-primary rounded-pill" href="{{ route('login.index') }}">Login</a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-primary rounded-pill" href="{{ route('register.index') }}">Register</a>
                </li>
            @endguest
        </ul>
    </div>
</div>
