<footer class="border-top">
    <div class="row text-center text-md-left px-2 px-lg-5 pt-5">

        <div class="col-12 col-md-4">
            <img src="{{ asset('img/logo-horizontal-higamix.png') }}" alt="HiGamix horizontal logo" class="mb-3"
                style="width:100%; max-width: 300px;">

            <div class="ml-2">
                <p>Higamix is an e-commerce platform that let everyone to sell digital goods online in a secure and
                    modern environment.</p>
            </div>
        </div>

        <div class="col-12 col-md-4 text-center mt-5 mt-md-0">
            <h5 class="font-weight-bold mb-4">NAVIGATION</h5>

            <ul class="list-unstyled">
                <li>
                    <a href="{{ route('home') }}" class="w-100">Home</a>
                </li>
            </ul>
        </div>

        <div class="col-12 col-md-4 text-center mt-5 mt-md-0">
            <h5 class="font-weight-bold mb-4">LET'S JOIN US</h5>

            <a class="btn btn-primary btn-lg rounded-pill" href="{{ route('register.index') }}">Start
                Selling</a>
        </div>

        <div class="col-12 pt-5 pb-3">
            <div class="footer-copyright text-center">
                <span><strong>© {{ now()->year }} HiGamix All Right Reserved.</strong></span>
            </div>
        </div>
    </div>
</footer>
