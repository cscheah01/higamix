<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:locale" content="@yield('og:locale', 'en_US')" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="@yield('og:title', 'HiGamix | Digital Goods Selling Platform')" />
    <meta property="og:description" content="@yield('og:description', 'Higamix is an e-commerce platform, let everyone to sell digital goods online. We provide automated delivery for the serial key product.')" />
    <meta property="og:url" content="@yield('og:url', Request::url())" />
    <meta property="og:site_name" content="@yield('og:site_name', 'HiGamix')" />
    <meta property="og:image" content="@yield('og:image', asset('img/higamix-open-graph-logo.png'))" />
    <meta property="og:image:width" content="@yield('og:image:width', '1200')" />
    <meta property="og:image:height" content="@yield('og:image:height', '630')" />
    <meta property="og:image:type" content="@yield('og:image:type', 'image/png')" />

    <title>@yield('page_title') | HiGamix</title>
    <meta name="description" content="@yield('description', 'Higamix is an e-commerce platform, let everyone to sell digital goods online. We provide automated delivery for the serial key product.')" />

    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('img/favicon.png') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
</head>

<body class="bg-white public-layout" id="@yield('page_id')">
    <div class="spinner-wrapper d-none">
        <div class="spinner">
            <div class="spinner-circle spinner-circle-outer"></div>
            <div class="spinner-circle-off spinner-circle-inner"></div>
            <div class="spinner-circle spinner-circle-single-1"></div>
            <div class="spinner-circle spinner-circle-single-2"></div>
        </div>
    </div>

    @include('public/layout/navigation-bar')

    <div class="container-fluid px-md-5" id="main-container">
        @yield('content')

        @if (Request::routeIs('home'))
            @include('public/layout/footer')
        @endif
    </div>

    @if (!Request::routeIs('home'))
        <div class="container-fluid">
            @include('public/layout/footer')
        </div>
    @endif

    <script type="text/javascript" src="{{ asset('js/app.js') }}"></script>

    @yield('script')
    <script>
        @if (Session::has('success_confirm'))
            Swal.fire({
                title: '{!! Session::get('success_confirm') !!}',
                icon: 'success',
            })
        @elseif (session('error_confirm'))
            Swal.fire({
                title: '{!! Session::get('error_confirm') !!}',
                icon: 'error',
            })
        @endif

        function toggleMobileNavigation() {
            if ($("#mobile-navigation").hasClass("d-none")) {
                $("#mobile-navigation").removeClass("d-none");

                $("body").css("overflow-y", "hidden");
            } else {
                $("#mobile-navigation").addClass("d-none");

                $("body").css("overflow-y", "auto");
            }
        }

        $(window).on('resize', function() {
            if ($(this).width() >= 576) {
                $("#mobile-navigation").addClass("d-none");

                $("body").css("overflow-y", "auto");
            }
        });
    </script>
</body>

</html>
