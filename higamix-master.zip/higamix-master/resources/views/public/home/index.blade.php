@extends('public/layout/layout')

@section('page_title', 'Digital Goods Selling')
@section('page_id', 'home')


@section('content')
    <div class="row align-items-center min-vh-100" id="banner-section">
        <div class="col-12 col-sm-6 order-1 order-sm-0 opacity-0" id="banner-column-1">
            <h1 class="mb-3 text-primary font-weight-bolder" id="banner-title">Digital Goods <br>Selling Platform</h1>
            <p class="mb-4 mb-sm-5">
                HiGamix is an E-Commerce platform that let everyone to sell digital goods online <br
                    class="d-none d-xl-block">in a secure and modern
                environment.
            </p>
            <a class="btn btn-primary btn-lg rounded-pill font-weight-bolder shadow opacity-0" id="banner-start-selling-btn"
                href="{{ route('register.index') }}">Start Selling</a>
        </div>
        <div class="col-12 col-sm-6 order-0 order-sm-1 text-center mb-5 mb-sm-0 opacity-0" id="banner-column-2">
            <img src="{{ asset('img/higamix-ecommerce-banner.png') }}" alt="HiGamix e-commerce platform banner"
                draggable="false" id="top-banner-image">
            <img src="{{ asset('img/higamix-wheel-gear.png') }}" alt="HiGamix e-commerce platform wheel gear icon"
                draggable="false" class="position-absolute rotate" id="top-banner-wheel-gear-1">
            <img src="{{ asset('img/higamix-wheel-gear.png') }}" alt="HiGamix e-commerce platform wheel gear icon"
                draggable="false" class="position-absolute rotate" id="top-banner-wheel-gear-2">
        </div>
    </div>

    <div class="text-center" id="product-type-section">
        <h2 class="text-primary font-weight-bolder title opacity-0" id="product-type-title">Support Several Types <br
                class="d-lg-none">of Digital Product
        </h2>

        <div class="row mt-5">
            <div class="col-12 col-md-6 mb-3 mb-md-0 opacity-0" id="product-type-column-1">
                <div class="bg-primary py-5 rounded-lg">
                    <img src="{{ asset('img/higamix-service-product-type-icon.png') }}"
                        alt="HiGamix e-commerce services product" draggable="false">
                    <div class="mt-5">
                        <h3 class="font-weight-bolder">Services</h3>
                        <p>Boost your creativity and selling directly on a <br>secure, and reliable platform</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 opacity-0" id="product-type-column-2">
                <div class="py-5 rounded-lg" style="background-color: #7DA1FF">
                    <img src="{{ asset('img/higamix-serials-product-type-icon.png') }}"
                        alt="HiGamix e-commerce serials product" draggable="false">
                    <div class="mt-5">
                        <h3 class="text-white font-weight-bolder">Serials</h3>
                        <p class="text-white">Sell license keys, activation codes, serials key <br>and
                            etc</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row align-items-center min-vh-100" id="automated-selling-process-section">
        <div class="col-12 col-sm-6 text-center mb-5 mb-sm-0 opacity-0" id="automated-selling-process-column-1">
            <img src="{{ asset('img/higamix-automated-selling-process.png') }}" alt="HiGamix automated selling process"
                draggable="false" id="automated-selling-process-banner">
            <img src="{{ asset('img/higamix-wheel-gear.png') }}" alt="HiGamix e-commerce platform wheel gear icon"
                draggable="false" class="position-absolute rotate" id="automated-selling-process-banner-wheel-gear-1">
            <img src="{{ asset('img/higamix-wheel-gear.png') }}" alt="HiGamix e-commerce platform wheel gear icon"
                draggable="false" class="position-absolute rotate" id="automated-selling-process-banner-wheel-gear-2">
        </div>
        <div class="col-12 col-sm-6 opacity-0" id="automated-selling-process-column-2">
            <h2 class="mb-3 text-primary font-weight-bolder title">Automated <br>Selling Process</h2>
            <p>
                HiGamix provides instant automated delivery of goods for the serial key product when your customer makes
                an
                order.
            </p>
            <p>
                No need worries to decide which serial key to assign anymore! Just update the product stock and let
                our system handle it for you.
            </p>
        </div>
    </div>


    <div class="row align-items-center min-vh-100" id="cryptocurrency-payment-transaction-section">
        <div class="col-12 col-sm-6 order-1 order-sm-0 opacity-0" id="cryptocurrency-payment-transaction-column-1">
            <h2 class="mb-3 text-primary font-weight-bolder title">Cryptocurrency <br>Payment Transactions</h2>
            <p>
                We provide you with a simple solution for selling your digital goods with cryptocurrency.
            </p>

            <div class="row text-center mt-5">
                <div class="col-12 col-xl-4 mb-4 mb-xl-0 opacity-0" id="cryptocurrency-payment-transaction-subcolumn-1">
                    <div class="shadow rounded-lg p-4 bg-white">
                        <img class="mb-3" src="{{ asset('img/higamix-fast-transactions-icon.png') }}"
                            alt="HiGamix fast cryptocurrency payment transactions" draggable="false">
                        <h4 class="font-weight-bold">Fast <br>Transactions</h4>
                    </div>
                </div>
                <div class="col-12 col-xl-4 mt-xl-5 mb-4 mb-xl-0 opacity-0"
                    id="cryptocurrency-payment-transaction-subcolumn-2">
                    <div class="shadow rounded-lg p-4 bg-white">
                        <img class="mb-3" src="{{ asset('img/higamix-low-transaction-fee-icon.png') }}"
                            alt="HiGamix low cryptocurrency transactions fee" draggable="false">
                        <h4 class="font-weight-bold">Low <br>Transactions Fee</h4>
                    </div>
                </div>
                <div class="col-12 col-xl-4 mb-4 mb-xl-0 opacity-0" id="cryptocurrency-payment-transaction-subcolumn-3">
                    <div class="shadow rounded-lg p-4 bg-white">
                        <img class="mb-3" src="{{ asset('img/higamix-secure-icon.png') }}"
                            alt="HiGamix highly secure cryptocurrency payment" draggable="false">
                        <h4 class="font-weight-bold">More <br>Security</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 order-0 order-sm-1 text-center mb-5 mb-sm-0 opacity-0"
            id="cryptocurrency-payment-transaction-column-2">
            <img src="{{ asset('img/higamix-cryptocurrency-payment-transaction.png') }}"
                alt="HiGamix e-commerce cryptocurrecy payment" draggable="false"
                id="cryptocurrency-payment-transaction-banner">
        </div>
    </div>


    <div id="become-reseller-section" class="opacity-0">
        <div class="text-center bg-blue-linear-gradient rounded-lg p-3 py-5 p-sm-5 text-white">
            <h2 class="mb-3 font-weight-bolder title">Becoming a Reseller</h2>
            <p>
                Our resells product feature offers you the opportunity to become a reseller and start your own online
                business.
            </p>

            <div class="row mt-5 text-center">
                <div class="col-12 col-md-6 mb-3 mb-md-0 opacity-0" id="become-reseller-column-1">
                    <div class="bg-white p-5 rounded-lg">
                        <div class="bg-primary p-4 rounded-circle d-inline-flex mb-4" style="max-width: 100px">
                            <img src="{{ asset('img/higamix-resell-icon.png') }}" alt="HiGamix resell feature"
                                class="w-100" draggable="false">
                        </div>
                        <h4 class="mb-3 text-primary font-weight-bolder">Resell other products <br
                                class="d-none d-md-block">on the
                            platform</h4>
                    </div>
                </div>
                <div class="col-12 col-md-6 opacity-0" id="become-reseller-column-2">
                    <div class="bg-white p-5 rounded-lg">
                        <div class="bg-primary p-4 rounded-circle d-inline-flex mb-4" style="max-width: 100px">
                            <img src="{{ asset('img/higamix-customize-price-icon.png') }}"
                                alt="HiGamix customize resell product price" class="w-100" draggable="false">
                        </div>
                        <h4 class="mb-3 text-primary font-weight-bolder">Customize the resell <br
                                class="d-none d-md-block">product price</h4>
                    </div>
                </div>
            </div>

            <a class="btn btn-light btn-lg mt-5 rounded-pill font-weight-bolder shadow opacity-0"
                id="become-reseller-get-started-btn" href="{{ route('register.index') }}">Get Started</a>
        </div>
    </div>

    <div class="row align-items-center min-vh-100" id="notification-section">
        <div class="col-12 col-sm-6 text-center mb-5 mb-sm-0 opacity-0" id="notification-column-1">
            <img src="{{ asset('img/higamix-phone.png') }}" alt="HiGamix notification through application"
                draggable="false" id="notification-banner">
        </div>
        <div class="col-12 col-sm-6 opacity-0" id="notification-column-2">
            <h2 class="mb-3 text-primary font-weight-bolder title">Notification <br>Through Application</h2>
            <p>
                You will get notified when the product you resell has changed.
            </p>

            <div class="row mt-5 opacity-0" id="notification-row-1">
                <div class="col-12 col-sm-auto mb-3">
                    <div class="bg-primary p-4 rounded-circle d-inline-flex w-100" style="max-width: 100px">
                        <img src="{{ asset('img/higamix-notification-icon.png') }}" alt="HiGamix notification icon"
                            class="w-100" draggable="false">
                    </div>
                </div>
                <div class="col-12 col-sm-8">
                    <h3 class="mb-3 text-primary font-weight-bolder">Mobile and Desktop Notifications</h3>
                    <p>
                        Receive notifications on your personal Discord server and product owner's Telegram group.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row align-items-center min-vh-100" id="third-part-integration-section">
        <div class="col-12 col-sm-6 order-1 order-sm-0 opacity-0" id="third-part-integration-column-1">
            <h2 class="mb-3 text-primary font-weight-bolder title">Support Third-Party <br>Platform Integration</h2>
            <p class="mb-4 mb-sm-5">
                We allow the shop's owner to integrate with their platform via our system API. Our API allows you to
                connect
                your store in our platform and sell it on your own platform.
            </p>
            <a class="btn btn-primary btn-lg rounded-pill opacity-0" target="_blank"
                href="{{ route('docs.api') }}" id="third-part-integration-view-api-doc-btn">View
                API Documentation</a>
        </div>
        <div class="col-12 col-sm-6 order-0 order-sm-1 text-center mb-5 mb-sm-0 opacity-0"
            id="third-part-integration-column-2">
            <img src="{{ asset('img/higamix-third-party-integration.png') }}" alt="HiGamix API integration"
                draggable="false" id="third-part-integration-banner">
        </div>
    </div>

    <div class="row align-items-center min-vh-100" id="platform-commission-section">
        <div class="col-12 col-sm-6 text-center mb-5 mb-sm-0 opacity-0" id="platform-commission-column-1">
            <img src="{{ asset('img/higamix-platform-commission.png') }}" alt="HiGamix low platform commission fee"
                draggable="false" id="platform-commission-banner">
        </div>
        <div class="col-12 col-sm-6 opacity-0" id="platform-commission-column-2">
            <h2 class="mb-3 text-primary font-weight-bolder title">Low Platform <br>Commission Fee</h2>
            <p>
                HiGamix is more encourages people to do business online. We help all the sellers by charging a modest
                platform charge.
            </p>
        </div>
    </div>

    <div class="opacity-0" id="cta-section">
        <div class="text-center rounded-lg shadow-lg p-3 py-5 p-sm-5 bg-blue-linear-gradient text-white">
            <h2 class="mb-3 font-weight-bolder title">Ready to start selling?</h2>
            <p>Launch your business online, it is free to selling digital product at HiGamix!</p>
            <a class="btn btn-light btn-lg mt-5 rounded-pill text-primary font-weight-bolder shadow opacity-0"
                id="cta-start-selling-btn" href="{{ route('register.index') }}">Start
                Selling</a>
        </div>
    </div>
@endsection


@section('script')
    <script>
        $(function() {
            var controller = new ScrollMagic.Controller();

            new ScrollMagic.Scene({
                    triggerElement: "body",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#banner-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#banner-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#banner-start-selling-btn").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);
                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#product-type-section",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#product-type-title").addClass(
                            "animate__animated animate__fadeIn"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#product-type-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#product-type-column-2").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#automated-selling-process-section",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#automated-selling-process-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#automated-selling-process-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);

                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#cryptocurrency-payment-transaction-section",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#cryptocurrency-payment-transaction-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#cryptocurrency-payment-transaction-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);


                    i++;
                    setTimeout(function() {
                        $("#cryptocurrency-payment-transaction-subcolumn-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#cryptocurrency-payment-transaction-subcolumn-2").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#cryptocurrency-payment-transaction-subcolumn-3").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#become-reseller-section",
                    triggerHook: 0.8,
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#become-reseller-section").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    i++;
                    setTimeout(function() {
                        $("#become-reseller-column-1").addClass(
                            "animate__animated animate__fadeInLeft"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#become-reseller-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);

                    i++;
                    i++;
                    setTimeout(function() {
                        $("#become-reseller-get-started-btn").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#notification-section",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#notification-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#notification-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);


                    i++;
                    i++;
                    setTimeout(function() {
                        $("#notification-row-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#third-part-integration-section",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#third-part-integration-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#third-part-integration-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#third-part-integration-view-api-doc-btn").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);
                })
                .addTo(controller);


            new ScrollMagic.Scene({
                    triggerElement: "#platform-commission-section",
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#platform-commission-column-1").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    setTimeout(function() {
                        $("#platform-commission-column-2").addClass(
                            "animate__animated animate__fadeInRight"
                        );
                    }, delay * i);

                })
                .addTo(controller);

            new ScrollMagic.Scene({
                    triggerElement: "#cta-section",
                    triggerHook: 0.8,
                })
                .on("enter", function() {
                    var delay = 500;
                    var i = 0;

                    setTimeout(function() {
                        $("#cta-section").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                    i++;
                    i++;
                    setTimeout(function() {
                        $("#cta-start-selling-btn").addClass(
                            "animate__animated animate__fadeInUp"
                        );
                    }, delay * i);

                })
                .addTo(controller);
        });
    </script>
@endsection
