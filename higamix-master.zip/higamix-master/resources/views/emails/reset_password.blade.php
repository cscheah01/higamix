@component('mail::message')
# Hello!

You are receiving this email because we received a password reset request for your account.

@component('mail::button', ['url' => route('reset_password.index', ['token' => $data['token'], 'email' => $data['email']])])
    Reset Password
@endcomponent

This password reset link will expire in {{ $data['expired_minutes'] }} minutes.
If you did not request a password reset, no further action is required

Regards,<br>
{{ config('app.name') }}

<hr style="margin:24px 0px;">

If you're having trouble clicking the "Reset Password" button, copy and paste the URL below into your web
browser:<a>{{ route('reset_password.index', ['token' => $data['token'], 'email' => $data['email']]) }}</a>
@endcomponent
