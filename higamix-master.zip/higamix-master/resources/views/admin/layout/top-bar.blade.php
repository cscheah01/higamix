<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button" onclick="SidebarToggle()">
                <i class="fas fa-bars"></i>
            </a>

            <script>
                function SidebarToggle() {
                    $.ajax({
                        type: "POST",
                        url: "{{ route('sidebar.save_state') }}",
                        data: {
                            _token: "{{ csrf_token() }}"
                        }
                    })
                }
            </script>
        </li>
    </ul>

    <h4 class="mt-2 ml-md-3 text-primary font-weight-bold text-center text-md-left w-100">Staff Portal</h4>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a data-toggle="dropdown" href="#" class="nav-link">
                <i class="fas fa-user"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href="{{ route('admin.profile.index') }}">
                    Account Setting
                </a>
                <a class="dropdown-item" href="{{ route('logout') }}"
                    onclick="event.preventDefault(); $('#logout-form').submit();">
                    {{ __('Logout') }}
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST">
                    @csrf
                </form>
            </div>
        </li>
    </ul>
</nav>
