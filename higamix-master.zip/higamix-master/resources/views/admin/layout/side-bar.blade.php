<aside class="main-sidebar sidebar-light-main elevation-4 position-fixed">
    <div class="brand-link">
        <img src="{{ asset('img/logo-higamix.png') }}" class="brand-image img-circle elevation-3 bg-white p-1"
            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">


        <a href="{{ route('admin.dashboard') }}">
            <div class="brand-text"><img class="sidebar-horizontal-logo" src="{{ asset('img/logo-text-higamix.png') }}"
                    onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'"></div>
        </a>
    </div>

    <div class="sidebar" style="margin-top: 57px; height: calc(100vh - 57px);">
        <nav class="mt-2 pb-4">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-item">
                    <a href="{{ route('admin.dashboard') }}"
                        class="nav-link {{ Request::routeIs('admin.dashboard') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-home"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.wallet_withdrawal_request.index') }}"
                        class="nav-link {{ Request::routeIs('admin.wallet_withdrawal_request.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-money-bill"></i>
                        <p>
                            Withdrawal Request
                        </p>
                    </a>
                </li>
                <li class="nav-item {{ Request::routeIs('admin.account_verify_request.*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-address-card"></i>
                        <p>
                            Account Verification
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('admin.account_verify_request.index') }}"
                                class="nav-link  {{ Request::routeIs('admin.account_verify_request.index') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Verify Request
                                </p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('admin.account_verify_request.rejected.index') }}"
                                class="nav-link  {{ Request::routeIs('admin.account_verify_request.rejected.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Rejected List
                                </p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.platform_order.index') }}"
                        class="nav-link {{ Request::routeIs('admin.platform_order.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-file-invoice"></i>
                        <p>
                            Platform Order
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.merchant.index') }}"
                        class="nav-link {{ Request::routeIs('admin.merchant.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            Merchant
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.wallet.index') }}"
                        class="nav-link {{ Request::routeIs('admin.wallet.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-wallet"></i>
                        <p>
                            Merchant Wallet
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.shop.index') }}"
                        class="nav-link {{ Request::routeIs('admin.shop.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-store"></i>
                        <p>
                            Shop
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.shop_agent.index') }}"
                        class="nav-link {{ Request::routeIs('admin.shop_agent.*') ? 'active' : '' }}">
                        <i class="fas fa-user-friends nav-icon"></i>
                        <p>
                            Shop Agent
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.product.index') }}"
                        class="nav-link {{ Request::routeIs('admin.product.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-box-archive"></i>
                        <p>
                            Product
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.platform_commission_transaction.index') }}"
                        class="nav-link {{ Request::routeIs('admin.platform_commission_transaction.*') ? 'active' : '' }}">
                        <i class="fa fa-money-check-dollar nav-icon"></i>
                        <p>
                            Commission Transaction
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.staff.index') }}"
                        class="nav-link {{ Request::routeIs('admin.staff.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-user-tie"></i>
                        <p>
                            Staff
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.invite_code.index') }}"
                        class="nav-link  {{ Request::routeIs('admin.invite_code.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-link"></i>
                        <p>
                            Invite Code
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('admin.login_history.index') }}"
                        class="nav-link  {{ Request::routeIs('admin.login_history.*') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-history"></i>
                        <p>
                            Login History
                        </p>
                    </a>
                </li>

                <li
                    class="nav-item {{ Request::routeIs('admin.platform_setting.*') || Request::routeIs('admin.withdrawal_transaction_fee_setting.*') ? 'menu-open' : '' }}">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-gear"></i>
                        <p>
                            Setting
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('admin.platform_setting.index') }}"
                                class="nav-link {{ Request::routeIs('admin.platform_setting.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Platform Setting
                                </p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="{{ route('admin.withdrawal_transaction_fee_setting.index') }}"
                                class="nav-link {{ Request::routeIs('admin.withdrawal_transaction_fee_setting.*') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>
                                    Withdrawal Fee Setting
                                </p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
