<footer class="main-footer text-center">
    <strong>© {{ now()->year }} HiGamix All Right Reserved.</strong>
</footer>
