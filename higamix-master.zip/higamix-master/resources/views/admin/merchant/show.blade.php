@extends('admin/layout/layout')

@section('page_title', 'Merchant Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Merchant Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Merchant Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.merchant.index') }}">
                            Back
                        </a>
                        <a class="btn btn-primary" href="{{ route('admin.merchant.edit', ['id' => $merchant->id]) }}">
                            Edit
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Email:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $merchant->email }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Name:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.shop.show', ['id' => $merchant->shop->id]) }}">
                            {{ $merchant->shop->name }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Telegram Channel Link:</label>
                </div>
                <div class="col-12 col-md-10">
                    @if ($merchant->shop->telegram_channel_url != null)
                        <a href="{{ $merchant->shop->telegram_channel_url }}" target="_blank">
                            {{ $merchant->shop->telegram_channel_url }}
                        </a>
                    @else
                        <div>
                            -
                        </div>
                    @endif
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Two Factor Authentication:</label>
                </div>
                <div class="col-12 col-md-10">
                    @if ($merchant->is_enabled_two_factor == true)
                        <span class="badge badge-success">Enabled</span>
                    @else
                        <span class="badge badge-danger">Disabled</span>
                    @endif
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Is Verified:</label>
                </div>
                <div class="col-12 col-md-5">
                    @if ($merchant->is_verified == true)
                        <span class="badge badge-success">Verified</span>
                    @elseif ($merchant->is_verified == false)
                        <span class="badge badge-warning">Non-Verified</span>
                    @endif

                </div>
                <div class="col-12 col-md-5">
                    <div class="d-flex float-right">
                        <form method="post"
                            action="{{ route('admin.merchant.account_verify.update', ['id' => $merchant->id]) }}">
                            @csrf
                            @method('PATCH')
                            <input type="hidden" name="is_verified" value="{{ $merchant->is_verified == true ? 0 : 1 }}" />
                            <button type="submit"
                                class="btn {{ $merchant->is_verified == true ? 'btn-danger' : 'btn-success' }} "
                                onclick="changeAccountVerify(event)">
                                {{ $merchant->is_verified == true ? 'Unverified Account' : 'Verify Account' }}
                            </button>
                        </form>
                    </div>
                </div>


                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Register At:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $merchant->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row align-items-center">
                <div class="col-12">
                    <h4 class="mb-1 pt-2">Wallet Details</h4>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <h5 class="mb-3">Balance</h5>
                </div>
                <div class="col-auto">
                    <i class="fa-solid fa-wallet fa-5x"></i>
                </div>
                <div class="col-auto col-md-6">
                    <div class="row">
                        <div class="col-auto">
                            <label>USDT</label>
                            <h5>{{ $merchant->wallet->balance }}</h5>
                        </div>
                        <div class="col-auto text-muted">
                            <label>Inactive Balance</label>
                            <h5>{{ $merchant->wallet->inactive_balance }}</h5>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="my-3">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Wallet Transaction</h5>
            </div>
            <table id="wallet-transaction-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Date</th>
                        <th>Debit (USDT)</th>
                        <th>Credit (USDT)</th>
                        <th>Balance (USDT)</th>
                        <th>Description</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Login History</h5>
            </div>
            <table id="login-history-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Date</th>
                        <th>IP Address</th>
                        <th>Country</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')

    <script>
        $(function() {
            $('#wallet-transaction-table').DataTable({
                infoFiltered: "",
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                language: {
                    infoFiltered: "",
                },
                ajax: {
                    url: "{{ route('admin.wallet_transaction.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }

                },
                searchCols: [{
                        search: "\\b{{ $merchant->id }}\\b",
                        regex: true
                    },
                    null,
                    null,
                    null,
                    null,
                ],
                columns: [{
                        data: "wallet_user_id",
                        name: "wallets.user_id",
                        visible: false,
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: "debit",
                        name: "debit",
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        },
                    },
                    {
                        data: "credit",
                        name: "credit",
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                    {
                        data: "balance",
                        name: "balance"
                    },
                    {
                        data: "description",
                        name: "description",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                ],
                order: [
                    [1, "desc"]
                ],
            });

            $('#login-history-table').DataTable({
                infoFiltered: "",
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                language: {
                    infoFiltered: "",
                },
                ajax: {
                    url: "{{ route('admin.login_history.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }

                },
                columns: [{
                        data: "user_id",
                        name: "user_id",
                        visible: false
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: "ip_address",
                        name: "ip_address"
                    },
                    {
                        data: "country",
                        name: "country"
                    },
                ],
                order: [
                    [1, "desc"]
                ],
                searchCols: [{
                        search: "\\b{{ $merchant->id }}\\b",
                        regex: true
                    },
                    null,
                    null,
                    null,
                ],
            });
            changeAccountVerify = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to change the account verify status?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, change it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>

@endsection
