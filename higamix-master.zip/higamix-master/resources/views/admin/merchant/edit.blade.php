@extends('admin/layout/layout')

@section('page_title', 'Edit Merchant')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Edit Merchant</h1>
                    <h4 class="m-0 d-block d-sm-none">Edit Merchant</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.merchant.show', ['id' => $merchant->id]) }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form id="form" action="{{ route('admin.merchant.update', ['id' => $merchant->id]) }}" method="post">
                @csrf
                @method('PATCH')

                <div class="form-group row">
                    <label for="email" class="col-sm-12 col-form-label">Email</label>
                    <div class="col-sm-12 input-wrapper">
                        <input type="email" class="form-control" id="email" name="email"
                            value="{{ $merchant['email'] }}" placeholder="Email" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-sm-12 col-form-label">New Password</label>
                    <div class="col-sm-12 input-wrapper">
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="New Password">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="password_confirmation" class="col-sm-12 col-form-label">Confirm New Password</label>
                    <div class="col-sm-12 input-wrapper">
                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation"
                            placeholder="Confirm New Password">
                    </div>
                </div>

            </form>
            <div class="form-group row">
                <label class="col-sm-3 col-form-label">Two-factor Authentication</label>
                <div class="col-sm-9 input-wrapper align-self-center">
                    <div class="row">
                        @if ($merchant['is_enabled_two_factor'] == true)
                            <div class="d-flex">
                                <div>
                                    <span class="badge badge-primary mr-2">Enabled</span>
                                </div>
                                <div>
                                    <form
                                        action="{{ route('admin.two_factor.user.disable', ['userId' => $merchant->id]) }}"
                                        method="post">
                                        @csrf
                                        @method('PATCH')
                                        <div class="form-group">
                                            <input type="hidden" name="is_enabled_two_factor" value="0" />
                                            <button type="submit" class="btn btn-danger"
                                                onclick="disableTwoFactor(event)">Disable</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        @elseif ($merchant['is_enabled_two_factor'] == false)
                            <span class="badge badge-secondary mr-2">Disabled</span>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="float-sm-right">
                <button type="submit" form="form" class="btn btn-success">
                    Save Edit
                </button>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    'password': {
                        required: false,
                        minlength: 8
                    },
                    'password_confirmation': {
                        required: false,
                        equalTo: "#password"
                    }
                },
                messages: {
                    'password_confirmation': {
                        equalTo: "Password not match."
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })

            disableTwoFactor = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to disable?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, disable it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }
        });
    </script>
@endsection
