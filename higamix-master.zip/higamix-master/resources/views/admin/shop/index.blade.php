@extends('admin/layout/layout')

@section('page_title', 'Shop')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-name">Name</label>
                            <input type="search" id="filter-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-merchant-email">Merchant Email</label>
                            <input type="search" id="filter-merchant-email" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Merchant Email</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.shop.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "name",
                        name: "name"
                    },
                    {
                        data: null,
                        name: "users.email",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.user_id);

                            return `
                             <a href="${url}">
                                ${data.user_email}
                            </a>`;
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var editUrl =
                                `{{ route('admin.shop.edit', ['id' => ':id']) }}`;
                            editUrl = editUrl.replace(':id', data.id);

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <a class="btn btn-primary mr-1" href="${editUrl}">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
            });


            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    shopName: $("#filter-name").val(),
                    merchantEmail: $("#filter-merchant-email").val(),
                };

                $table.column(0).search(filters.shopName);
                $table.column(1).search(filters.merchantEmail);
                $table.draw();
            });
        });
    </script>
@endsection
