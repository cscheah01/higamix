@extends('admin/layout/layout')

@section('page_title', 'Shop Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.shop.index') }}">
                            Back
                        </a>
                        <a class="btn btn-primary" href="{{ route('admin.shop.edit', ['id' => $shop->id]) }}">
                            Edit
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Shop Logo:</label>
                </div>
                <div class="col-12">
                    <div class="img-wrap mx-auto mb-4 border img-circle shadow">
                        <img id="logo-preview" class="img"
                            src="{{ $shop['logo_image'] != null ? url('storage/shop_logo/' . $shop['logo_image']) : asset('img/empty-image.png') }}"
                            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Name:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $shop->name }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Merchant Email:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.merchant.show', ['id' => $shop->user->id]) }}">
                            {{ $shop->user->email }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Telegram Channel Link:</label>
                </div>
                <div class="col-12 col-md-10">
                    @if ($shop->telegram_channel_url != null)
                        <a href="{{ $shop->telegram_channel_url }}" target="_blank">
                            {{ $shop->telegram_channel_url }}
                        </a>
                    @else
                        <div>
                            -
                        </div>
                    @endif
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop General Description:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $shop->general_description ?? '-' }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Description:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div class="ql-container ql-snow" style="min-height:150px;">
                        <div class="ql-editor">{!! $shop['description'] !!}</div>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Agent Connect Code:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <span id="agent-connect-code">{{ $shop->agent_connect_code }}</span>
                        <button class="btn btn-primary ml-2" id="btn-copy-agent-connect-code"
                            onclick="copyAgentConnectCode()">Copy</button>
                    </div>
                </div>

                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Created At:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $shop->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

        });

        function copyAgentConnectCode() {
            var agentConnectCode = $("#agent-connect-code").text();
            navigator.clipboard.writeText(agentConnectCode);

            $("#btn-copy-agent-connect-code").removeClass("btn-primary");
            $("#btn-copy-agent-connect-code").addClass("btn-success");
            $("#btn-copy-agent-connect-code").text("Copied!");
        }
    </script>

@endsection
