@extends('admin/layout/layout')

@section('page_title', 'Edit Merchant Shop Profile')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Edit Merchant Shop Profile</h1>
                    <h4 class="m-0 d-block d-sm-none">Edit Merchant Shop Profile</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.shop.index', ['id' => $shop->id]) }}}">
                            Back
                        </a>
                        <button type="submit" form="form" class="btn btn-success">
                            Save Edit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <label>Shop Details</label>
        </div>
        <div class="card-body">
            <form id="form" action="{{ route('admin.shop.update', ['id' => $shop->id]) }}" method="post"
                enctype="multipart/form-data">
                @csrf
                @method('PATCH')
                <div class="img-wrap mx-auto mb-4 border img-circle shadow">
                    <img id="logo-preview" class="img"
                        data-initial-image="{{ $shop['logo_image'] != null ? url('storage/shop_logo/' . $shop['logo_image']) : asset('img/empty-image.png') }}"
                        src="{{ $shop['logo_image'] != null ? url('storage/shop_logo/' . $shop['logo_image']) : asset('img/empty-image.png') }}"
                        onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                </div>
                <div class="form-group row">
                    <div class="col-sm-2 col-form-label">
                        <label for="logo_image">Shop Logo</label>
                    </div>
                    <div class="col-sm-10">
                        <div class="input-wrapper input-group">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="logo_image" name="logo_image"
                                    accept=".png,.jpeg,.jpg">
                                <input type="hidden" name="remove_image" id="remove_image" value="0">
                                <label class="custom-file-label" id="logo_image_label" for="logo_image">
                                    @if ($shop['logo_image'] != null)
                                        {{ $shop['logo_image'] }}
                                    @else
                                        Choose file
                                    @endif
                                </label>
                            </div>
                            <button type="button"
                                class="btn btn-danger ml-2 {{ $shop['logo_image'] == null ? 'd-none' : '' }} "
                                id="remove-image-btn" onclick="removeImage()">Remove</button>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="email" class="col-sm-2 col-form-label">Merchant Email</label>
                    <div class="col-sm-10 input-wrapper">
                        <input type="text" class="form-control" value="{{ $shop->user->email }}" disabled>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label">Shop Name</label>
                    <div class="col-sm-10 input-wrapper">
                        <input type="text" class="form-control" id="name" name="name" value="{{ $shop['name'] }}"
                            placeholder="Shop Name" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class='col-sm-2'>
                        <label for="general_description" class="col-form-label">Shop General Description</label></label>
                    </div>


                    <div class="col-sm-10 input-wrapper">
                        <textarea class="form-control" name="general_description" id="general_description" rows="4">{{ $shop['general_description'] }}</textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="description" class="col-sm-2 col-form-label">Shop Description</label>
                    <div class="col-sm-10 input-wrapper">
                        <div id="description-editor" class="h-auto ql-editor-box">
                        </div>
                        <input type="hidden" name="description" id="description" value="{{ $shop['description'] }}">
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $("#logo_image").change(function() {
                const file = this.files[0];
                if (file) {
                    $('#remove_image').val(0);
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        $("#logo-preview")
                            .attr("src", event.target.result);
                        $("#remove-image-btn").removeClass("d-none");
                    };
                    reader.readAsDataURL(file);
                } else {
                    var initialImage = $("#logo-preview").data("initial-image");

                    $("#logo-preview")
                        .attr("src", initialImage);
                    $("#remove-image-btn").addClass("d-none");
                }
            });

            var quill = new Quill('#description-editor', {
                modules: _quillEditorModules,
                placeholder: 'Write shop description...',
                theme: 'snow',
            });
            quill.root.innerHTML = $("#description").val();
            quill.on('text-change', function(delta, oldDelta, source) {
                $("#description").val(quill.root.innerHTML);
            });
        });

        function removeImage() {
            $('#remove_image').val(0);
            if (!$("#logo_image").val()) {
                $("#logo-preview").data("initial-image", "{{ asset('img/empty-image.png') }}")
                $('#remove_image').val(1);
                $("#logo_image_label").text("Choose file");
                $("#remove-image-btn").addClass("d-none");
            }
            if ($("#logo-preview").data("initial-image") != "{{ asset('img/empty-image.png') }}") {
                $("#logo_image_label").text("{{ $shop['logo_image'] }}");
            }
            $("#logo_image").val('');
            var initialImage = $("#logo-preview").data("initial-image");
            $("#logo-preview")
                .attr("src", initialImage);
        }
    </script>
@endsection
