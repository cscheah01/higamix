@extends('admin/layout/layout')

@section('page_title', 'Withdrawal Request Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Withdrawal Request Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Withdrawal Request Details</h4>
                </div>

                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right d-flex">
                        <a class="btn btn-dark" href="{{ route('admin.wallet_withdrawal_request.index') }}">
                            Back
                        </a>
                        <button type="submit" class="btn btn-danger ml-1" data-toggle="modal"
                            data-target="#reject-withdraw-modal"
                            {{ $walletWithdrawalRequest->is_approved == true || $walletWithdrawalRequest->is_rejected == true ? 'disabled' : '' }}>
                            Reject
                        </button>
                        <form method="post"
                            action=" {{ route('admin.wallet_withdrawal_request.update', ['id' => $walletWithdrawalRequest->id]) }}">
                            @csrf
                            @method('PATCH')
                            <input type="hidden" name="is_approved" value="1" />
                            <button type="submit" class="btn btn-success ml-1" onclick="ApproveWithdrawalRequest(event)"
                                {{ $walletWithdrawalRequest->is_approved == true || $walletWithdrawalRequest->is_rejected == true ? 'disabled' : '' }}>
                                Approve
                            </button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Email</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.merchant.show', ['id' => $walletWithdrawalRequest->user->id]) }}">
                            {{ $walletWithdrawalRequest->user->email }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Name</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.shop.show', ['id' => $walletWithdrawalRequest->shop->id]) }}">
                            {{ $walletWithdrawalRequest->shop->name }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Withdrawal Request Amount (USDT)</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $walletWithdrawalRequest->amount }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Wallet Balance (USDT)</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $walletWithdrawalRequest->wallet->balance }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Request Date</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $walletWithdrawalRequest->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Status</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        @if ($walletWithdrawalRequest->is_approved == true)
                            <span class="badge badge-success">Approved</span>
                        @elseif ($walletWithdrawalRequest->is_approved == false)
                            @if ($walletWithdrawalRequest->is_rejected == true)
                                <span class="badge badge-danger">Rejected</span>
                            @elseif ($walletWithdrawalRequest->is_rejected == false)
                                <span class="badge badge-warning">Pending</span>
                            @endif
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Withdrawal Address</label>
                </div>
                <div class="col-12 col-md-10">

                    @if ($walletWithdrawalRequest->wallet->withdraw_address == null)
                        <span class="badge badge-secondary">None</span>
                    @else
                        {{ $walletWithdrawalRequest->wallet->withdraw_address }}
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="reject-withdraw-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reject reason</h5>
                </div>

                <div class="modal-body">
                    <form method="post"
                        action="{{ route('admin.wallet_withdrawal_request.update', ['id' => $walletWithdrawalRequest->id]) }}"
                        id="reject-withdraw-form">
                        @csrf
                        @method('PATCH')
                        <div class="form-group">
                            <input type="hidden" name="is_approved" value="0" />
                            <textarea class="form-control" name="remark" id="remark"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary"
                                onclick="RejectWithdrawalRequest(event)">Reject</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#reject-withdraw-form').validate({
                rules: {
                    remark: {
                        required: true
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            ApproveWithdrawalRequest = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to approve?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            RejectWithdrawalRequest = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to reject?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, reject it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>

@endsection
