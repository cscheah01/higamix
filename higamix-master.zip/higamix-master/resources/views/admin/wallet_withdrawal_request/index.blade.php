@extends('admin/layout/layout')

@section('page_title', 'Withdrawal Request List')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Withdrawal Request List</h1>
                    <h4 class="m-0 d-block d-sm-none">Withdrawal Request List</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-merchant-email">Merchant Email</label>
                            <input type="search" id="filter-merchant-email" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-shop-name">Shop Name</label>
                            <input type="search" id="filter-shop-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-from" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">Date
                                From</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-from"
                                data-target-input="nearest" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-from"
                                    data-target="#datetimepicker-date-from" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-to" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">Date
                                To</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-to"
                                data-target-input="nearest" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-to"
                                    data-target="#datetimepicker-date-to" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-status">Status</label>
                            <select class="form-control" id="filter-status">
                                <option value="">All</option>
                                <option value="1">Approved</option>
                                <option value="0">Rejected</option>
                                <option value="2">Pending</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Merchant Email</th>
                        <th>Shop Name</th>
                        <th>Request Amount (USDT)</th>
                        <th>Request Date</th>
                        <th>Status</th>
                        <th class="d-none"></th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="reject-withdraw-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reject reason</h5>
                </div>
                <form id="reject-withdraw-form" method="post">
                    <div class="modal-body">

                        @csrf
                        @method('PATCH')
                        <div class="form-group">
                            <input type="hidden" name="is_approved" value="0" />
                            <textarea class="form-control" name="remark" id="remark"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary"
                            onclick="rejectWithdrawalRequest(event)">Reject</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')

    <script>
        $(function() {
            $('.date-time-picker').datetimepicker({
                format: 'DD-MM-YYYY hh:mm A',
            });


            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.wallet_withdrawal_request.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";


                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                    }
                },
                columns: [{
                        data: null,
                        name: "users.email",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.user_id);

                            return `
                             <a href="${url}">
                                ${data.user_email}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "shops.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        className: "dt-body-right",
                        data: "amount",
                        name: "amount"
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        name: "is_approved",
                        width: "50px",
                        orderable: false,
                        className: "text-center",
                        render: function(data, type, row) {

                            if (data.is_approved == true) {

                                return `
                                <span class = "badge badge-success">
                                    Approved
                                </span>`;

                            } else if (data.is_approved == false) {

                                if (data.is_rejected == true) {
                                    return `
                                    <span class = "badge badge-danger">
                                        Rejected
                                    </span>`;

                                } else if (data.is_rejected == false) {
                                    return `
                                    <span class = "badge badge-warning">
                                        Pending
                                    </span>`;
                                }
                            }
                        }
                    },
                    {
                        data: "is_rejected",
                        name: "is_rejected",
                        visible: false
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.wallet_withdrawal_request.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var formActionUrl =
                                `{{ route('admin.wallet_withdrawal_request.update', ['id' => ':id']) }}`;
                            formActionUrl = formActionUrl.replace(':id', data.id);

                            return `
                        <div class="d-flex">
                             <a class="btn btn-success mr-1" href=" ${viewUrl}">
                                <i class="fas fa-eye"></i>
                            </a>

                                 <form method="post" class= "mr-1" action="  ${formActionUrl}">
                                    @csrf
                                    @method('PATCH')
                                    <input type="hidden" name="is_approved" value="1"/>
                                    <button type="submit" class="btn btn-primary " onclick="approveWithdrawalRequest(event)"${data.is_approved == true || data.is_rejected == true? 'disabled' : ''}>
                                        <i class="fa fa-check"></i>
                                    </button>
                                </form>

                            <button type="submit" class="btn btn-danger" onclick="rejectWithdraw(' ${formActionUrl}')"${data.is_approved == true || data.is_rejected == true? 'disabled' : ''}>
                                <i class="fa fa-x"></i>
                            </button>


                        </div>`;
                        }
                    },
                ],
                order: [
                    [3, "desc"]
                ],
            });

            rejectWithdraw = function(formActionUrl) {
                $('#reject-withdraw-modal').modal('show');
                $('#reject-withdraw-form').attr('action', formActionUrl);

            }
            $('#reject-withdraw-form').validate({
                rules: {
                    remark: {
                        required: true
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });
            approveWithdrawalRequest = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to approve?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            rejectWithdrawalRequest = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to reject?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, reject it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }
            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    merchantEmail: $("#filter-merchant-email").val(),
                    shopName: $("#filter-shop-name").val(),
                };

                if ($("#filter-status").val() != 2 && $("#filter-status").val() != '') {
                    filters.status = $("#filter-status").val();
                    filters.isRejected = 1;

                    if (filters.status == 1) {
                        filters.isRejected = 0;
                    }
                } else if ($("#filter-status").val() == 2) {
                    filters.status = 0;
                    filters.isRejected = 0;
                } else {
                    filters.status = '';
                    filters.isRejected = '';
                }
                $table.column(0).search(filters.merchantEmail);
                $table.column(1).search(filters.shopName);
                $table.column(4).search(filters.status);
                $table.column(5).search(filters.isRejected);
                $table.draw();
            });
        });
    </script>
@endsection
