@extends('admin/layout/layout')

@section('page_title', 'Rejected Account Verification')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Rejected Account Verification</h1>
                    <h4 class="m-0 d-block d-sm-none">Rejected Account Verification</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-merchant-email">Merchant Email</label>
                            <input type="search" id="filter-merchant-email" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-shop-name">Shop Name</label>
                            <input type="search" id="filter-shop-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-from" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">Date
                                From</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-from"
                                data-target-input="nearest" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-from"
                                    data-target="#datetimepicker-date-from" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-to" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">Date
                                To</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-to"
                                data-target-input="nearest" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-to"
                                    data-target="#datetimepicker-date-to" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Merchant Email</th>
                        <th>Shop Name</th>
                        <th>Request Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

@endsection

@section('script')

    <script>
        $(function() {
            $('.date-time-picker').datetimepicker({
                format: 'DD-MM-YYYY hh:mm A',
            });
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.account_verify_request.rejected.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";

                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                    }
                },
                columns: [{
                        data: null,
                        name: "users.email",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.user_id);

                            return `
                             <a href="${url}">
                                ${data.user_email}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "shops.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}`;
                        }
                    },
                    {
                        data: null,
                        width: "170px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.user_id);

                            var formActionUrl =
                                `{{ route('admin.account_verify_request.update', ['id' => ':id']) }}`;
                            formActionUrl = formActionUrl.replace(':id', data.id);

                            return `
                        <div class="d-flex">
                             <a class="btn btn-success mr-1" href="${ viewUrl}">
                                <i class="fas fa-eye"></i>
                            </a>

                                 <form method="post" class= "mr-1" action="${ formActionUrl}">
                                    @csrf
                                    @method('PATCH')
                                    <input type="hidden" name="is_approved" value="1"/>
                                    <button type="submit" class="btn btn-primary " onclick="approveAccountVerify(event)">
                                        Set as Verified
                                    </button>
                                </form>
                        </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
            });

            approveAccountVerify = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to approve?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    merchantEmail: $("#filter-merchant-email").val(),
                    shopName: $("#filter-shop-name").val(),

                };

                $table.column(0).search(filters.merchantEmail);
                $table.column(1).search(filters.shopName);
                $table.draw();
            });
        });
    </script>
@endsection
