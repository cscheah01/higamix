@extends('admin/layout/layout')

@section('page_title', 'Shop Agent Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Agent Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Agent Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.shop_agent.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Shop Name:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.shop.show', ['id' => $shopAgent->shop->id]) }}">
                            {{ $shopAgent->shop->name }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Agent Shop Name:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.shop.show', ['id' => $shopAgent->agent->id]) }}">
                            {{ $shopAgent->agent->name }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Status:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        @if ($shopAgent->is_waiting_approved == true)
                            <span class="badge badge-primary">Pending</span>
                        @elseif ($shopAgent->is_waiting_approved == false)
                            @if ($shopAgent->is_approved == true)
                                <span class="badge badge-success">Approved</span>
                            @elseif ($shopAgent->is_approved == false)
                                <span class="badge badge-danger">Rejected</span>
                            @endif
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="card mt-5">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Resell Product</h5>
            </div>
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Agent Shop Name</th>
                        <th>Product Name</th>
                        <th>Price (USDT)</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                aasorting: [],
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.resell_product.datatable', ['id' => $shopAgent->shop->id]) }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }

                },

                columns: [{
                        data: null,
                        name: "agent_shops.name",
                        orderable: false,
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.agent_shop_id);

                            return `
                             <a href="${url}">
                                ${data.agent_shop_name}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "name",
                        orderable: false,
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.product.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.id);

                            return `
                             <a href="${url}">
                                ${data.name}
                            </a>
                            `;
                        }
                    },
                    {
                        className: "dt-body-right",
                        data: "price",
                        name: "price",
                        orderable: false,
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.product.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </div>`;
                        }
                    },

                ],
            });
        });
    </script>

@endsection
