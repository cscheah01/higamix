@extends('admin/layout/layout')

@section('page_title', 'Shop Agent')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Shop Agent</h1>
                    <h4 class="m-0 d-block d-sm-none">Shop Agent</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-shop-name">Shop Name</label>
                            <input type="search" id="filter-shop-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-agent-shop-name">Agent Shop Name</label>
                            <input type="search" id="filter-agent-shop-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-status">Status</label>
                            <select class="form-control" id="filter-status">
                                <option value="">All</option>
                                <option value="1">Approved</option>
                                <option value="0">Rejected</option>
                                <option value="2">Pending</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Shop Name</th>
                        <th>Agent Shop Name</th>
                        <th>Status</th>
                        <th class="d-none"></th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.shop_agent.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: null,
                        name: "shops.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "agent.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.agent_id);

                            return `
                             <a href="${url}">
                                ${data.agent_name}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "is_approved",
                        width: "50px",
                        orderable: false,
                        className: "text-center",
                        render: function(data, type, row) {

                            if (data.is_waiting_approved == true) {
                                return ` <span class = "badge badge-primary">Pending</span>`;
                            } else if (data.is_waiting_approved == false) {
                                if (data.is_approved == true) {
                                    return ` <span class = "badge badge-success">Approved</span>`;
                                } else if (data.is_approved == false) {

                                    return ` <span class = "badge badge-danger">Rejected</span>`;
                                }
                            }
                        }

                    },
                    {
                        data: "is_waiting_approved",
                        name: "is_waiting_approved",
                        visible: false
                    },
                    {
                        data: null,
                        width: "25px",
                        orderable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.shop_agent.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);


                            return `
                                 <div class="d-flex">
                                 <a class="btn btn-success" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>
                           </div> `;
                        }
                    },

                ],
                order: [],
            });


            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    shopName: $("#filter-shop-name").val(),
                    agentShopName: $("#filter-agent-shop-name").val(),
                };


                if ($("#filter-status").val() == "") {
                    filters.status = '';
                    filters.isWaitingApproved = '';
                } else if ($("#filter-status").val() == "0" || $("#filter-status").val() == "1") {
                    filters.status = $("#filter-status").val();
                    filters.isWaitingApproved = "0";
                } else if ($("#filter-status").val() == "2") {
                    filters.status = "0";
                    filters.isWaitingApproved = "1";
                }


                $table.column(0).search(filters.shopName);
                $table.column(1).search(filters.agentShopName);
                $table.column(2).search(filters.status);
                $table.column(3).search(filters.isWaitingApproved);

                $table.draw();
            })
        });
    </script>
@endsection
