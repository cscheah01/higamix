@extends('admin/layout/layout')

@section('page_title', 'Wallet')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Merchant Wallet</h1>
                    <h4 class="m-0 d-block d-sm-none">Merchant Wallet</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-merchant-email">Merchant Email</label>
                            <input type="search" id="filter-merchant-email" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-shop-name">Shop Name</label>
                            <input type="search" id="filter-shop-name" class="form-control">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Merchant Email</th>
                        <th>Shop Name</th>
                        <th>Wallet Balance (USDT)</th>
                        <th>Withdrawal Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                order: [],
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.wallet.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: null,
                        name: "users.email",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.user_id);

                            return `
                             <a href="${url}">
                                ${data.user_email}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "shops.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        className: "dt-body-right",
                        data: "balance",
                        name: "balance"
                    },
                    {
                        data: "withdraw_address",
                        name: "withdraw_address",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.wallet.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.user_id);

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success ml-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                            </div>`;
                        }
                    },
                ],
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    merchantEmail: $("#filter-merchant-email").val(),
                    shopName: $("#filter-shop-name").val(),
                };

                $table.column(0).search(filters.merchantEmail);
                $table.column(1).search(filters.shopName);
                $table.draw();
            });
        });
    </script>
@endsection
