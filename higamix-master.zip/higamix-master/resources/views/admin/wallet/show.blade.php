@extends('admin/layout/layout')

@section('page_title', 'Wallet Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Wallet Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Wallet Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.wallet.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Merchant Email:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.merchant.show', ['id' => $wallet->user->id]) }}">
                            {{ $wallet->user->email }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Shop Name:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <a href="{{ route('admin.shop.show', ['id' => $wallet->shop->id]) }}">
                            {{ $wallet->shop->name }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Balance (USDT):</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $wallet->balance }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Inactive Balance:</label>
                </div>
                <div class="col-12 col-md-10 text-muted">
                    <div>
                        {{ $wallet->inactive_balance }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Withdrawal Address:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        @if ($wallet['withdraw_address'] == null)
                            <span class="badge badge-secondary">None</span>
                        @else
                            {{ $wallet['withdraw_address'] }}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Transaction History</h5>
            </div>
            <table id="transaction-history-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Date</th>
                        <th>Debit (USDT)</th>
                        <th>Credit (USDT)</th>
                        <th>Balance (USDT)</th>
                        <th>Description</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Request Withdrawal History</h5>
            </div>
            <table id="request-withdrawal-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Date</th>
                        <th>Amount (USDT)</th>
                        <th>Status</th>
                        <th>Remark</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#transaction-history-table').DataTable({
                infoFiltered: "",
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                language: {
                    infoFiltered: "",
                },
                ajax: {
                    url: "{{ route('admin.wallet_transaction.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }

                },
                searchCols: [{
                        search: "\\b{{ $wallet->id }}\\b",
                        regex: true
                    },
                    null,
                    null,
                    null,
                    null,
                ],
                columns: [{
                        data: "wallet_user_id",
                        name: "wallets.user_id",
                        visible: false,
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: "debit",
                        name: "debit",
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        },
                    },
                    {
                        data: "credit",
                        name: "credit",
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                    {
                        data: "balance",
                        name: "balance"
                    },
                    {
                        data: null,
                        name: "description",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data.order_id) {

                                var urlPlatformOrder =
                                    `{{ route('admin.platform_order.show', ['id' => ':id']) }}`;
                                urlPlatformOrder = urlPlatformOrder.replace(':id', data
                                    .order_id);

                                if (data.debit != null) {
                                    return `
                                        Sales order #
                                        <a href="${urlPlatformOrder}">
                                        ${data.order_id}
                                        </a>`;
                                } else {
                                    return `
                                        Purchase for order #
                                        <a href="${urlPlatformOrder}">
                                        ${data.order_id}
                                        </a>`;
                                }
                            }

                            return `${data.description}`;
                        }
                    },
                ],
                order: [
                    [1, "desc"]
                ],
            });

            $('#request-withdrawal-table').DataTable({
                infoFiltered: "",
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                language: {
                    infoFiltered: "",
                },
                ajax: {
                    url: "{{ route('admin.wallet_withdrawal_request.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                searchCols: [{
                        search: "\\b{{ $wallet->user_id }}\\b",
                        regex: true
                    },
                    null,
                    null,
                    null,
                    null,
                ],
                columns: [{
                        data: "user_id",
                        name: "users.id",
                        visible: false
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: "amount",
                        name: "amount"
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        className: "text-center",
                        render: function(data, type, row) {

                            if (data.is_approved == true && data.is_rejected == false) {
                                return ' <span class="badge badge-success">Approved</span>';
                            } else if (data.is_approved == false && data.is_rejected == true) {
                                return ' <span class="badge badge-danger">Rejected</span>';
                            } else if (data.is_approved == false && data.is_rejected == false) {
                                return ' <span class="badge badge-secondary">Pending</span>';
                            }

                        }
                    },
                    {
                        data: "remark",
                        name: "remark",
                        orderable: false,
                        render: function(data, type, row) {
                            if (data == null) {
                                return '-';
                            } else {
                                return data;
                            }
                        }
                    },
                ],
                order: [
                    [1, "desc"]
                ],
            });
        });
    </script>

@endsection
