<div class="card">
    <div class="card-body">
        <ul class="nav nav-pills nav-sidebar flex-column">
            <li class="nav-item">
                <a href="{{ route('admin.profile.index') }}" class="nav-link {{ Request::routeIs('admin.profile.index') || Request::routeIs('admin.profile.edit') ? 'active' : '' }}">
                    <p>
                        Profile
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('admin.profile.edit_password') }}" class="nav-link {{ Request::routeIs('admin.profile.edit_password') ? 'active' : '' }}">
                    <p>
                        Change Password
                    </p>
                </a>
            </li>
        </ul>
    </div>
</div>