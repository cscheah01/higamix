@extends('admin/layout/layout')

@section('page_title', 'Change Password')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Account Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Account Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-4">
            @include('admin/account_setting/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Change Password</h4>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <button type="submit" form="form" class="btn btn-success">
                                    Save Edit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form id="form" action="{{ route('admin.profile.update_password') }}" method="post">
                        @csrf
                        @method('PATCH')
                        <div class="form-group row">
                            <label for="current_password" class="col-sm-3 col-form-label">Current Password</label>
                            <div class="col-sm-9 input-wrapper">
                                <input type="password" class="form-control" id="current_password" name="current_password"
                                    placeholder="Current Password" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-sm-3 col-form-label">New Password</label>
                            <div class="col-sm-9 input-wrapper">
                                <input type="password" class="form-control" id="password" name="password"
                                    placeholder="New Password" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password_confirmation" class="col-sm-3 col-form-label">Confirm New Password</label>
                            <div class="col-sm-9 input-wrapper">
                                <input type="password" class="form-control" id="password_confirmation"
                                    name="password_confirmation" placeholder="Confirm New Password" required>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    password: {
                        required: true,
                        minlength: 8
                    },
                    password_confirmation: {
                        required: true,
                        equalTo: '#password'
                    }
                },
                messages: {
                    password_confirmation: {
                        equalTo: "Password not match."
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
        });
    </script>
@endsection
