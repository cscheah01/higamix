@extends('admin/layout/layout')

@section('page_title', 'Edit Account Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Account Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Account Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-12 col-md-4">
            @include('admin/account_setting/_navigation')
        </div>
        <div class="col-12 col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0">Edit Account Details</h4>
                        </div>
                        <div class="col-12 col-sm-auto pt-2 pt-sm-0">
                            <div class="float-sm-right">
                                <a class="btn btn-dark" href="{{ route('admin.profile.index') }}">
                                    Back
                                </a>
                                <button type="submit" form="form" class="btn btn-success">
                                    Save Edit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form id="form" action="{{ route('admin.profile.update') }}" method="post">
                        @csrf
                        @method('PATCH')

                        <div class="form-group row">
                            <label for="email" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10 input-wrapper">
                                <input type="text" class="form-control" id="email" name="email"
                                    value="{{ $profile['email'] }}" placeholder="Email" required>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-wrapper').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
        });
    </script>
@endsection
