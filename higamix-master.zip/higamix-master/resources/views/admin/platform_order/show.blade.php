@php
use App\Enums\OrderStatus;
use App\Enums\ProductType;
@endphp

@extends('admin/layout/layout')

@section('page_title', 'Order Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <div class="d-flex align-items-center">
                        <h1 class="m-0 d-none d-sm-block">Order Details</h1>
                        <h4 class="m-0 d-block d-sm-none">Order Details</h4>
                        @if ($order->is_api_sales)
                            <span class="badge badge-primary ml-3">Sales from API</span>
                        @endif
                    </div>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('admin.platform_order.index') }}">
                                Back
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body p-md-5">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="row mb-3">
                        <div class="col-12 col-md-4">
                            Order Id:
                        </div>
                        <div class="col-12 col-md-8">
                            {{ $order->id }}
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12 col-md-4">
                            Date:
                        </div>
                        <div class="col-12 col-md-8">
                            <div>
                                {{ $order->created_at->format('d-m-Y h:i a') }}
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12 col-md-4">
                            Buyer Email:
                        </div>
                        <div class="col-12 col-md-8">
                            {{ $order->buyer_email }}
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="row mb-3">
                        <div class="col-12 col-md-auto">
                            Status:
                        </div>
                        <div class="col-12 col-md-auto">
                            @if ($order->status == OrderStatus::CompletePayment()->key)
                                <span
                                    class="badge badge-success">{{ OrderStatus::fromKey($order->status)->description }}</span>
                            @else
                                <span
                                    class="badge badge-light">{{ OrderStatus::fromKey($order->status)->description }}</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>




            <hr class="my-5">
            <div class="overflow-auto">
                <div class="container-fluid" style="min-width: 500px;">
                    <div class="row bg-primary py-2">
                        <div class="col-2 col-md-1 text-center align-self-center">
                            No.
                        </div>
                        <div class="col-7 d-block d-md-none text-center align-self-center">
                            Product
                        </div>
                        <div class="col-4 col-md-4 d-none d-md-block text-left align-self-center">
                            Product Name
                        </div>
                        <div class="col-md-2 d-none d-md-block text-center align-self-center">
                            Product Type
                        </div>
                        <div class="col-md-1 d-none d-md-block text-center align-self-center">
                            Qty
                        </div>
                        <div class="col-md-2 d-none d-md-block text-center align-self-center">
                            Unit Price (USDT)
                        </div>
                        <div class="col-3 col-md-2 col-md-2 text-center">
                            Total (USDT)
                        </div>
                    </div>
                    @foreach ($orderProducts as $index => $orderProduct)
                        <div class="row mt-3">
                            <div class="col-2 col-md-1 text-center">
                                {{ $index + 1 }}
                            </div>
                            <div class="col-7 d-block d-md-none">
                                <div>Product Name: <br>
                                    {{ $orderProduct->name }}</div>
                                <div>Product Type:
                                    <br>
                                    {{ ProductType::fromKey($orderProduct->product_type)->description }}
                                </div>
                                <div>Qty: {{ $orderProduct->qty }}</div>
                                <div>Unit Price (USDT): {{ $orderProduct->unit_price }}</div>
                            </div>
                            <div class="col-4 d-none d-md-block">
                                {{ $orderProduct->name }}
                            </div>
                            <div class="col-2 d-none d-md-block text-center">
                                {{ ProductType::fromKey($orderProduct->product_type)->description }}
                            </div>
                            <div class="col-1 d-none d-md-block text-center">
                                {{ $orderProduct->qty }}
                            </div>
                            <div class="col-2 d-none d-md-block text-right">
                                {{ $orderProduct->unit_price }}
                            </div>
                            <div class="col-3 col-md-2 text-right">
                                {{ $orderProduct->sub_total }}
                            </div>
                        </div>
                    @endforeach
                    <hr class="my-5">
                    <div class="row">
                        <div class="col-9 col-md-10 text-right">
                            Total :
                        </div>
                        <div class="col-3 col-md-2 text-right">
                            {{ $order->total }}
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-9 col-md-10 text-right">
                            Product Cost:
                        </div>
                        <div class="col-3 col-md-2 text-right">
                            -{{ $order->product_cost ?? number_format(0, 2, '.', '') }}
                        </div>
                    </div>
                    <div class="row font-weight-bold">
                        <div class="col-9 col-md-10 text-right">
                            Merchant Profit :
                        </div>
                        <div class="col-3 col-md-2 text-right">
                            {{ $order->seller_profit }}
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-9 col-md-10 text-right">
                            Platform Commission ({{ $order->platform_commission_percentage }}%):
                        </div>
                        <div class="col-3 col-md-2 text-right">
                            {{ number_format($order->total * ($order->platform_commission_percentage / 100), 2, '.', '') }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Comment</h4>
        </div>
        <div class="card-body">
            <div class="overflow-auto" id="comments-wrapper">
                <div class="container-fluid" style="max-height: 60vh;">
                    @if ($orderComments->isEmpty())
                        <div class="alert alert-secondary">
                            This product was no comment.
                        </div>
                    @else
                        @foreach ($orderComments as $orderComment)
                            <div class="row mb-3">
                                <div class="col-12">
                                    <span class="mr-1">{{ $orderComment->user->email }}</span>
                                    <small class="text-muted">{{ $orderComment->created_at }}</small>
                                    <div>
                                        : {{ $orderComment->content }}
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>


            <hr class="my-3">

            <form id="comment-form" action="{{ route('admin.platform_order.store', ['id' => $order->id]) }}"
                method="post">
                @csrf

                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <input type="text" name="content" class="form-control" placeholder="Add Comment..." required>
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">Add Comment</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#comment-form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

            $('#comments-wrapper').scrollTop($('#comments-wrapper')[0].scrollHeight);

        });
    </script>
@endsection
