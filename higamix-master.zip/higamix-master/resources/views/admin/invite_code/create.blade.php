@extends('admin/layout/layout')

@section('page_title', 'Create Invite Code')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Create Invite Code</h1>
                    <h4 class="m-0 d-block d-sm-none">Create Invite Code</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.invite_code.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('admin.invite_code.store') }}" method="post">
            @csrf

            <div class="card-body">
                <div class="form-group">
                    <label for="code">Invite code</label>
                    <input type="text" class="form-control" id="code" name="code" placeholder="Invite code"
                        required>
                </div>
                <button type="button" class="btn btn-primary" onclick="generateCode()">
                    Generate
                </button>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Create
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    code: {
                        required: true,
                        minlength: 10
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
        });

        function generateCode() {
            $('#code').val(uuidv4());
        }
    </script>
@endsection
