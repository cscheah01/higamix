@extends('admin/layout/layout')

@section('page_title', 'Invite Code Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Invite Code Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Invite Code Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('admin.invite_code.index') }}">
                                Back
                            </a>
                            <form method="post" action={{ route('admin.invite_code.destroy', ['id' => $inviteCode->id]) }}>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="deleteInviteCode(event)"
                                    {{ $inviteCode->is_used == true ? 'disabled' : '' }}>
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Invite Code:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        <span class="mr-2" id="invite-code">{{ $inviteCode->code }}</span>
                        <button class="btn btn-primary" id="btn-copy-invite-code" onclick="copyInviteCode()">Copy</button>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Status:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        @if ($inviteCode->is_used == 1)
                            <span class="badge badge-dark">Used</span>
                        @else
                            <span class="badge badge-primary">Unused</span>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Used By:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        @if ($inviteCode['used_by'] == null)
                            -
                        @else
                            <a href="{{ route('admin.merchant.show', ['id' => $inviteCode->user->id]) }}">
                                {{ $inviteCode->user->email }}</a>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Created At:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $inviteCode->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            deleteInviteCode = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });



        function copyInviteCode() {
            var inviteCode = $("#invite-code").text();
            navigator.clipboard.writeText(inviteCode);

            $("#btn-copy-invite-code").removeClass("btn-primary");
            $("#btn-copy-invite-code").addClass("btn-success");
            $("#btn-copy-invite-code").text("Copied!");
        }
    </script>
@endsection
