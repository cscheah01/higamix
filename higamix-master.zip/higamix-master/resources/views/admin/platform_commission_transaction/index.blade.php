@extends('admin/layout/layout')

@section('page_title', 'Platform Commission Transaction')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Platform Commission Transaction</h1>
                    <h4 class="m-0 d-block d-sm-none">Platform Commission Transaction</h4>
                </div>
            </div>
        </div>
    </div>


    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-order-id">Order ID</label>
                            <input type="search" id="filter-order-id" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-from" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">Date
                                From</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-from"
                                data-target-input="nearest" data-target="#datetimepicker-date-from"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-from"
                                    data-target="#datetimepicker-date-from" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="datetimepicker-date-to" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">Date
                                To</label>
                            <div class="input-group date date-time-picker" id="datetimepicker-date-to"
                                data-target-input="nearest" data-target="#datetimepicker-date-to"
                                data-toggle="datetimepicker">
                                <input type="search" class="form-control datetimepicker-input" id="filter-date-to"
                                    data-target="#datetimepicker-date-to" />
                                <div class="input-group-append">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Percentage (%)</th>
                        <th>Amount (USDT)</th>
                        <th>Date</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('.date-time-picker').datetimepicker({
                format: 'DD-MM-YYYY hh:mm A',
            });

            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.platform_commission_transaction.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";

                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                    }
                },
                columns: [{

                        data: null,
                        name: "order_id",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.platform_order.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.order_id);

                            return `
                             <a href="${url}">
                                ${data.order_id}
                            </a>`;
                        }
                    },
                    {

                        data: "percentage",
                        name: "percentage"
                    },
                    {
                        className: "dt-body-right",
                        data: "amount",
                        name: "amount"
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                        <div class="d-flex">
                             ${ createdAt }
                        </div>`;
                        }
                    },
                ],
                order: [
                    [3, 'desc']
                ],
            });

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    orderId: $("#filter-order-id").val(),
                };
                $table.column(0).search(filters.orderId);
                $table.draw();
            });
        });
    </script>
@endsection
