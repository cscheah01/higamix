@extends('admin/layout/layout')

@section('page_title', 'Dashboard')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Dashboard</h1>
                    <h4 class="m-0 d-block d-sm-none">Dashboard</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-sm-6 col-xl-4 mb-3">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-wallet fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Zixipay Balance (USDT)
                        </div>
                        <div>
                            @if ($data['zixipay_balance'] == null)
                                <b class="text-danger">Fail to connect Zixipay</b>
                            @else
                                <b>{{ $data['zixipay_balance'] }}</b>
                            @endif
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <br>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-4 mb-3 mb-sm-0">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-file-invoice-dollar fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Monthly Sales ({{ \Carbon\Carbon::now()->format('M Y') }})
                        </div>
                        <div>
                            <b>USDT {{ $data['total_sales'] ?? number_format(0, 2) }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('admin.platform_order.index') }}">More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-4 mb-3">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-file-invoice-dollar fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Earned Commission ({{ \Carbon\Carbon::now()->format('M Y') }})
                        </div>
                        <div>
                            <b>USDT
                                {{ $data['total_earned_commission'] ?? number_format(0, 2) }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('admin.platform_commission_transaction.index') }}">More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-xl-4 mb-3">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-file-invoice-dollar fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Withdrawal Request
                        </div>
                        <div>
                            <b>{{ $data['withdrawal_request'] ?? 0 }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('admin.wallet_withdrawal_request.index') }}">More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-xl-4 mb-3 mb-sm-0">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-user-plus fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Account Verify Request
                        </div>
                        <div>
                            <b>{{ $data['account_verify_request'] ?? 0 }}</b>
                        </div>
                    </div>
                </div>
                <hr class="m-0">
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="{{ route('admin.account_verify_request.index') }}">More info <i
                                class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-xl-4 mb-3">
            <div class="border shadow-sm rounded mr-1 bg-white">
                <div class="row p-4">
                    <div class="col-3">
                        <i class="fas fa-wallet fa-3x text-primary"></i>
                    </div>
                    <div class="col-9">
                        <div>
                            Today New Register Merchant
                        </div>
                        <div>
                            <b>{{ $data['today_total_register_merchant'] ?? 0 }}</b>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <hr class="m-0">
                        <a href="{{ route('admin.merchant.index') }}">More info <i class="fas fa-chevron-down"></i></a>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">New Register Merchant</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('admin.merchant.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <canvas id="register-merchant-chart" width="auto" height="80"></canvas>

        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Platform Sales Amount</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('admin.platform_order.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <canvas id="sales-amount-chart" width="auto" height="80"></canvas>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Earned Platform Commission</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('admin.platform_commission_transaction.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <canvas id="earned-commission-amount-chart" width="auto" height="80"></canvas>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-12 col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Verify Request List</h4>
                </div>
                <div class="col-12 col-sm-4 col-lg-3 text-sm-right">
                    <a href="{{ route('admin.account_verify_request.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body table-responsive">
            <table id="verify-request-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Merchant Email</th>
                        <th>Shop Name</th>
                        <th>Request Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <div class="row">
                <div class="col-auto col-sm-8 col-lg-9 d-flex align-items-center">
                    <h4 class="mb-0 mr-4">Withdrawal Request List</h4>
                </div>
                <div class="col-auto col-sm-4 col-lg-3 text-right">
                    <a href="{{ route('admin.wallet_withdrawal_request.index') }}">
                        More info <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>

        </div>
        <div class="card-body table-responsive">
            <table id="withdrawal-request-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Merchant Email</th>
                        <th>Shop Name</th>
                        <th>Request Amount (USDT)</th>
                        <th>Request Date</th>
                        <th>Status</th>
                        <th class="d-none"></th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="modal fade" id="reject-withdraw-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reject reason</h5>
                </div>
                <form id="reject-withdraw-form" method="post">
                    <div class="modal-body">

                        @csrf
                        @method('PATCH')
                        <div class="form-group">
                            <input type="hidden" name="is_approved" value="0" />
                            <textarea class="form-control" name="remark" id="remark"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary"
                            onclick="rejectWithdrawalRequest(event)">Reject</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {

            $('#verify-request-table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.account_verify_request.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";

                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                    }
                },
                columns: [{
                        data: null,
                        name: "users.email",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.user_id);

                            return `
                             <a href="${url}">
                                ${data.user_email}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "shops.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                       `;
                        }
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.user_id);

                            var formActionUrl =
                                `{{ route('admin.account_verify_request.update', ['id' => ':id']) }}`;
                            formActionUrl = formActionUrl.replace(':id', data.id);

                            return `
                        <div class="d-flex">
                             <a class="btn btn-success mr-1" href="${viewUrl}">
                                <i class="fas fa-eye"></i>
                            </a>

                                 <form method="post" class= "mr-1" action="${formActionUrl}">
                                    @csrf
                                    @method('PATCH')
                                    <input type="hidden" name="is_approved" value="1"/>
                                    <button type="submit" class="btn btn-primary " onclick="approveAccountVerify(event)">
                                        <i class="fa fa-check"></i>
                                    </button>
                                </form>

                            <form method="post" action="${formActionUrl}">
                                    @csrf
                                    @method('PATCH')
                                    <input type="hidden" name="is_approved" value="0"/>
                                    <button type="submit" class="btn btn-danger " onclick="rejectAccountVerify(event)">
                                        <i class="fa fa-x"></i>
                                    </button>
                                </form>
                        </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
            });

            approveAccountVerify = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to approve?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            rejectAccountVerify = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to reject?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, reject it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }

            $('#withdrawal-request-table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.wallet_withdrawal_request.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: function(data) {
                        data._token = "{{ csrf_token() }}";


                        var filters = {
                            dateFrom: $("#filter-date-from").val(),
                            dateTo: $("#filter-date-to").val(),
                        };

                        if (moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateFrom = moment(filters.dateFrom, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        if (moment(filters.dateTo, 'DD-MM-YYYY hh:mm A', true)
                            .isValid()) {
                            filters.dateTo = moment(filters.dateTo, 'DD-MM-YYYY hh:mm A').format(
                                'YYYY-MM-DD HH:mm:ss');
                        }

                        data.date_from = filters.dateFrom;
                        data.date_to = filters.dateTo;
                    }
                },
                columns: [{
                        data: null,
                        name: "users.email",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.merchant.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.user_id);

                            return `
                             <a href="${url}">
                                ${data.user_email}
                            </a>`;
                        }
                    },
                    {
                        data: null,
                        name: "shops.name",
                        render: function(data, type, row) {
                            var url =
                                `{{ route('admin.shop.show', ['id' => ':id']) }}`;
                            url = url.replace(':id', data.shop_id);

                            return `
                             <a href="${url}">
                                ${data.shop_name}
                            </a>`;
                        }
                    },
                    {
                        className: "dt-body-right",
                        data: "amount",
                        name: "amount"
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                            ${createdAt}
                        `;
                        }
                    },
                    {
                        data: null,
                        name: "is_approved",
                        width: "50px",
                        orderable: false,
                        className: "text-center",
                        render: function(data, type, row) {

                            if (data.is_approved == true) {

                                return `
                                <span class = "badge badge-success">
                                    Approved
                                </span>`;

                            } else if (data.is_approved == false) {

                                if (data.is_rejected == true) {
                                    return `
                                    <span class = "badge badge-danger">
                                        Rejected
                                    </span>`;

                                } else if (data.is_rejected == false) {
                                    return `
                                    <span class = "badge badge-warning">
                                        Pending
                                    </span>`;
                                }
                            }
                        }
                    },
                    {
                        data: "is_rejected",
                        name: "is_rejected",
                        visible: false
                    },
                    {
                        data: null,
                        width: "50px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.wallet_withdrawal_request.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var formActionUrl =
                                `{{ route('admin.wallet_withdrawal_request.update', ['id' => ':id']) }}`;
                            formActionUrl = formActionUrl.replace(':id', data.id);

                            return `
                        <div class="d-flex">
                             <a class="btn btn-success mr-1" href=" ${viewUrl}">
                                <i class="fas fa-eye"></i>
                            </a>

                                 <form method="post" class= "mr-1" action="  ${formActionUrl}">
                                    @csrf
                                    @method('PATCH')
                                    <input type="hidden" name="is_approved" value="1"/>
                                    <button type="submit" class="btn btn-primary " onclick="approveWithdrawalRequest(event)"${data.is_approved == true || data.is_rejected == true? 'disabled' : ''}>
                                        <i class="fa fa-check"></i>
                                    </button>
                                </form>

                            <button type="submit" class="btn btn-danger" onclick="rejectWithdraw(' ${formActionUrl}')"${data.is_approved == true || data.is_rejected == true? 'disabled' : ''}>
                                <i class="fa fa-x"></i>
                            </button>


                        </div>`;
                        }
                    },
                ],
                order: [
                    [3, "desc"]
                ],
            });

            rejectWithdraw = function(formActionUrl) {
                $('#reject-withdraw-modal').modal('show');
                $('#reject-withdraw-form').attr('action', formActionUrl);

            }
            $('#reject-withdraw-form').validate({
                rules: {
                    remark: {
                        required: true
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });
            approveWithdrawalRequest = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to approve?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, approve it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            rejectWithdrawalRequest = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure that you want to reject?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, reject it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            }

            var newMerchant = @json($data['each_month_new_register_merchant']);

            const ctxNewMerchant = document.getElementById('register-merchant-chart').getContext('2d');
            const newMerchantChart = new Chart(ctxNewMerchant, {
                type: 'line',
                data: {
                    labels: ['January', 'Febraury', 'March', 'April', 'May', 'June', 'July',
                        'August', 'September',
                        'October', 'November', 'December'
                    ],
                    datasets: [{
                        label: 'New Merchant',
                        data: newMerchant,
                        fill: true,
                        borderColor: '#002FA7',
                        tension: 0.1,
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });


            var sales = @json($data['each_month_sales']);

            const ctxSales = document.getElementById('sales-amount-chart').getContext('2d');
            const salesChart = new Chart(ctxSales, {
                type: 'line',
                data: {
                    labels: ['January', 'Febraury', 'March', 'April', 'May', 'June', 'July',
                        'August', 'September',
                        'October', 'November', 'December'
                    ],
                    datasets: [{
                        label: 'Sales',
                        data: sales,
                        fill: true,
                        borderColor: '#002FA7',
                        tension: 0.1,
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });


            var platformCommission = @json($data['each_month_earned_platform_commission']);

            const ctxPlatformCommission = document.getElementById('earned-commission-amount-chart').getContext(
                '2d');
            const platformCommissionChart = new Chart(ctxPlatformCommission, {
                type: 'line',
                data: {
                    labels: ['January', 'Febraury', 'March', 'April', 'May', 'June', 'July',
                        'August', 'September',
                        'October', 'November', 'December'
                    ],
                    datasets: [{
                        label: 'Platform Commission',
                        data: platformCommission,
                        fill: true,
                        borderColor: '#002FA7',
                        tension: 0.1,
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        });
    </script>
@endsection
