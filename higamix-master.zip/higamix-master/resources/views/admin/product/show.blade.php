@php
use App\Enums\ProductType;
@endphp

@extends('admin/layout/layout')

@section('page_title', 'Product Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Product Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Product Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.product.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">Product Owner</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Merchant Email:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        <a href="{{ route('admin.merchant.show', ['id' => $product->shop->user->id]) }}">
                            {{ $product->shop->user->email }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Shop Name:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        <a href="{{ route('admin.shop.show', ['id' => $product->shop->id]) }}">
                            {{ $product->shop->name }}</a>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Is Resell:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->is_resell == true)
                            <span class="badge badge-primary">Yes</span>
                        @else
                            <span class="badge badge-secondary">No</span>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">General Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="img-wrap rounded mx-auto mb-4 border shadow">
                        <img class="img"
                            src="{{ $product['image'] != null ? url('storage/product_image/' . $product['image']) : asset('img/empty-image.png') }}"
                            onerror="this.onerror=null;this.src='{{ asset('img/empty-image.png') }}'">
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Title:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->name }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->parent_product_id != null)
                            {{ $parentProduct->productCategory->name ?? 'Uncategorized' }}
                        @else
                            {{ $product->productCategory->name ?? 'Uncategorized' }}
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Sub Category:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->parent_product_id != null)
                            {{ $parentProduct->productSubCategory->name ?? '-' }}
                        @else
                            {{ $product->productSubCategory->name ?? '-' }}
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Status:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->is_available == true)
                            <span class="badge badge-primary">Available</span>
                        @else
                            <span class="badge badge-danger">Not Available</span>
                        @endif
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Description:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div class="ql-container ql-snow" style="min-height:150px;">
                        <div class="ql-editor">
                            {!! $parentProduct->description ?? $product->description !!}
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Product Type:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->parent_product_id != null ? ProductType::fromKey($parentProduct->product_type)->description : ProductType::fromKey($product->product_type)->description }}
                    </div>
                </div>
                @if (($product->parent_product_id != null
                    ? ProductType::fromKey($parentProduct->product_type)->description
                    : ProductType::fromKey($product->product_type)->description) == ProductType::Service()->key)
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Service Description:</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div class="ql-container ql-snow" style="min-height:150px;">
                            <div class="ql-editor">{!! $product->service_description ?? $parentProduct->service_description !!}</div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Price & Purchase Quantity</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Product Price (USDT):</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->price ?? $parentProduct->resell_cost_price + $product->resell_profit }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Minimum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        {{ $product->min_purchase_qty ?? $parentProduct->min_purchase_qty }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-3">
                    <label>Maximum Purchase Quantity:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if (($product->parent_product_id != null ? $parentProduct->max_purchase_qty : $product->max_purchase_qty) == 0)
                            -
                        @else
                            {{ $parentProduct->max_purchase_qty ?? $product->max_purchase_qty }}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Resell Details</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-3">
                    <label>Allow Resell:</label>
                </div>
                <div class="col-12 col-md-9">
                    <div>
                        @if ($product->is_open_resell == true)
                            <span class="badge badge-primary">Allow</span>
                        @else
                            <span class="badge badge-danger">Disallow</span>
                        @endif
                    </div>
                </div>

                @if ($product->is_open_resell == true)
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Resell Cost Price (USDT):</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div>
                            {{ $product->resell_cost_price }}
                        </div>
                    </div>
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-12 col-md-3">
                        <label>Suggested Min Resell Price (USDT):</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <div>
                            {{ $product->suggested_min_resell_price }}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">
            <h4 class="mb-0">Promotion</h4>
        </div>
        <div class="card-body">
            @if ($productDiscounts->isEmpty())
                <div class="alert alert-secondary">
                    This product was no promotion.
                </div>
            @else
                @foreach ($productDiscounts as $productDiscount)
                    <div class="row mb-4">
                        <div class="col-6 col-sm-auto">
                            <label>Min Quantity: </label>
                            <div>
                                {{ $productDiscount->min_qty }}
                            </div>
                        </div>
                        <div class="col-6 col-sm-auto">
                            <label>Price / pcs (USDT): </label>
                            <div>
                                {{ $productDiscount->discounted_price }}
                            </div>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>
@endsection

@section('script')
    <script></script>
@endsection
