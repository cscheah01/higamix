@extends('admin/layout/layout')

@section('page_title', 'Setup Two-Factor Authentication')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Setup Two-Factor Authentication</h1>
                    <h4 class="m-0 d-block d-sm-none">Setup Two-Factor Authentication</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.profile.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body py-5">
            <div class="row">
                <div class="col-12 col-md-6 border-right">
                    <h3 class="text-center mb-5">Step 1: Scan Code or Enter Key</h3>
                    <p class="text-center">Set up your two factor authentication by scanning the barcode below with your
                        Google Authenticator or Authy app.</p>
                    <p class="text-center">
                        Alternatively, you can use the code <b>{{ $twoFactor['google_2fa_secret'] }}</b>
                    </p>

                    <div class="text-center my-5 mb-md-0">
                        {!! QrCode::size(200)->generate($twoFactor['qr_image_url']) !!}
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <h3 class="text-center pt-5 pt-md-0 mb-5">Step 2: Enter Code from Authenticator App</h3>

                    <div class="row">
                        <div class="col"></div>
                        <div class="col-8 text-center">
                            <form id="form" action="{{ route('admin.two_factor.setup.enable') }}" method="post">
                                @csrf

                                <div class="form-group">
                                    <input type="text" class="form-control text-center" name="code"
                                        placeholder="123456" required>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            </form>
                        </div>
                        <div class="col"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection


@section('script')
    <script>
        $(function() {
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            })
        });
    </script>
@endsection
