@extends('admin/layout/layout')

@section('page_title', 'Withdraw Transaction Fee Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Withdraw Transaction Fee Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Withdraw Transaction Fee Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <button type="submit" form="form" class="btn btn-success">
                            Save Edit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form id="form" action="{{ route('admin.withdrawal_transaction_fee_setting.update') }}" method="post">
                @csrf
                @method('PATCH')
                <div class="form-group row">
                    <div class="col-md-12">
                        <button type="button" class="btn btn-primary mb-3" onclick="addwithdrawalTransactionFeeSetting()">
                            Add
                        </button>
                        <div class="setting-input-wrapper">
                            @foreach ($withdrawalTransactionFees as $index => $withdrawTransactionFee)
                                <div class="row mb-3 setting-row">
                                    <div class="col-6 col-md-5">
                                        <div class="form-group">
                                            <label
                                                for="withdrawal_transaction_fees[{{ $index }}][amount_more_than_equal]">
                                                Amount more than or equal to (USDT)</label>
                                            <input type="number" step="0.01" min="0.00"
                                                class="form-control setting-within-amount-input"
                                                name="withdrawal_transaction_fees[{{ $index }}][amount_more_than_equal]"
                                                id="withdrawal_transaction_fees[{{ $index }}][amount_more_than_equal]"
                                                placeholder="Amount"
                                                value="{{ $withdrawTransactionFee->amount_more_than_equal }}" required>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-5">
                                        <div class="form-group">
                                            <label for="withdrawal_transaction_fees[{{ $index }}][fee]">Fee (USDT)
                                            </label>
                                            <input type="number" step="0.01" min="0.00"
                                                class="form-control setting-fee-input"
                                                name="withdrawal_transaction_fees[{{ $index }}][fee]"
                                                id="withdrawal_transaction_fees[{{ $index }}][fee]" placeholder="Fee"
                                                value="{{ $withdrawTransactionFee->fee }}" required>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-2 mb-3 mt-md-0 d-flex align-items-end">
                                        <button type="button" class="btn btn-danger btn-remove-setting">
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
            $('#form').validate({
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

        });

        function addwithdrawalTransactionFeeSetting() {
            var nextNumber = $('.setting-row').length;
            $('.setting-input-wrapper').append(
                `
                <div class="row mb-3 setting-row">
                    <div class="col-6 col-md-5">
                        <div class="form-group">
                            <label for="withdrawal_transaction_fees[${nextNumber}][amount_more_than_equal]">Amount more than or equal to (USDT)</label>
                            <input type="number" step="0.01" min="0.00" class="form-control setting-within-amount-input" name="withdrawal_transaction_fees[${nextNumber}][amount_more_than_equal]" id="withdrawal_transaction_fees[${nextNumber}][amount_more_than_equal]" placeholder="Amount" required>
                        </div>
                    </div>
                    <div class="col-6 col-md-5">
                        <div class="form-group">
                            <label for="withdrawal_transaction_fees[${nextNumber}][fee]">Fee (USDT)</label>
                            <input type="number" step="0.01" min="0.00" class="form-control setting-fee-input" name="withdrawal_transaction_fees[${nextNumber}][fee]" id="withdrawal_transaction_fees[${nextNumber}][fee]" placeholder="Fee" required>
                        </div>
                    </div>
                    <div class="col-6 col-md-2 mb-3 mt-md-0 d-flex align-items-end">
                        <button type="button" class="btn btn-danger btn-remove-setting">
                            Remove
                        </button>
                    </div>
                </div>`);
            $('[data-toggle="tooltip"]').tooltip();
        }


        $(document).on('click', '.btn-remove-setting', function() {
            $(this).closest('.setting-row').remove();
            reAssignSettingInputName();
        });

        function reAssignSettingInputName() {
            var settingWithinAmmountCount = 1;
            var settingFeeCount = 1;
            $('.setting-within-amount-input').each(function() {
                $(this).attr(`'name', 'withdrawal_transaction_fees[' ${settingWithdrawAmmountCount}
                    '][amount_more_than_equal]'`);
                settingWithinAmmountCount++;
            })
            $('.setting-fee-input').each(function() {
                $(this).attr(`'name', 'withdrawal_transaction_fees[' ${ settingFeeCount }'][fee]'`);
                settingFeeCount++;
            })
        }
    </script>

@endsection
