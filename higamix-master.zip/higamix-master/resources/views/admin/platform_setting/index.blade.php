@php
use App\Enums\SettingMeta;
@endphp

@extends('admin/layout/layout')

@section('page_title', 'Platform Setting')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Platform Setting</h1>
                    <h4 class="m-0 d-block d-sm-none">Platform Setting</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <button type="submit" form="form" class="btn btn-success">
                            Save Edit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <form id="form" action="{{ route('admin.platform_setting.update') }}" method="post">
                @csrf
                @method('PATCH')

                @foreach ($platformSettings as $platformSetting)
                    <div class="form-group row">
                        <label for="platform_setting[{{ $platformSetting['meta_key'] }}]"
                            class="col-md-3 col-form-label text-capitalize">{{ SettingMeta::fromKey($platformSetting['meta_key'])->description }}</label>

                        <div class="col-md-5 col-xl-4">

                            @if ($platformSetting['meta_key'] == SettingMeta::PlatformCommission()->key)
                                <div class="input-group">
                                    <input type="number" class="form-control"
                                        name="platform_setting[{{ $platformSetting['meta_key'] }}]"
                                        id="platform_setting[{{ $platformSetting['meta_key'] }}]" step="0.01"
                                        min="0.00" value="{{ $platformSetting['meta_value'] }}" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                            @elseif ($platformSetting['meta_key'] == SettingMeta::MinimumTopUpAmount()->key ||
                                $platformSetting['meta_key'] == SettingMeta::MinimumWithdrawAmount()->key)
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">USDT</span>
                                    </div>
                                    <input type="number" class="form-control"
                                        name="platform_setting[{{ $platformSetting['meta_key'] }}]"
                                        id="platform_setting[{{ $platformSetting['meta_key'] }}]" step="0.01"
                                        min="0.00" value="{{ $platformSetting['meta_value'] }}" required>
                                </div>
                            @endif

                        </div>
                        <div class="col-md-3 col-xl-4">

                        </div>
                    </div>
                @endforeach
            </form>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({

                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.input-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                invalidHandler: function(form, validator) {
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        toastr.error('Please check all the fields')
                    }
                },
            });

        });
    </script>
@endsection
