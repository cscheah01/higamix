@extends('admin/layout/layout')

@section('page_title', 'Staff Details')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Staff Details</h1>
                    <h4 class="m-0 d-block d-sm-none">Staff Details</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <div class="d-flex">
                            <a class="btn btn-dark mr-1" href="{{ route('admin.staff.index') }}">
                                Back
                            </a>
                            <form method="post" action={{ route('admin.staff.destroy', ['id' => $staff->id]) }}
                                class="mr-1">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="deleteStaff(event)"
                                    {{ $staff->id == auth()->user()->id ? 'disabled' : '' }}>
                                    Delete
                                </button>
                            </form>
                            <a class="btn btn-primary" href="{{ route('admin.staff.edit', ['id' => $staff->id]) }}">
                                Edit
                            </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-2">
                    <label>Email:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $staff->email }}
                    </div>
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Two Factor Authentication:</label>
                </div>
                <div class="col-12 col-md-10">
                    @if ($staff->is_enabled_two_factor == true)
                        <span class="badge badge-success">Enabled</span>
                    @else
                        <span class="badge badge-danger">Disabled</span>
                    @endif
                </div>
                <div class="col-12">
                    <hr />
                </div>
                <div class="col-12 col-md-2">
                    <label>Created At:</label>
                </div>
                <div class="col-12 col-md-10">
                    <div>
                        {{ $staff->created_at->format('d-m-Y h:i a') }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mr-3">Login History</h5>
            </div>
            <table id="login-history-table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th class="d-none"></th>
                        <th>Date</th>
                        <th>IP Address</th>
                        <th>Country</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

@endsection

@section('script')

    <script>
        $(function() {
            $('#login-history-table').DataTable({
                infoFiltered: "",
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                language: {
                    infoFiltered: "",
                },
                ajax: {
                    url: "{{ route('admin.login_history.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "user_id",
                        name: "user_id",
                        visible: false
                    }, {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                             ${createdAt}
                        `;
                        }
                    },
                    {
                        data: "ip_address",
                        name: "ip_address"
                    },
                    {
                        data: "country",
                        name: "country"
                    },

                ],
                order: [
                    [1, "desc"]
                ],
                searchCols: [{
                        search: "\\b{{ $staff->id }}\\b",
                        regex: true
                    },
                    null,
                    null,
                    null,
                ],
            });

            deleteStaff = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',

                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };
        });
    </script>

@endsection
