@extends('admin/layout/layout')

@section('page_title', 'Create Staff')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Create Staff</h1>
                    <h4 class="m-0 d-block d-sm-none">Create Staff</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a class="btn btn-dark" href="{{ route('admin.staff.index') }}">
                            Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <form id="form" action="{{ route('admin.staff.store') }}" method="post">
            @csrf

            <div class="card-body">
                <div class="form-group">
                    <label for="user-email">Email</label>
                    <input type="email" class="form-control" id="user-email" name="email" value="{{ old('email') }}"
                        placeholder="Email" required>

                </div>
                <div class="form-group">
                    <label for="user-password">Password</label>
                    <input type="password" class="form-control" id="user-password" name="password" placeholder="Password"
                        required>
                </div>
                <div class="form-group">
                    <label for="name">Confirm password</label>
                    <input type="password" class="form-control" id="user-password_confirmation" name="password_confirmation"
                        placeholder="Confirm Password" required>
                </div>
            </div>
            <div class="card-footer">
                <div class="float-sm-right">
                    <button type="submit" form="form" class="btn btn-success">
                        Create
                    </button>
                </div>
            </div>
        </form>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#form').validate({
                rules: {
                    'password': {
                        required: true,
                        minlength: 8
                    },
                    'password_confirmation': {
                        required: true,
                        equalTo: "#user-password"
                    }
                },
                messages: {
                    'password_confirmation': {
                        equalTo: "Password not match."
                    }
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            })
        });
    </script>
@endsection
