@extends('admin/layout/layout')

@section('page_title', 'Staff')

@section('content')
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2 px-0">
                <div class="col px-0">
                    <h1 class="m-0 d-none d-sm-block">Staff</h1>
                    <h4 class="m-0 d-block d-sm-none">Staff</h4>
                </div>
                <div class="col-sm-4 px-0 pt-2 pt-sm-0">
                    <div class="float-sm-right">
                        <a type="button" class="btn btn-success" href="{{ route('admin.staff.create') }}">
                            Create Staff
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-5">
        <div class="card-body">
            <form id="filter-form">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-email">Email</label>
                            <input type="search" id="filter-email" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="filter-status">Two Factor Authentication</label>
                            <select class="form-control" id="filter-status">
                                <option value="">All</option>
                                <option value="0">Disabled</option>
                                <option value="1">Enabled</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="float-right">
                <button type="button" class="btn btn-default" onclick="resetForm('#filter-form');">
                    Reset
                </button>
                <button type="submit" class="btn btn-primary" form="filter-form">
                    Search
                </button>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table id="table" class="table table-bordered dt-responsive rounded" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Two Factor Authentication</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(function() {
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                sDom: "ltipr",
                ajax: {
                    url: "{{ route('admin.staff.datatable') }}",
                    dataType: "json",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}"
                    }
                },
                columns: [{
                        data: "email",
                        name: "email"
                    },
                    {
                        data: "is_enabled_two_factor",
                        name: "is_enabled_two_factor",
                        width: "200px",
                        className: "text-center",
                        render: function(data, type, row) {

                            if (data == true) {
                                return `<span class="badge badge-dark">Enabled</span>`;
                            } else {
                                return `<span class="badge badge-primary">Disabled</span>`;
                            }
                        }
                    },
                    {
                        data: "created_at",
                        name: "created_at",
                        width: "150px",
                        render: function(data, type, row) {
                            var createdAt =
                                moment(data).local().format("DD-MM-YYYY hh:mm a")

                            return `
                        <div class="d-flex">
                             ${createdAt}
                        </div>`;
                        }
                    },
                    {
                        data: null,
                        width: "90px",
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row) {
                            var viewUrl =
                                `{{ route('admin.staff.show', ['id' => ':id']) }}`;
                            viewUrl = viewUrl.replace(':id', data.id);

                            var editUrl =
                                `{{ route('admin.staff.edit', ['id' => ':id']) }}`;
                            editUrl = editUrl.replace(':id', data.id);

                            var deleteUrl =
                                `{{ route('admin.staff.destroy', ['id' => ':id']) }}`;
                            deleteUrl = deleteUrl.replace(':id', data.id);

                            var userId = `{{ auth()->user()->id }}`;

                            return `
                            <div class="d-flex">
                                 <a class="btn btn-success mr-1" href="${viewUrl}">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <a class="btn btn-primary mr-1" href="${editUrl}">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="post" action="${deleteUrl}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="deleteStaff(event)" ${data.id == userId ? 'disabled' : ''}>
                                        <i class="far fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>`;
                        }
                    },
                ],
                order: [
                    [2, "desc"]
                ],
            });

            deleteStaff = function(e) {
                e.preventDefault();

                Swal.fire({
                    title: 'Are you sure want to delete?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#002FA7',
                    cancelButtonColor: '#f01b00',
                    confirmButtonText: 'Yes, delete it'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(e.target).closest('form').submit();
                    }
                })
            };

            $("#filter-form").submit(function(e) {
                e.preventDefault();

                var $table = $('#table').DataTable();

                var filters = {
                    email: $("#filter-email").val(),
                    status: $("#filter-status").val(),
                };

                $table.column(0).search(filters.email);
                $table.column(1).search(filters.status);
                $table.draw();
            });
        });
    </script>

@endsection
