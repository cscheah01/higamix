
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta
            name="HiGamix API Documentation"
            content="Documentation for the HiGamix API"
        >

    <link href="{{ asset('slate/images/favicon-804af83b.png') }}" rel="icon" type="image/png" />

    <title>HiGamix API Reference</title>

    <style media="screen">
      .highlight table td { padding: 5px; }
.highlight table pre { margin: 0; }
.highlight .gh {
  color: #999999;
}
.highlight .sr {
  color: #f6aa11;
}
.highlight .go {
  color: #888888;
}
.highlight .gp {
  color: #555555;
}
.highlight .gs {
}
.highlight .gu {
  color: #aaaaaa;
}
.highlight .nb {
  color: #f6aa11;
}
.highlight .cm {
  color: #75715e;
}
.highlight .cp {
  color: #75715e;
}
.highlight .c1 {
  color: #75715e;
}
.highlight .cs {
  color: #75715e;
}
.highlight .c, .highlight .ch, .highlight .cd, .highlight .cpf {
  color: #75715e;
}
.highlight .err {
  color: #960050;
}
.highlight .gr {
  color: #960050;
}
.highlight .gt {
  color: #960050;
}
.highlight .gd {
  color: #49483e;
}
.highlight .gi {
  color: #49483e;
}
.highlight .ge {
  color: #49483e;
}
.highlight .kc {
  color: #66d9ef;
}
.highlight .kd {
  color: #66d9ef;
}
.highlight .kr {
  color: #66d9ef;
}
.highlight .no {
  color: #66d9ef;
}
.highlight .kt {
  color: #66d9ef;
}
.highlight .mf {
  color: #ae81ff;
}
.highlight .mh {
  color: #ae81ff;
}
.highlight .il {
  color: #ae81ff;
}
.highlight .mi {
  color: #ae81ff;
}
.highlight .mo {
  color: #ae81ff;
}
.highlight .m, .highlight .mb, .highlight .mx {
  color: #ae81ff;
}
.highlight .sc {
  color: #ae81ff;
}
.highlight .se {
  color: #ae81ff;
}
.highlight .ss {
  color: #ae81ff;
}
.highlight .sd {
  color: #e6db74;
}
.highlight .s2 {
  color: #e6db74;
}
.highlight .sb {
  color: #e6db74;
}
.highlight .sh {
  color: #e6db74;
}
.highlight .si {
  color: #e6db74;
}
.highlight .sx {
  color: #e6db74;
}
.highlight .s1 {
  color: #e6db74;
}
.highlight .s, .highlight .sa, .highlight .dl {
  color: #e6db74;
}
.highlight .na {
  color: #a6e22e;
}
.highlight .nc {
  color: #a6e22e;
}
.highlight .nd {
  color: #a6e22e;
}
.highlight .ne {
  color: #a6e22e;
}
.highlight .nf, .highlight .fm {
  color: #a6e22e;
}
.highlight .vc {
  color: #ffffff;
}
.highlight .nn {
  color: #ffffff;
}
.highlight .ni {
  color: #ffffff;
}
.highlight .bp {
  color: #ffffff;
}
.highlight .vg {
  color: #ffffff;
}
.highlight .vi {
  color: #ffffff;
}
.highlight .nv, .highlight .vm {
  color: #ffffff;
}
.highlight .w {
  color: #ffffff;
}
.highlight {
  color: #ffffff;
}
.highlight .n, .highlight .py, .highlight .nx {
  color: #ffffff;
}
.highlight .nl {
  color: #f92672;
}
.highlight .ow {
  color: #f92672;
}
.highlight .nt {
  color: #f92672;
}
.highlight .k, .highlight .kv {
  color: #f92672;
}
.highlight .kn {
  color: #f92672;
}
.highlight .kp {
  color: #f92672;
}
.highlight .o {
  color: #f92672;
}
    </style>
    <style media="print">
      * {
        -webkit-transition:none!important;
        transition:none!important;
      }
      .highlight table td { padding: 5px; }
.highlight table pre { margin: 0; }
.highlight, .highlight .w {
  color: #586e75;
}
.highlight .err {
  color: #002b36;
  background-color: #dc322f;
}
.highlight .c, .highlight .ch, .highlight .cd, .highlight .cm, .highlight .cpf, .highlight .c1, .highlight .cs {
  color: #657b83;
}
.highlight .cp {
  color: #b58900;
}
.highlight .nt {
  color: #b58900;
}
.highlight .o, .highlight .ow {
  color: #93a1a1;
}
.highlight .p, .highlight .pi {
  color: #93a1a1;
}
.highlight .gi {
  color: #859900;
}
.highlight .gd {
  color: #dc322f;
}
.highlight .gh {
  color: #268bd2;
  background-color: #002b36;
  font-weight: bold;
}
.highlight .k, .highlight .kn, .highlight .kp, .highlight .kr, .highlight .kv {
  color: #6c71c4;
}
.highlight .kc {
  color: #cb4b16;
}
.highlight .kt {
  color: #cb4b16;
}
.highlight .kd {
  color: #cb4b16;
}
.highlight .s, .highlight .sb, .highlight .sc, .highlight .dl, .highlight .sd, .highlight .s2, .highlight .sh, .highlight .sx, .highlight .s1 {
  color: #859900;
}
.highlight .sa {
  color: #6c71c4;
}
.highlight .sr {
  color: #2aa198;
}
.highlight .si {
  color: #d33682;
}
.highlight .se {
  color: #d33682;
}
.highlight .nn {
  color: #b58900;
}
.highlight .nc {
  color: #b58900;
}
.highlight .no {
  color: #b58900;
}
.highlight .na {
  color: #268bd2;
}
.highlight .m, .highlight .mb, .highlight .mf, .highlight .mh, .highlight .mi, .highlight .il, .highlight .mo, .highlight .mx {
  color: #859900;
}
.highlight .ss {
  color: #859900;
}
    </style>
    <link href="{{ asset('slate/stylesheets/screen-19fa452a.css') }}" rel="stylesheet" media="screen" />
    <link href="{{ asset('slate/stylesheets/print-953e3353.css') }}" rel="stylesheet" media="print" />
      <script src="{{ asset('slate/javascripts/all-b12a2749.js') }}"></script>

    <script>
      $(function() { setupCodeCopy(); });
    </script>
  </head>

  <body class="index" data-languages="[&quot;javascript&quot;]">
    <a href="#" id="nav-button">
      <span>
        NAV
        <img src="{{ asset('slate/images/navbar-cad8cdcb.png') }}" alt="" />
      </span>
    </a>
    <div class="toc-wrapper">
      <img src="{{ asset('slate/images/logo-aba265cd.png') }}" class="logo" alt="" />
        <div class="lang-selector">
              <a href="#" data-language-name="javascript">node.js</a>
        </div>
        <div class="search">
          <input type="text" class="search" id="input-search" placeholder="Search">
        </div>
        <ul class="search-results"></ul>
      <ul id="toc" class="toc-list-h1">
          <li>
            <a href="#introduction" class="toc-h1 toc-link" data-title="Introduction">Introduction</a>
              <ul class="toc-list-h2">
                  <li>
                    <a href="#base-url" class="toc-h2 toc-link" data-title="Base URL">Base URL</a>
                  </li>
                  <li>
                    <a href="#rate-limit" class="toc-h2 toc-link" data-title="Rate limit">Rate limit</a>
                  </li>
              </ul>
          </li>
          <li>
            <a href="#authentication" class="toc-h1 toc-link" data-title="Authentication">Authentication</a>
              <ul class="toc-list-h2">
                  <li>
                    <a href="#api-keys" class="toc-h2 toc-link" data-title="API keys">API keys</a>
                  </li>
                  <li>
                    <a href="#signature" class="toc-h2 toc-link" data-title="Signature">Signature</a>
                  </li>
                  <li>
                    <a href="#headers" class="toc-h2 toc-link" data-title="Headers">Headers</a>
                  </li>
              </ul>
          </li>
          <li>
            <a href="#wallet" class="toc-h1 toc-link" data-title="Wallet">Wallet</a>
              <ul class="toc-list-h2">
                  <li>
                    <a href="#get-wallet-balance" class="toc-h2 toc-link" data-title="Get Wallet Balance">Get Wallet Balance</a>
                  </li>
              </ul>
          </li>
          <li>
            <a href="#products" class="toc-h1 toc-link" data-title="Products">Products</a>
              <ul class="toc-list-h2">
                  <li>
                    <a href="#product-properties" class="toc-h2 toc-link" data-title="Product properties">Product properties</a>
                  </li>
                  <li>
                    <a href="#list-all-products" class="toc-h2 toc-link" data-title="List all products">List all products</a>
                  </li>
                  <li>
                    <a href="#retrieve-a-product" class="toc-h2 toc-link" data-title="Retrieve a product">Retrieve a product</a>
                  </li>
              </ul>
          </li>
          <li>
            <a href="#orders" class="toc-h1 toc-link" data-title="Orders">Orders</a>
              <ul class="toc-list-h2">
                  <li>
                    <a href="#order-properties" class="toc-h2 toc-link" data-title="Order properties">Order properties</a>
                  </li>
                  <li>
                    <a href="#create-an-order" class="toc-h2 toc-link" data-title="Create an order">Create an order</a>
                  </li>
                  <li>
                    <a href="#retrieve-an-order" class="toc-h2 toc-link" data-title="Retrieve an order">Retrieve an order</a>
                  </li>
                  <li>
                    <a href="#list-all-orders" class="toc-h2 toc-link" data-title="List all orders">List all orders</a>
                  </li>
              </ul>
          </li>
          <li>
            <a href="#errors" class="toc-h1 toc-link" data-title="Errors">Errors</a>
          </li>
      </ul>
    </div>
    <div class="page-wrapper">
      <div class="dark-box"></div>
      <div class="content">
        <h1 id='introduction'>Introduction</h1>
<p>Welcome to the HiGamix API! HiGamix is an E-Commerce platform that let everyone to sell digital goods online in a secure and modern environment.</p>

<p>HiGamix API allow the merchant to integrate with their own platform. Our API allows you to connect your store in our platform and sell it on your own platform.</p>
<h2 id='base-url'>Base URL</h2>
<p><code>https://www.higamix.com/api/v1</code></p>
<h2 id='rate-limit'>Rate limit</h2>
<p>HiGamix API endpoints call are limited to <code>1000 request/minute</code>. Exceed the rate limit will result in a <code>429</code> HTTP return code.</p>
<h1 id='authentication'>Authentication</h1>
<p>HiGamix API uses HMAC-SHA256 as its authentication mechanism.</p>
<h2 id='api-keys'>API keys</h2>
<p>You can get the <code>Public Key</code> and <code>Secret Key</code> from the <a href="https://www.higamix.com/login" target="_blank">merchant portal</a> <strong>account setting page</strong> under API Credentials section to generate a HMAC-SHA256 signature.</p>

<aside class="notice">
Please store your <code>Public Key</code> and <code>Secret Key</code> in a secure environment and <b>should avoid</b> to store at client-side code.
</aside>
<h2 id='signature'>Signature</h2><div class="highlight"><pre class="highlight javascript tab-javascript"><code><span class="kd">const</span> <span class="nx">secretKey</span> <span class="o">=</span> <span class="dl">'</span><span class="s1">s6Gdsd86eda18-157a-475e-b312-487ab7281ce0hCxba</span><span class="dl">'</span><span class="p">;</span>
<span class="kd">const</span> <span class="nx">requestBody</span> <span class="o">=</span> <span class="nx">JSON</span><span class="p">.</span><span class="nx">stringify</span><span class="p">({...});</span> <span class="c1">// =&gt; the whole request body</span>
<span class="kd">const</span> <span class="nx">timestamp</span> <span class="o">=</span> <span class="k">new</span> <span class="nb">Date</span><span class="p">().</span><span class="nx">getTime</span><span class="p">().</span><span class="nx">toString</span><span class="p">();</span> <span class="c1">// =&gt; `1659530485630`</span>

<span class="kd">const</span> <span class="nx">rawSignature</span> <span class="o">=</span> <span class="s2">`</span><span class="p">${</span><span class="nx">timestamp</span><span class="p">}</span><span class="s2">\r\n\r\n</span><span class="p">${</span><span class="nx">requestBody</span><span class="p">}</span><span class="s2">`</span><span class="p">;</span>

<span class="kd">const</span> <span class="nx">signature</span> <span class="o">=</span> <span class="nx">CryptoJS</span><span class="p">.</span><span class="nx">HmacSHA256</span><span class="p">(</span><span class="nx">rawSignature</span><span class="p">,</span> <span class="nx">secretKey</span><span class="p">).</span><span class="nx">toString</span><span class="p">();</span>
<span class="c1">// =&gt; 'ad4ecdd30d579e5fa7d0692edf01a6c0f13652af6a6778291914ebcde1cccc60'</span>
</code></pre></div>
<p>HMAC-SHA256 signatures is require for all endpoints.</p>

<p><strong>The format of the Raw Signature:</strong><br>
<code>&#60;timestamp&#62;\r\n\r\n&#60;requestBody&#62;</code></p>

<p>Use <code>Secret Key</code> as the key and the <code>Raw Signature</code> as the value for the HMAC operation.</p>

<aside class="notice">
API calls will be rejected if the <code>timestamp</code> is not within 60 seconds window from the endpoint server’s time.
</aside>
<h2 id='headers'>Headers</h2><div class="highlight"><pre class="highlight javascript tab-javascript"><code><span class="kd">const</span> <span class="nx">publictKey</span> <span class="o">=</span> <span class="dl">"</span><span class="s2">PcwQg965f5891-4435-45e9-98d7-5ba77655fdc9Ls6LP</span><span class="dl">"</span><span class="p">;</span>
<span class="kd">const</span> <span class="nx">token</span> <span class="o">=</span> <span class="s2">`</span><span class="p">${</span><span class="nx">publictKey</span><span class="p">}</span><span class="s2">:</span><span class="p">${</span><span class="nx">timestamp</span><span class="p">}</span><span class="s2">:</span><span class="p">${</span><span class="nx">signature</span><span class="p">}</span><span class="s2">`</span><span class="p">;</span>
</code></pre></div>
<blockquote>
<p>Example:</p>
</blockquote>
<div class="highlight"><pre class="highlight plaintext"><code>Authorization: hmac PcwQg965f5891-4435-45e9-98d7-5ba77655fdc9Ls6LP:1659530485630:ad4ecdd30d579e5fa7d0692edf01a6c0f13652af6a6778291914ebcde1cccc60
</code></pre></div>
<p>Every API call <strong>must include</strong> <code>Authorization</code> header with the token.</p>

<p><strong>The format of the token:</strong><br>
<code>&#60;publictKey&#62;:&#60;timestamp&#62;:&#60;signature&#62;</code></p>
<h1 id='wallet'>Wallet</h1><h2 id='get-wallet-balance'>Get Wallet Balance</h2>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">true</span><span class="p">,</span><span class="w">
  </span><span class="nl">"data"</span><span class="p">:</span><span class="w"> </span><span class="p">{</span><span class="w">
    </span><span class="nl">"balance"</span><span class="p">:</span><span class="w"> </span><span class="s2">"100.00"</span><span class="w">
  </span><span class="p">}</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<p>This endpoint retrieves the wallet balance.</p>
<h3 id='http-request'>HTTP Request</h3>
<p><code>GET /balances</code></p>
<h1 id='products'>Products</h1><h2 id='product-properties'>Product properties</h2>
<table><thead>
<tr>
<th>Attribute</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead><tbody>
<tr>
<td>id</td>
<td>integer</td>
<td>Unique identifier for the resource..</td>
</tr>
<tr>
<td>name</td>
<td>string</td>
<td>Product name.</td>
</tr>
<tr>
<td>description</td>
<td>string</td>
<td>Product description. This field will return html code in string, the content styling is base on <a href="https://quilljs.com">quilljs</a>.</td>
</tr>
<tr>
<td>image</td>
<td>string</td>
<td>Product image url.</td>
</tr>
<tr>
<td>price</td>
<td>string</td>
<td>Product sell price.</td>
</tr>
<tr>
<td>min_purchase_qty</td>
<td>integer</td>
<td>Minimum purchase quantity the product.</td>
</tr>
<tr>
<td>max_purchase_qty</td>
<td>integer</td>
<td>Maximum purchase quantity the product.</td>
</tr>
<tr>
<td>product_type</td>
<td>string</td>
<td>Product type. Options: <code>Serial key</code>, <code>Service</code>.</td>
</tr>
<tr>
<td>service_description</td>
<td>string</td>
<td>Product service description for <code>Service</code> type product. This field will return html code in string, the content styling is base on <a href="https://quilljs.com">quilljs</a>.</td>
</tr>
<tr>
<td>product_category_name</td>
<td>string</td>
<td>Category name.</td>
</tr>
<tr>
<td>product_sub_category_name</td>
<td>string</td>
<td>Sub category name.</td>
</tr>
<tr>
<td>stock_qty</td>
<td>integer</td>
<td>Total remaining stock quantity for <code>Serial key</code> type product.</td>
</tr>
<tr>
<td>promotion</td>
<td>array</td>
<td>Promotions data. See <a href="#product-promotion-properties">Product - Promotion properties</a></td>
</tr>
</tbody></table>
<h3 id='product-promotion-properties'>Product - Promotion properties</h3>
<table><thead>
<tr>
<th>Attribute</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead><tbody>
<tr>
<td>min_qty</td>
<td>integer</td>
<td>Minimum purchase quantity to get the discounted price.</td>
</tr>
<tr>
<td>discounted_price</td>
<td>string</td>
<td>Discounted unit price.</td>
</tr>
</tbody></table>
<h2 id='list-all-products'>List all products</h2>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">true</span><span class="p">,</span><span class="w">
  </span><span class="nl">"data"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="p">,</span><span class="w">
      </span><span class="nl">"name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Product A"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"description"</span><span class="p">:</span><span class="w"> </span><span class="s2">"&lt;p&gt;This is a dummy product description.&lt;/p&gt;"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"image"</span><span class="p">:</span><span class="w"> </span><span class="s2">"http://127.0.0.1:8000/storage/product_image/example.jpg"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"20.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"min_purchase_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="p">,</span><span class="w">
      </span><span class="nl">"max_purchase_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">0</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_type"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Serial key"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_category_name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"A"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_sub_category_name"</span><span class="p">:</span><span class="w"> </span><span class="kc">null</span><span class="p">,</span><span class="w">
      </span><span class="nl">"stock_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">10</span><span class="p">,</span><span class="w">
      </span><span class="nl">"promotion"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
        </span><span class="p">{</span><span class="w">
          </span><span class="nl">"min_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">3</span><span class="p">,</span><span class="w">
          </span><span class="nl">"discounted_price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"19.00"</span><span class="w">
        </span><span class="p">},</span><span class="w">
        </span><span class="p">{</span><span class="w">
          </span><span class="nl">"min_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">5</span><span class="p">,</span><span class="w">
          </span><span class="nl">"discounted_price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"18.00"</span><span class="w">
        </span><span class="p">}</span><span class="w">
      </span><span class="p">]</span><span class="w">
    </span><span class="p">},</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">2</span><span class="p">,</span><span class="w">
      </span><span class="nl">"name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Product B"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"description"</span><span class="p">:</span><span class="w"> </span><span class="s2">"&lt;p&gt;This is a dummy product description.&lt;/p&gt;"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"image"</span><span class="p">:</span><span class="w"> </span><span class="kc">null</span><span class="p">,</span><span class="w">
      </span><span class="nl">"price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"20.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"min_purchase_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="p">,</span><span class="w">
      </span><span class="nl">"max_purchase_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">50</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_type"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Service"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"service_description"</span><span class="p">:</span><span class="w"> </span><span class="s2">"&lt;p&gt;This is a dummy product service description.&lt;/p&gt;"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_category_name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"B"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_sub_category_name"</span><span class="p">:</span><span class="w"> </span><span class="kc">null</span><span class="w">
    </span><span class="p">}</span><span class="w">
  </span><span class="p">]</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<p>This endpoint retrieves all the products.</p>
<h3 id='http-request-2'>HTTP Request</h3>
<p><code>GET /products</code></p>
<h3 id='available-parameters'>Available Parameters</h3>
<table><thead>
<tr>
<th>Parameter</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead><tbody>
<tr>
<td>page</td>
<td>integer</td>
<td>Current page of the collection. Default is <code>1</code>.</td>
</tr>
</tbody></table>
<h2 id='retrieve-a-product'>Retrieve a product</h2>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">true</span><span class="p">,</span><span class="w">
  </span><span class="nl">"data"</span><span class="p">:</span><span class="w"> </span><span class="p">{</span><span class="w">
    </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="p">,</span><span class="w">
    </span><span class="nl">"name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Product A"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"description"</span><span class="p">:</span><span class="w"> </span><span class="s2">"&lt;p&gt;This is a dummy product description.&lt;/p&gt;"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"image"</span><span class="p">:</span><span class="w"> </span><span class="s2">"http://127.0.0.1:8000/storage/product_image/example.jpg"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"20.00"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"min_purchase_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="p">,</span><span class="w">
    </span><span class="nl">"max_purchase_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">0</span><span class="p">,</span><span class="w">
    </span><span class="nl">"product_type"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Serial key"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"product_category_name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"A"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"product_sub_category_name"</span><span class="p">:</span><span class="w"> </span><span class="kc">null</span><span class="p">,</span><span class="w">
    </span><span class="nl">"stock_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">10</span><span class="p">,</span><span class="w">
    </span><span class="nl">"promotion"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
      </span><span class="p">{</span><span class="w">
        </span><span class="nl">"min_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">3</span><span class="p">,</span><span class="w">
        </span><span class="nl">"discounted_price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"19.00"</span><span class="w">
      </span><span class="p">},</span><span class="w">
      </span><span class="p">{</span><span class="w">
        </span><span class="nl">"min_qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">5</span><span class="p">,</span><span class="w">
        </span><span class="nl">"discounted_price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"18.00"</span><span class="w">
      </span><span class="p">}</span><span class="w">
    </span><span class="p">]</span><span class="w">
  </span><span class="p">}</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<p>This endpoint retrieves a product by id.</p>
<h3 id='http-request-3'>HTTP Request</h3>
<p><code>GET /products/&lt;id&gt;</code></p>
<h1 id='orders'>Orders</h1><h2 id='order-properties'>Order properties</h2>
<table><thead>
<tr>
<th>Attribute</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead><tbody>
<tr>
<td>id</td>
<td>integer</td>
<td>Unique identifier for the resource.</td>
</tr>
<tr>
<td>buyer_email</td>
<td>email</td>
<td>Buyer email.</td>
</tr>
<tr>
<td>total</td>
<td>string</td>
<td>Grand total.</td>
</tr>
<tr>
<td>platform_commission_percentage</td>
<td>string</td>
<td>Platform commission percentage for this order.</td>
</tr>
<tr>
<td>platform_commission_amount</td>
<td>string</td>
<td>Total deducted platform commission for this order.</td>
</tr>
<tr>
<td>product_cost</td>
<td>string</td>
<td>Total of resell cost price in this order.</td>
</tr>
<tr>
<td>seller_profit</td>
<td>string</td>
<td>Total of profit in this order after deducted platform commission and product cost.</td>
</tr>
<tr>
<td>status</td>
<td>string</td>
<td>Order status. Options: <code>Complete payment</code>. Default is <code>Complete payment</code>.</td>
</tr>
<tr>
<td>created_at</td>
<td>date-time</td>
<td>The date the order was created, in <code>d-m-Y H:i:s</code> format.</td>
</tr>
<tr>
<td>product</td>
<td>array</td>
<td>Purchased products data. See <a href="#order-product-properties">Order - Product properties</a></td>
</tr>
</tbody></table>
<h3 id='order-product-properties'>Order - Product properties</h3>
<table><thead>
<tr>
<th>Attribute</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead><tbody>
<tr>
<td>name</td>
<td>string</td>
<td>Product name.</td>
</tr>
<tr>
<td>product_type</td>
<td>string</td>
<td>Product type. Options: <code>Serial key</code>, <code>Service</code>.</td>
</tr>
<tr>
<td>qty</td>
<td>integer</td>
<td>Purchase quantity of this product.</td>
</tr>
<tr>
<td>unit_price</td>
<td>string</td>
<td>Product unit price.</td>
</tr>
<tr>
<td>sub_total</td>
<td>string</td>
<td>Sub total of this product. Formular: <code>qty * unit_price</code>.</td>
</tr>
<tr>
<td>serial_number</td>
<td>array</td>
<td>Serial keys assigned to this sales order product. Only for <code>Serial key</code> type product.</td>
</tr>
</tbody></table>
<h2 id='create-an-order'>Create an order</h2>
<blockquote>
<p>Request example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"buyer_email"</span><span class="p">:</span><span class="w"> </span><span class="s2">"example@example.com"</span><span class="p">,</span><span class="w">
  </span><span class="nl">"product"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"product_id"</span><span class="p">:</span><span class="w"> </span><span class="mi">5</span><span class="p">,</span><span class="w">
      </span><span class="nl">"qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="w">
    </span><span class="p">},</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"product_id"</span><span class="p">:</span><span class="w"> </span><span class="mi">2</span><span class="p">,</span><span class="w">
      </span><span class="nl">"qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">5</span><span class="w">
    </span><span class="p">}</span><span class="w">
  </span><span class="p">]</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">true</span><span class="p">,</span><span class="w">
  </span><span class="nl">"data"</span><span class="p">:</span><span class="w"> </span><span class="p">{</span><span class="w">
    </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="w"> </span><span class="err">//order</span><span class="w"> </span><span class="err">id</span><span class="w">
  </span><span class="p">}</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<p>This endpoint let you to create a new order and return you an order id.</p>
<h3 id='http-request-4'>HTTP Request</h3>
<p><code>POST /orders</code></p>
<h3 id='request-body-reference'>Request Body Reference</h3>
<table><thead>
<tr>
<th>Parameter</th>
<th>Type</th>
<th>Optional</th>
</tr>
</thead><tbody>
<tr>
<td>buyer_email</td>
<td>email</td>
<td>No</td>
</tr>
<tr>
<td>product_id</td>
<td>integer</td>
<td>No</td>
</tr>
<tr>
<td>qty</td>
<td>integer</td>
<td>No</td>
</tr>
</tbody></table>
<h2 id='retrieve-an-order'>Retrieve an order</h2>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">true</span><span class="p">,</span><span class="w">
  </span><span class="nl">"data"</span><span class="p">:</span><span class="w"> </span><span class="p">{</span><span class="w">
    </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">2</span><span class="p">,</span><span class="w">
    </span><span class="nl">"buyer_email"</span><span class="p">:</span><span class="w"> </span><span class="s2">"example@example.com"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"total"</span><span class="p">:</span><span class="w"> </span><span class="s2">"200.00"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"platform_commission_percentage"</span><span class="p">:</span><span class="w"> </span><span class="s2">"4.00"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"platform_commission_amount"</span><span class="p">:</span><span class="w"> </span><span class="s2">"8.00"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"product_cost"</span><span class="p">:</span><span class="w"> </span><span class="s2">"0.00"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"seller_profit"</span><span class="p">:</span><span class="w"> </span><span class="s2">"192.00"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"status"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Complete payment"</span><span class="p">,</span><span class="w">
    </span><span class="nl">"product"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
      </span><span class="p">{</span><span class="w">
        </span><span class="nl">"name"</span><span class="p">:</span><span class="w"> </span><span class="s2">"q"</span><span class="p">,</span><span class="w">
        </span><span class="nl">"product_type"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Serial key"</span><span class="p">,</span><span class="w">
        </span><span class="nl">"qty"</span><span class="p">:</span><span class="w"> </span><span class="mi">2</span><span class="p">,</span><span class="w">
        </span><span class="nl">"unit_price"</span><span class="p">:</span><span class="w"> </span><span class="s2">"100.00"</span><span class="p">,</span><span class="w">
        </span><span class="nl">"sub_total"</span><span class="p">:</span><span class="w"> </span><span class="s2">"200.00"</span><span class="p">,</span><span class="w">
        </span><span class="nl">"serial_number"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="s2">"example_serial_number_1"</span><span class="p">,</span><span class="w"> </span><span class="s2">"example_serial_number_2"</span><span class="p">]</span><span class="w">
      </span><span class="p">}</span><span class="w">
    </span><span class="p">],</span><span class="w">
    </span><span class="nl">"created_at"</span><span class="p">:</span><span class="w"> </span><span class="s2">"02-08-2022 16:04:10"</span><span class="w">
  </span><span class="p">}</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<p>This endpoint retrieves an order by id.</p>
<h3 id='http-request-5'>HTTP Request</h3>
<p><code>GET /orders/&lt;id&gt;</code></p>
<h2 id='list-all-orders'>List all orders</h2>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">true</span><span class="p">,</span><span class="w">
  </span><span class="nl">"data"</span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">1</span><span class="p">,</span><span class="w">
      </span><span class="nl">"buyer_email"</span><span class="p">:</span><span class="w"> </span><span class="s2">"example@example.com"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"total"</span><span class="p">:</span><span class="w"> </span><span class="s2">"200.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"platform_commission_percentage"</span><span class="p">:</span><span class="w"> </span><span class="s2">"4.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"platform_commission_amount"</span><span class="p">:</span><span class="w"> </span><span class="s2">"8.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_cost"</span><span class="p">:</span><span class="w"> </span><span class="s2">"0.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"seller_profit"</span><span class="p">:</span><span class="w"> </span><span class="s2">"192.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"status"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Complete payment"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"created_at"</span><span class="p">:</span><span class="w"> </span><span class="s2">"2022-08-02 16:04:10"</span><span class="w">
    </span><span class="p">},</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"id"</span><span class="p">:</span><span class="w"> </span><span class="mi">2</span><span class="p">,</span><span class="w">
      </span><span class="nl">"buyer_email"</span><span class="p">:</span><span class="w"> </span><span class="s2">"example@example.com"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"total"</span><span class="p">:</span><span class="w"> </span><span class="s2">"100.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"platform_commission_percentage"</span><span class="p">:</span><span class="w"> </span><span class="s2">"4.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"platform_commission_amount"</span><span class="p">:</span><span class="w"> </span><span class="s2">"4.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"product_cost"</span><span class="p">:</span><span class="w"> </span><span class="s2">"0.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"seller_profit"</span><span class="p">:</span><span class="w"> </span><span class="s2">"96.00"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"status"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Complete payment"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"created_at"</span><span class="p">:</span><span class="w"> </span><span class="s2">"2022-08-03 07:49:28"</span><span class="w">
    </span><span class="p">}</span><span class="w">
  </span><span class="p">]</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<p>This endpoint retrieves all the orders.</p>
<h3 id='http-request-6'>HTTP Request</h3>
<p><code>GET /orders</code></p>
<h3 id='available-parameters-2'>Available Parameters</h3>
<table><thead>
<tr>
<th>Parameter</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead><tbody>
<tr>
<td>page</td>
<td>integer</td>
<td>Current page of the collection. Default is <code>1</code>.</td>
</tr>
</tbody></table>
<h1 id='errors'>Errors</h1>
<blockquote>
<p>JSON response example:</p>
</blockquote>
<div class="highlight"><pre class="highlight json tab-json"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"success"</span><span class="p">:</span><span class="w"> </span><span class="kc">false</span><span class="p">,</span><span class="w">
  </span><span class="nl">"message"</span><span class="p">:</span><span class="w"> </span><span class="s2">"Product not found."</span><span class="w">
</span><span class="p">}</span><span class="w">
</span></code></pre></div>
<aside class="notice">
Any HiGamix endpoint can return an error.
</aside>

<p>The HiGamix API uses the following error codes and format:</p>

<table><thead>
<tr>
<th>Error Code</th>
<th>Meaning</th>
</tr>
</thead><tbody>
<tr>
<td>400</td>
<td>Bad Request -- Your request is invalid.</td>
</tr>
<tr>
<td>401</td>
<td>Unauthorized -- Your authorization token is incorrect.</td>
</tr>
<tr>
<td>403</td>
<td>Forbidden -- You dont&#39;t have permission to access this endpoint.</td>
</tr>
<tr>
<td>404</td>
<td>Not Found -- The specified product or order could not be found.</td>
</tr>
<tr>
<td>405</td>
<td>Method Not Allowed -- You tried to access with an invalid method.</td>
</tr>
<tr>
<td>429</td>
<td>Too Many Requests -- You&#39;re sending too many request.</td>
</tr>
<tr>
<td>500</td>
<td>Internal Server Error -- We had a problem with our server. Try again later.</td>
</tr>
<tr>
<td>503</td>
<td>Service Unavailable -- We&#39;re temporarily offline for maintenance. Please try again later.</td>
</tr>
</tbody></table>

      </div>
      <div class="dark-box">
          <div class="lang-selector">
                <a href="#" data-language-name="javascript">node.js</a>
          </div>
      </div>
    </div>
  </body>
</html>
