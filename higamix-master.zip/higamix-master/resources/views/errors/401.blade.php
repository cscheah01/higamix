@extends('public/layout/layout')

@section('page_title', 'Unauthorized')
@section('page_id', 'error')


@section('content')
    <div class="row justify-content-center align-items-center py-5" id="main-content-wrapper">
        <div class="col-12 col-sm-6">
            <img src="{{ asset('img/higamix-error-stop-access.png') }}" draggable="false" class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-sm-6">
            <h1 class="title text-primary font-weight-bolder">401</h1>
            <p class="content">You don't have permission to access this page.</p>
        </div>
    </div>
@endsection
