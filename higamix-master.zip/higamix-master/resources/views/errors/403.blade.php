@extends('public/layout/layout')

@section('page_title', 'Forbidden')
@section('page_id', 'error')


@section('content')
    <div class="row justify-content-center align-items-center py-5" id="main-content-wrapper">
        <div class="col-12 col-sm-6">
            <img src="{{ asset('img/higamix-robot.png') }}" draggable="false" class="mx-auto d-block w-75">
        </div>
        <div class="col-12 col-sm-6">
            <h1 class="title text-primary font-weight-bolder">403</h1>
            <p class="content">You dont't have access to the page you requested.</p>
        </div>
    </div>
@endsection
