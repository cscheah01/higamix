---
title: HiGamix API Reference

language_tabs: # must be one of https://git.io/vQNgJ
  - javascript: node.js

toc_footers:

includes:
  - errors

search: true

code_clipboard: true

meta:
  - name: HiGamix API Documentation
    content: Documentation for the HiGamix API
---

# Introduction

Welcome to the HiGamix API! HiGamix is an E-Commerce platform that let everyone to sell digital goods online in a secure and modern environment.

HiGamix API allow the merchant to integrate with their own platform. Our API allows you to connect your store in our platform and sell it on your own platform.

## Base URL

<code>https://www.higamix.com/api/v1</code>

## Rate limit

HiGamix API endpoints call are limited to <code>1000 request/minute</code>. Exceed the rate limit will result in a <code>429</code> HTTP return code.

# Authentication

HiGamix API uses HMAC-SHA256 as its authentication mechanism.

## API keys

You can get the <code>Public Key</code> and <code>Secret Key</code> from the <a href="https://www.higamix.com/login" target="_blank">merchant portal</a> **account setting page** under API Credentials section to generate a HMAC-SHA256 signature.

<aside class="notice">
Please store your <code>Public Key</code> and <code>Secret Key</code> in a secure environment and <b>should avoid</b> to store at client-side code.
</aside>

## Signature

```javascript
const secretKey = 's6Gdsd86eda18-157a-475e-b312-487ab7281ce0hCxba';
const requestBody = JSON.stringify({...}); // => the whole request body
const timestamp = new Date().getTime().toString(); // => `1659530485630`

const rawSignature = `${timestamp}\r\n\r\n${requestBody}`;

const signature = CryptoJS.HmacSHA256(rawSignature, secretKey).toString();
// => 'ad4ecdd30d579e5fa7d0692edf01a6c0f13652af6a6778291914ebcde1cccc60'
```

HMAC-SHA256 signatures is require for all endpoints.

**The format of the Raw Signature:**<br>
<code>&#60;timestamp&#62;\r\n\r\n&#60;requestBody&#62;</code>

Use <code>Secret Key</code> as the key and the <code>Raw Signature</code> as the value for the HMAC operation.

<aside class="notice">
API calls will be rejected if the <code>timestamp</code> is not within 60 seconds window from the endpoint server’s time.
</aside>

## Headers

```javascript
const publictKey = "PcwQg965f5891-4435-45e9-98d7-5ba77655fdc9Ls6LP";
const token = `${publictKey}:${timestamp}:${signature}`;
```

> Example:

````
Authorization: hmac PcwQg965f5891-4435-45e9-98d7-5ba77655fdc9Ls6LP:1659530485630:ad4ecdd30d579e5fa7d0692edf01a6c0f13652af6a6778291914ebcde1cccc60
```

Every API call **must include** <code>Authorization</code> header with the token.

**The format of the token:**<br>
<code>&#60;publictKey&#62;:&#60;timestamp&#62;:&#60;signature&#62;</code>

# Wallet

## Get Wallet Balance

> JSON response example:

```json
{
  "success": true,
  "data": {
    "balance": "100.00"
  }
}
````

This endpoint retrieves the wallet balance.

### HTTP Request

`GET /balances`

# Products

## Product properties

| Attribute                 | Type    | Description                                                                                                                                                                   |
| ------------------------- | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| id                        | integer | Unique identifier for the resource..                                                                                                                                          |
| name                      | string  | Product name.                                                                                                                                                                 |
| description               | string  | Product description. This field will return html code in string, the content styling is base on [quilljs](https://quilljs.com).                                               |
| image                     | string  | Product image url.                                                                                                                                                            |
| price                     | string  | Product sell price.                                                                                                                                                           |
| min_purchase_qty          | integer | Minimum purchase quantity the product.                                                                                                                                        |
| max_purchase_qty          | integer | Maximum purchase quantity the product.                                                                                                                                        |
| product_type              | string  | Product type. Options: <code>Serial key</code>, <code>Service</code>.                                                                                                         |
| service_description       | string  | Product service description for <code>Service</code> type product. This field will return html code in string, the content styling is base on [quilljs](https://quilljs.com). |
| product_category_name     | string  | Category name.                                                                                                                                                                |
| product_sub_category_name | string  | Sub category name.                                                                                                                                                            |
| stock_qty                 | integer | Total remaining stock quantity for <code>Serial key</code> type product.                                                                                                      |
| promotion                 | array   | Promotions data. See [Product - Promotion properties](#product-promotion-properties)                                                                                          |

### Product - Promotion properties

| Attribute        | Type    | Description                                            |
| ---------------- | ------- | ------------------------------------------------------ |
| min_qty          | integer | Minimum purchase quantity to get the discounted price. |
| discounted_price | string  | Discounted unit price.                                 |

## List all products

> JSON response example:

```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Product A",
      "description": "<p>This is a dummy product description.</p>",
      "image": "http://127.0.0.1:8000/storage/product_image/example.jpg",
      "price": "20.00",
      "min_purchase_qty": 1,
      "max_purchase_qty": 0,
      "product_type": "Serial key",
      "product_category_name": "A",
      "product_sub_category_name": null,
      "stock_qty": 10,
      "promotion": [
        {
          "min_qty": 3,
          "discounted_price": "19.00"
        },
        {
          "min_qty": 5,
          "discounted_price": "18.00"
        }
      ]
    },
    {
      "id": 2,
      "name": "Product B",
      "description": "<p>This is a dummy product description.</p>",
      "image": null,
      "price": "20.00",
      "min_purchase_qty": 1,
      "max_purchase_qty": 50,
      "product_type": "Service",
      "service_description": "<p>This is a dummy product service description.</p>",
      "product_category_name": "B",
      "product_sub_category_name": null
    }
  ]
}
```

This endpoint retrieves all the products.

### HTTP Request

`GET /products`

### Available Parameters

| Parameter | Type    | Description                                                |
| --------- | ------- | ---------------------------------------------------------- |
| page      | integer | Current page of the collection. Default is <code>1</code>. |

## Retrieve a product

> JSON response example:

```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Product A",
    "description": "<p>This is a dummy product description.</p>",
    "image": "http://127.0.0.1:8000/storage/product_image/example.jpg",
    "price": "20.00",
    "min_purchase_qty": 1,
    "max_purchase_qty": 0,
    "product_type": "Serial key",
    "product_category_name": "A",
    "product_sub_category_name": null,
    "stock_qty": 10,
    "promotion": [
      {
        "min_qty": 3,
        "discounted_price": "19.00"
      },
      {
        "min_qty": 5,
        "discounted_price": "18.00"
      }
    ]
  }
}
```

This endpoint retrieves a product by id.

### HTTP Request

`GET /products/<id>`

# Orders

## Order properties

| Attribute                      | Type      | Description                                                                                     |
| ------------------------------ | --------- | ----------------------------------------------------------------------------------------------- |
| id                             | integer   | Unique identifier for the resource.                                                             |
| buyer_email                    | email     | Buyer email.                                                                                    |
| total                          | string    | Grand total.                                                                                    |
| platform_commission_percentage | string    | Platform commission percentage for this order.                                                  |
| platform_commission_amount     | string    | Total deducted platform commission for this order.                                              |
| product_cost                   | string    | Total of resell cost price in this order.                                                       |
| seller_profit                  | string    | Total of profit in this order after deducted platform commission and product cost.              |
| status                         | string    | Order status. Options: <code>Complete payment</code>. Default is <code>Complete payment</code>. |
| created_at                     | date-time | The date the order was created, in <code>d-m-Y H:i:s</code> format.                             |
| product                        | array     | Purchased products data. See [Order - Product properties](#order-product-properties)            |

### Order - Product properties

| Attribute     | Type    | Description                                                                                      |
| ------------- | ------- | ------------------------------------------------------------------------------------------------ |
| name          | string  | Product name.                                                                                    |
| product_type  | string  | Product type. Options: <code>Serial key</code>, <code>Service</code>.                            |
| qty           | integer | Purchase quantity of this product.                                                               |
| unit_price    | string  | Product unit price.                                                                              |
| sub_total     | string  | Sub total of this product. Formular: <code>qty \* unit_price</code>.                             |
| serial_number | array   | Serial keys assigned to this sales order product. Only for <code>Serial key</code> type product. |

## Create an order

> Request example:

```json
{
  "buyer_email": "example@example.com",
  "product": [
    {
      "product_id": 5,
      "qty": 1
    },
    {
      "product_id": 2,
      "qty": 5
    }
  ]
}
```

> JSON response example:

```json
{
  "success": true,
  "data": {
    "id": 1 //order id
  }
}
```

This endpoint let you to create a new order and return you an order id.

### HTTP Request

`POST /orders`

### Request Body Reference

| Parameter   | Type    | Optional |
| ----------- | ------- | -------- |
| buyer_email | email   | No       |
| product_id  | integer | No       |
| qty         | integer | No       |

## Retrieve an order

> JSON response example:

```json
{
  "success": true,
  "data": {
    "id": 2,
    "buyer_email": "example@example.com",
    "total": "200.00",
    "platform_commission_percentage": "4.00",
    "platform_commission_amount": "8.00",
    "product_cost": "0.00",
    "seller_profit": "192.00",
    "status": "Complete payment",
    "product": [
      {
        "name": "q",
        "product_type": "Serial key",
        "qty": 2,
        "unit_price": "100.00",
        "sub_total": "200.00",
        "serial_number": ["example_serial_number_1", "example_serial_number_2"]
      }
    ],
    "created_at": "02-08-2022 16:04:10"
  }
}
```

This endpoint retrieves an order by id.

### HTTP Request

`GET /orders/<id>`

## List all orders

> JSON response example:

```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "buyer_email": "example@example.com",
      "total": "200.00",
      "platform_commission_percentage": "4.00",
      "platform_commission_amount": "8.00",
      "product_cost": "0.00",
      "seller_profit": "192.00",
      "status": "Complete payment",
      "created_at": "2022-08-02 16:04:10"
    },
    {
      "id": 2,
      "buyer_email": "example@example.com",
      "total": "100.00",
      "platform_commission_percentage": "4.00",
      "platform_commission_amount": "4.00",
      "product_cost": "0.00",
      "seller_profit": "96.00",
      "status": "Complete payment",
      "created_at": "2022-08-03 07:49:28"
    }
  ]
}
```

This endpoint retrieves all the orders.

### HTTP Request

`GET /orders`

### Available Parameters

| Parameter | Type    | Description                                                |
| --------- | ------- | ---------------------------------------------------------- |
| page      | integer | Current page of the collection. Default is <code>1</code>. |
