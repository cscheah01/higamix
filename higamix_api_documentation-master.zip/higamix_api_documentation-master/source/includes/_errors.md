# Errors

> JSON response example:

```json
{
  "success": false,
  "message": "Product not found."
}
```

<aside class="notice">
Any HiGamix endpoint can return an error.
</aside>

The HiGamix API uses the following error codes and format:

| Error Code | Meaning                                                                                   |
| ---------- | ----------------------------------------------------------------------------------------- |
| 400        | Bad Request -- Your request is invalid.                                                   |
| 401        | Unauthorized -- Your authorization token is incorrect.                                    |
| 403        | Forbidden -- You dont't have permission to access this endpoint.                          |
| 404        | Not Found -- The specified product or order could not be found.                           |
| 405        | Method Not Allowed -- You tried to access with an invalid method.                         |
| 429        | Too Many Requests -- You're sending too many request.                                     |
| 500        | Internal Server Error -- We had a problem with our server. Try again later.               |
| 503        | Service Unavailable -- We're temporarily offline for maintenance. Please try again later. |
